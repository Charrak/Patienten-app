#!/usr/bin/env node
'use strict';
/* Erzeugt ein Demo-Backup (JSON) über die echte App-Logik (public/local-api.js):
   4 Trainer, 7 Gruppen, 20 Patienten mit unterschiedlichen Verordnungen
   (Arten, Kostenträger, Status). Aufruf:  node scripts/make-demo-backup.js [ausgabe.json] */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

global.window = globalThis;
const store = new Map();
window.localStorage = { getItem: (k) => (store.has(k) ? store.get(k) : null), setItem: (k, v) => { store.set(k, String(v)); }, removeItem: (k) => { store.delete(k); } };
require(path.join(__dirname, '..', 'lib', 'rules.js'));
require(path.join(__dirname, '..', 'lib', 'ical.js'));
require(path.join(__dirname, '..', 'public', 'local-api.js'));
const A = window.localApi;

/* ---------- Hilfen ---------- */
let seed = 20261030;
const rnd = () => { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; };
const iso = (d) => d.toISOString().slice(0, 10);
const tage = (n) => new Date(Date.now() + n * 86400000);
const addDays = (isoStr, n) => iso(new Date(new Date(isoStr + 'T12:00:00Z').getTime() + n * 86400000));
const heute = iso(new Date());

/* kleine Unterschrift als PNG (Schreibzug mit Zufallsschwung) */
function crc32(buf) { let c, crc = -1; for (let n = 0; n < buf.length; n++) { c = (crc ^ buf[n]) & 0xff; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; crc = (crc >>> 8) ^ c; } return (crc ^ -1) >>> 0; }
function chunk(type, data) { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]); const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td)); return Buffer.concat([len, td, crc]); }
function signaturPng(s) {
  const W = 200, H = 60, px = Buffer.alloc(W * H * 4, 0);
  const a1 = 6 + (s % 7), a2 = 0.05 + (s % 5) * 0.012, ph = (s % 11) / 3;
  const pts = [];
  for (let x = 12; x < W - 12; x += 0.5) {
    const t = (x - 12) / (W - 24);
    pts.push([x, H / 2 + Math.sin(x * a2 * 2 + ph) * a1 * (1 - t * 0.5) + Math.sin(x * 0.31 + s) * 5 * t - (x % 40 < 3 ? 10 : 0)]);
  }
  for (const [x, y] of pts) for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) {
    const X = Math.round(x) + dx, Y = Math.round(y) + dy;
    if (X >= 0 && X < W && Y >= 0 && Y < H) { const i = (Y * W + X) * 4; px[i] = 20; px[i + 1] = 40; px[i + 2] = 110; px[i + 3] = 255; }
  }
  const raw = Buffer.alloc((W * 4 + 1) * H);
  for (let y = 0; y < H; y++) { raw[y * (W * 4 + 1)] = 0; px.copy(raw, y * (W * 4 + 1) + 1, y * W * 4, (y + 1) * W * 4); }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 6;
  const png = Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
  return `data:image/png;base64,${png.toString('base64')}`;
}

/* ---------- Stammdaten ---------- */
const TRAINER = [
  { vorname: 'Anna', nachname: 'Berger', farbe: '#0b6b6b', email: 'anna.berger@example.de', telefon: '+49 170 1110001', stundenlohn: '22,50', qualifikationen: ['uebungsleiter', 'orthopaedie', 'neurologie'], notfall: 'notfallsanitaeter' },
  { vorname: 'Jonas', nachname: 'Keller', farbe: '#1971c2', email: 'jonas.keller@example.de', telefon: '+49 170 1110002', stundenlohn: '24,00', qualifikationen: ['uebungsleiter', 'wasser', 'orthopaedie'], notfall: 'rettungssanitaeter' },
  { vorname: 'Mira', nachname: 'Sommer', farbe: '#c2255c', email: 'mira.sommer@example.de', telefon: '+49 170 1110003', stundenlohn: '30,00', qualifikationen: ['uebungsleiter', 'herzgruppenleiter', 'innere'], notfall: 'arzt' },
  { vorname: 'Lena', nachname: 'Fischer', farbe: '#e67700', email: 'lena.fischer@example.de', telefon: '+49 170 1110004', stundenlohn: '21,00', qualifikationen: ['uebungsleiter', 'funktionstraining', 'kinder', 'orthopaedie'], notfall: 'rettungssanitaeter' },
];

/* Kurse: key, Titel, Art, Trainer-Index, Wochentag (1=Mo), Beginn, Dauer, Ort */
const KURSE = [
  { key: 'rsMo', titel: 'Rücken-Fit Montag', art: 'rs', t: 0, wt: 1, beginn: '17:30', dauer: 45, ort: 'Sporthalle Nord' },
  { key: 'rsMi', titel: 'Gelenk-Fit Mittwoch', art: 'rs', t: 0, wt: 3, beginn: '18:30', dauer: 45, ort: 'Sporthalle Nord' },
  { key: 'wasser', titel: 'Wassergymnastik Dienstag', art: 'rsWasser', t: 1, wt: 2, beginn: '16:00', dauer: 45, ort: 'Hallenbad Mitte' },
  { key: 'herz', titel: 'Herzgruppe Donnerstag', art: 'herzgruppe', t: 2, wt: 4, beginn: '19:00', dauer: 60, ort: 'Reha-Zentrum' },
  { key: 'hi', titel: 'Herzinsuffizienz Freitag', art: 'herzinsuffizienz', t: 2, wt: 5, beginn: '10:00', dauer: 60, ort: 'Reha-Zentrum' },
  { key: 'ft', titel: 'Funktionstraining Rheuma', art: 'funktionstraining', t: 3, wt: 1, beginn: '10:00', dauer: 45, ort: 'Gesundheitshaus' },
  { key: 'kids', titel: 'Reha-Sport Kinder', art: 'rsKinder', t: 3, wt: 6, beginn: '10:00', dauer: 45, ort: 'Turnhalle Grundschule' },
];

/* Patienten: Name, Geburtstag, Kasse, Art-Kurs, Kostenträger, Besonderheiten */
const P = [
  // GKV – Rehasport Trocken
  { n: 'Schneider, Heike', g: '1962-03-14', kk: 'AOK Rheinland/Hamburg', k: 'rsMo', icd: 'M54.5;M51.1', z: 'Schmerzreduktion, Rumpfkräftigung', fort: 7, ue: 50, f: 2 },
  { n: 'Wagner, Dieter', g: '1957-11-02', kk: 'Techniker Krankenkasse', k: 'rsMo', icd: 'M17.1', z: 'Gelenkmobilität, Muskelaufbau Knie', fort: 5, ue: 50, f: 2 },
  { n: 'Becker, Ursula', g: '1949-06-21', kk: 'BARMER', k: 'rsMi', icd: 'M81.0', z: 'Sturzprophylaxe, Knochenbelastung', fort: 9, ue: 50, f: 1, folge: true },
  { n: 'Hoffmann, Klaus', g: '1968-01-30', kk: 'DAK-Gesundheit', k: 'rsMi', icd: 'M75.1;M25.5', z: 'Schulterbeweglichkeit', fort: 4, ue: 50, f: 2, abbruch: { vorTagen: 12, grund: 'Umzug in eine andere Stadt' } },
  { n: 'Schulz, Renate', g: '1955-09-09', kk: 'IKK classic', k: 'rsMo', icd: 'E11.9;E66.0', z: 'Gewichtsreduktion, Stoffwechsel', fort: 6, ue: 50, f: 2 },
  { n: 'Koch, Manfred', g: '1960-12-12', kk: 'AOK NordWest', k: 'rsMi', icd: 'C61', z: 'Belastbarkeit nach Krebstherapie', fort: 3, ue: 50, f: 2 },
  { n: 'Richter, Sabine', g: '1971-04-25', kk: 'KKH', k: 'rsMo', icd: 'M79.7', z: 'Fibromyalgie: Schmerzbewältigung', fort: 8, ue: 50, f: 2, abbruch: { vorTagen: 20, grund: 'Gesundheitliche Verschlechterung, Kur geplant' } },
  { n: 'Klein, Walter', g: '1952-08-17', kk: 'Techniker Krankenkasse', k: 'rsMi', icd: 'M16.0', z: 'Koordination, Gangsicherheit', fort: 12, ue: 10, f: 1, abgeschlossen: true, ueeBegr: 'Kurzverordnung nach Hüft-TEP' },
  // Wasser
  { n: 'Wolf, Brigitte', g: '1958-02-05', kk: 'AOK Rheinland/Hamburg', k: 'wasser', icd: 'M15.0;M47.8', z: 'Gelenkschonende Kräftigung', fort: 6, ue: 50, f: 2 },
  { n: 'Neumann, Peter', g: '1964-10-28', kk: 'BARMER', k: 'wasser', icd: 'S83.5', z: 'Aufbau nach Kreuzbandverletzung', fort: 5, ue: 50, f: 2 },
  // Herzgruppe
  { n: 'Schwarz, Helmut', g: '1951-05-19', kk: 'DAK-Gesundheit', k: 'herz', icd: 'I25.1;Z95.1', z: 'Belastbarkeit nach Bypass-OP', fort: 8, ue: 90, f: 2 },
  { n: 'Zimmermann, Gisela', g: '1956-07-07', kk: 'AOK NordWest', k: 'herz', icd: 'I21.4', z: 'Herz-Kreislauf-Training nach Infarkt', fort: 7, ue: 90, f: 2 },
  { n: 'Braun, Günter', g: '1949-03-03', kk: 'Techniker Krankenkasse', k: 'herz', icd: 'I48.0', z: 'Rhythmusstabilität, Ausdauer', fort: 6, ue: 90, f: 2, abbruch: { vorTagen: 9, grund: 'Wechsel in eine wohnortnahe Herzgruppe' } },
  // Herzinsuffizienz
  { n: 'Krüger, Ilse', g: '1946-11-23', kk: 'BARMER', k: 'hi', icd: 'I50.1', z: 'Belastungstoleranz erhalten', fort: 6, ue: 90, f: 2 },
  // Funktionstraining
  { n: 'Hartmann, Elke', g: '1960-04-11', kk: 'IKK classic', k: 'ft', icd: 'M05.8;M06.0', z: 'Gelenkfunktion, Morgensteifigkeit', fort: 9, ue: 50, f: 1 },
  { n: 'Lange, Thomas', g: '1966-09-30', kk: 'KKH', k: 'ft', icd: 'M45.0', z: 'Wirbelsäulenbeweglichkeit (Bechterew)', fort: 8, ue: 50, f: 1 },
  { n: 'Werner, Christa', g: '1953-01-18', kk: 'AOK Rheinland/Hamburg', k: 'ft', icd: 'M15.9', z: 'Arthrose: Beweglichkeit, Schmerzlinderung', fort: 5, ue: 50, f: 1 },
  // Kinder
  { n: 'Meier, Luca', g: '2015-06-02', kk: 'Techniker Krankenkasse', k: 'kids', icd: 'Q66.8;M21.6', z: 'Fußfehlstellung, Haltungsschulung', fort: 6, ue: 50, f: 1 },
  // Rentenversicherung (G0850) und Unfallversicherung (DGUV)
  { n: 'Lehmann, Jürgen', g: '1972-02-14', kk: 'Deutsche Rentenversicherung Rheinland', kt: 'rv', ft: 'g0850', k: 'rsMo', icd: 'M54.4', z: 'Erhalt der Erwerbsfähigkeit', fort: 4, ue: 50, f: 2 },
  { n: 'Köhler, Andrea', g: '1980-08-08', kk: 'BG Handel und Warenlogistik', kt: 'uv', ft: 'dguv', k: 'rsMi', icd: 'S82.3', z: 'Rückkehr in den Beruf nach Unfall', fort: 3, ue: 50, f: 2 },
];
// Verordnung im Entwurf (nur eingescannt, noch nicht fertig erfasst)
const ENTWURF = { n: 'Fuchs, Martina', g: '1969-05-15', kk: 'DAK-Gesundheit', icd: 'M54.5', z: 'Rückenschmerzen', art: 'rs', ue: 50, f: 2, von: heute };

const arten = { rsMo: 'rs', rsMi: 'rs', wasser: 'rsWasser', herz: 'herzgruppe', hi: 'herzinsuffizienz', ft: 'funktionstraining', kids: 'rsKinder' };
const SIG_LEITUNG = signaturPng(77);
const DOKU = {
  rs: ['Aufwärmen, Rumpfstabilisation (Plank-Varianten), Dehnung', 'Kräftigung Beine/Rücken mit Kleingeräten, Entspannung', 'Gleichgewichtsparcours, Mobilisation Wirbelsäule', 'Zirkeltraining leichte Intensität, Atemübungen'],
  rsWasser: ['Gehen und Laufen im Wasser, Auftriebsübungen', 'Widerstandsübungen mit Poolnudeln, Dehnung', 'Gelenkschonende Mobilisation, Entspannung'],
  herzgruppe: ['Ergometer 50–75 W, Pulskontrolle, Gymnastik', 'Ausdauer Zirkel, RR vor/nach Belastung', 'Koordination, Entspannung, Ärztliche Visite'],
  herzinsuffizienz: ['Leichte Ausdauer, RR/Puls vor und nach Belastung', 'Atemgymnastik, Kräftigung Kleingeräte'],
  funktionstraining: ['Gelenkübungen Hand/Schulter, Dehnung', 'Kräftigung mit Theraband, Entspannung'],
  rsKinder: ['Spielerische Koordination, Haltungsschulung', 'Fußgymnastik, Balance-Parcours'],
};

(async () => {
  await A('GET', '/api/state');
  await A('PUT', '/api/settings', {
    anbieter: { name: 'RheaSport Demo e. V.', ik: '123456789', strasse: 'Sportallee 1', plz: '50667', ort: 'Köln', email: 'info@example.de', telefon: '0221 000000' },
    fuehrungspersonal: [{ name: 'Petra Leitung', email: 'leitung@example.de' }],
    bundesland: 'NW', ortLändlich: false,
    gruppennamen: KURSE.map((k) => k.titel),
    abrechnung: { automatisch: true, saetze: [
      ...[['rs', 6.60, 6.94], ['rsWasser', 8.20, 8.62], ['herzgruppe', 10.18, 10.71], ['herzinsuffizienz', 10.18, 10.71], ['funktionstraining', 4.95, 5.20], ['rsKinder', 8.00, 8.41]].flatMap(([art, s25, s26]) => [
        { bundesland: 'NW', kostentraegerArt: 'gkv', kostentraeger: '', art, gueltigAb: '2025-01-01', satz: s25, quelle: 'Demo-Beispielwert (bitte durch RSD-Wert ersetzen)' },
        { bundesland: 'NW', kostentraegerArt: 'gkv', kostentraeger: '', art, gueltigAb: '2026-01-01', satz: s26, quelle: 'Demo-Beispielwert (bitte durch RSD-Wert ersetzen)' }]),
      { bundesland: '', kostentraegerArt: 'rv', kostentraeger: 'Deutsche Rentenversicherung', art: 'rs', gueltigAb: '2026-01-01', satz: 7.24, quelle: 'DRV Bund (Pos. 604503)' },
      { bundesland: '', kostentraegerArt: 'uv', kostentraeger: '', art: 'rs', gueltigAb: '2026-01-01', satz: 7.00, quelle: 'Demo-Beispielwert (bitte durch Träger-Wert ersetzen)' },
    ] },
  });

  const trainer = [];
  for (const t of TRAINER) {
    const r = await A('POST', '/api/trainer', {
      vorname: t.vorname, nachname: t.nachname, email: t.email, telefon: t.telefon, stundenlohn: t.stundenlohn,
      farbe: t.farbe, qualifikationen: t.qualifikationen, notfallqualifikation: t.notfall, notfallGueltigBis: '2027-12-31',
      zertifikateBis: '2028-12-31', verchwiegenheit: '2026-01-01', datenschutzBelehrung: '2026-01-01',
    });
    trainer.push(r.trainer);
  }
  const startKurse = iso(tage(-84));
  const kurse = {};
  for (const k of KURSE) {
    const r = await A('POST', '/api/kurse', {
      titel: k.titel, art: k.art, trainerId: trainer[k.t].id, ort: k.ort,
      raumflaecheQm: 140, wochentag: k.wt, beginn: k.beginn, dauerMin: k.dauer,
      maxTeilnehmer: Math.min(15, (({ rsKinder: 10, herzinsuffizienz: 12 })[k.art]) || 15), startdatum: startKurse, enddatum: '',
      betreuungsArzt: { name: 'Dr. med. Jan Weber', visitationAm: iso(tage(-40)) },
      notfallplan: true, aed: { vorhanden: true, wartungAm: iso(tage(-100)) }, notfallkoffer: true, notfallUebungAm: iso(tage(-80)),
      technischeGeraete: true, ergometer: k.art.startsWith('herz'),
    });
    kurse[k.key] = r.kurs;
  }

  /* --- Verordnungen anlegen --- */
  const eintraege = [];
  for (const [idx, p] of P.entries()) {
    const von = addDays(heute, -(p.fort * 7));
    const wochen = Math.ceil(p.ue / p.f);
    const bis = addDays(von, wochen * 7 + 14);
    const art = arten[p.k];
    const [nach, vor] = p.n.split(', ');
    const scan = await A('POST', '/api/verordnungen/scan', {
      code: JSON.stringify({ rs: '1', n: p.n, g: p.g, kk: p.kk, vs: `${'ABCDEFGHKLMNPRSTUVWXYZ'[idx]}${String(100000000 + idx * 7919317).slice(0, 9)}`, von, bis, art, f: p.f, ue: p.ue, icd: p.icd, z: p.z, arzt: 'Dr. med. Jan Weber', ft: p.ft || 'muster56', kt: p.kt || 'gkv', ik: p.kt === 'rv' ? '110301003' : p.kt === 'uv' ? '120691049' : `10${String(8310400 + (p.kk.length * 37) % 9000).padStart(7, '0')}` }),
    });
    const vid = scan.verordnung.id;
    const kurs = kurse[p.k];
    const email = `${vor.toLowerCase()}.${nach.toLowerCase().replace(/ü/g, 'ue').replace(/ö/g, 'oe').replace(/ä/g, 'ae')}@example.de`;
    try {
      const r = await A('PUT', `/api/verordnungen/${vid}`, {
        trainerId: kurs.trainerId, kursIds: [kurs.id], ausstellungsdatum: addDays(von, -5),
        email, telefon: `+49 171 ${2000000 + idx * 1357}`,
        kostenuebernahme: { liegtVor: true, datum: addDays(von, -2), zeitraum: '', kennzeichen: idx % 7 === 3 ? '' : `G${String(26100000 + idx * 4177)}`, gueltigBis: addDays(bis, 30) },
        frequenzBegruendung: '', ueeBegruendung: p.ueeBegr || '',
        dauerBegruendung: (new Date(bis) - new Date(von)) / 86400000 > 183 ? 'Therapieziel bei der verordneten Frequenz nicht innerhalb von 6 Monaten erreichbar; ärztlich begründet (längerer Aufbau der Belastbarkeit).' : '',
        folgeverordnung: Boolean(p.folge), folgeBegruendung: p.folge ? 'Selbstständige Durchführung der Übungen noch nicht sicher möglich (Osteoporose, Sturzrisiko).' : '',
        einwilligung: true, anmeldungUnterschrift: signaturPng(idx + 1), anmeldungDatum: von, abschliessen: true,
        angelegtVon: ['Petra Leitung', 'Anna Berger', 'Mira Sommer'][idx % 3], scanKontrolliert: true,
      });
      eintraege.push({ p, vid, kurs, patientId: r.verordnung.patientId, von, idx });
    } catch (e) { console.error(`WARNUNG ${p.n} (${art}, ${p.ue} ÜE, f${p.f}):`, e.message, ((e.daten && e.daten.pruefung && e.daten.pruefung.felder) || []).filter((f) => !f.ok && f.blockierend).map((f) => `${f.name}: ${f.text}`).join(' || ')); }
  }
  // Beratungsprotokoll (Rehabilitationssport): bei den meisten unterschrieben, bei jedem fünften noch offen
  for (const e of eintraege.filter((x) => x.p.k !== 'ft' && x.idx % 5 !== 0)) {
    await A('PUT', `/api/verordnungen/${e.vid}`, { beratungsprotokoll: {
      datum: addDays(e.von, -3), ort: 'Köln', leistungen: e.idx % 4 === 0 ? 'Teilnahme an Vereinsangeboten' : '', beitrag: e.idx % 4 === 0 ? '5' : '', turnus: e.idx % 4 === 0 ? 'monatlich' : '',
      kopie: true, anbieterName: 'Petra Leitung', unterschriftVersicherte: signaturPng(e.idx + 1), unterschriftAnbieter: signaturPng(77),
    } });
  }
  // Entwurf ohne Abschluss
  await A('POST', '/api/verordnungen/scan', { code: JSON.stringify({ rs: '1', n: ENTWURF.n, g: ENTWURF.g, kk: ENTWURF.kk, vs: 'Z999888777', von: ENTWURF.von, bis: addDays(ENTWURF.von, 190), art: ENTWURF.art, f: ENTWURF.f, ue: ENTWURF.ue, icd: ENTWURF.icd, z: ENTWURF.z, arzt: 'Dr. med. Jan Weber', ft: 'muster56' }) });

  /* --- Termine, Unterschriften, Bestätigungen --- */
  const von = iso(tage(-90)), bis = iso(tage(60));
  const termine = (await A('GET', `/api/termine?von=${von}&bis=${bis}`)).termine;
  const abbruchDatum = (e) => (e.p.abbruch ? addDays(heute, -e.p.abbruch.vorTagen) : null);
  let sig = 0, fehlend = 0;
  for (const t of termine.filter((x) => x.datum < heute).sort((a, b) => a.datum.localeCompare(b.datum))) {
    for (const e of eintraege.filter((x) => x.kurs.id === t.kursId)) {
      if (t.datum < e.von) continue;
      const stop = abbruchDatum(e);
      if (stop && t.datum > stop) continue;
      if (e.p.abgeschlossen && t.datum > addDays(e.von, e.p.ue * 7)) continue;
      const r = rnd();
      const neu = t.datum >= addDays(heute, -10); // letzte Tage: einzelne Unterschriften fehlen noch
      try {
        if (r < 0.08) { await A('POST', `/api/termine/${t.id}/anwesenheit`, { patientId: e.patientId, wahrgenommen: false, fehlGrund: ['Krank', 'Urlaub', 'Arzttermin'][Math.floor(rnd() * 3)] }); continue; }
        if (neu && r > 0.9) { await A('POST', `/api/termine/${t.id}/anwesenheit`, { patientId: e.patientId, wahrgenommen: true }); fehlend++; continue; }
        await A('POST', `/api/termine/${t.id}/anwesenheit`, r > 0.95 ? { patientId: e.patientId, wahrgenommen: true, unterschriftPapier: true } : { patientId: e.patientId, wahrgenommen: true, unterschriftPng: signaturPng(e.idx + 1) });
        sig++;
      } catch (err) { console.error('Anwesenheit:', err.message); }
    }
  }
  // Leitungsbestätigung (außer jeweils jüngster Termin je Gruppe)
  const letzte = new Map();
  for (const t of termine.filter((x) => x.datum < heute)) { if (!letzte.has(t.kursId) || t.datum > letzte.get(t.kursId)) letzte.set(t.kursId, t.datum); }
  let best = 0;
  for (const t of termine.filter((x) => x.datum < heute && x.datum !== letzte.get(x.kursId))) {
    const k = KURSE.find((kk) => kurse[kk.key].id === t.kursId);
    const tr = trainer[k.t];
    const texte = DOKU[k.art];
    try {
      await A('PUT', `/api/termine/${t.id}`, { leiterBestaetigung: { name: `${tr.vorname} ${tr.nachname}`, unterschriftPng: SIG_LEITUNG }, dokumentation: texte[Math.floor(rnd() * texte.length)] });
      best++;
    } catch (err) { console.error('Leiter:', err.message); }
  }
  // Abbrüche
  for (const e of eintraege.filter((x) => x.p.abbruch)) {
    await A('POST', `/api/verordnungen/${e.vid}/abbruch`, { grund: e.p.abbruch.grund, datum: abbruchDatum(e) });
  }

  // Fertig erbrachte Verordnung als abgerechnet markieren
  for (const e of eintraege.filter((x) => x.p.abgeschlossen)) {
    await A('POST', `/api/verordnungen/${e.vid}/abrechnung`, { satzQuelle: 'Vorgabe (Einstellungen)', rechnungsNr: 'RS-2026-0001', abrechnen: true });
  }

  /* --- Exportieren --- */
  const exp = await A('GET', '/api/export');
  const db = JSON.parse(exp.json);
  db.outbox = (db.outbox || []).slice(-6); // Postfach nicht überfrachten
  const out = process.argv[2] || path.join(process.cwd(), 'rheasport-demo-backup.json');
  fs.writeFileSync(out, JSON.stringify(db));
  const st = await A('GET', '/api/state');
  const count = (s) => st.verordnungen.filter((v) => v.status === s).length;
  console.log(`Trainer ${st.trainer.length} | Kurse ${st.kurse.length} | Patienten ${st.patienten.length} | Verordnungen ${st.verordnungen.length} (aktiv ${count('aktiv')}, abgebrochen ${count('abgebrochen')}, abgerechnet ${count('abgerechnet')}, entwurf ${st.verordnungen.filter((v) => !['aktiv', 'abgebrochen', 'abgeschlossen'].includes(v.status)).length})`);
  console.log(`Unterschriften ${sig}, bewusst offen ${fehlend}, Leitungsbestätigungen ${best} | Datei ${out} (${Math.round(fs.statSync(out).size / 1024)} KB)`);
})().catch((e) => { console.error('FEHLER:', e); process.exit(1); });
