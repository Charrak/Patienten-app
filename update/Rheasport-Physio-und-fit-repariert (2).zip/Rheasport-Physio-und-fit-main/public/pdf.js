/* RheaPdf – erzeugt aus einem HTML-Dokument (Druckansicht) eine mehrseitige A4-PDF, ganz ohne Zusatzbibliothek.
 * Jede Seite wird als Bild (JPEG) in die PDF eingebettet; Seitenumbrüche liegen zwischen Tabellenzeilen/Absätzen.
 * Damit funktioniert Drucken/Teilen auch dort, wo window.print() fehlt (Android-WebView). */
(function () {
  const W = 794, H = 1123, M = 30; // A4 bei 96 dpi, Seitenrand in px
  const CONTENT_H = H - 2 * M;
  // Gleiche Grundeinstellungen beim Messen und beim Zeichnen (sonst weichen Zeilenhöhen der App von denen im Bild ab)
  const BASIS = 'background:#fff;color:#000;margin:0;padding:0;font:16px/normal Arial,Helvetica,sans-serif;letter-spacing:normal;word-spacing:normal;text-transform:none;text-align:left;box-sizing:content-box';

  async function bildGeladen(host) {
    const imgs = [...host.querySelectorAll('img')];
    await Promise.all(imgs.map((i) => (i.complete && i.naturalWidth ? Promise.resolve() : new Promise((res) => { i.onload = i.onerror = res; }))));
  }
  const canvasZuJpeg = (c, q) => new Promise((res, rej) => c.toBlob((b) => (b ? b.arrayBuffer().then((x) => res(new Uint8Array(x))) : rej(new Error('Seite konnte nicht erzeugt werden.'))), 'image/jpeg', q));

  /** PDF aus JPEG-Seiten zusammensetzen (A4, Bild füllt die Seite). */
  function pdfBauen(jpegs) {
    const enc = new TextEncoder();
    const teile = [];
    const offsets = [];
    let pos = 0;
    const push = (x) => { const u = typeof x === 'string' ? enc.encode(x) : x; teile.push(u); pos += u.length; };
    const obj = (n, inhalt) => { offsets[n] = pos; push(`${n} 0 obj\n`); push(inhalt); push('\nendobj\n'); };
    const n = jpegs.length;
    push('%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n');
    obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
    obj(2, `<< /Type /Pages /Count ${n} /Kids [${jpegs.map((_, i) => `${3 + i * 3} 0 R`).join(' ')}] >>`);
    jpegs.forEach((j, i) => {
      const p = 3 + i * 3, c = p + 1, im = p + 2;
      obj(p, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im0 ${im} 0 R >> >> /Contents ${c} 0 R >>`);
      const inh = 'q 595.28 0 0 841.89 0 0 cm /Im0 Do Q';
      obj(c, `<< /Length ${inh.length} >>\nstream\n${inh}\nendstream`);
      offsets[im] = pos;
      push(`${im} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${j.breite} /Height ${j.hoehe} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${j.daten.length} >>\nstream\n`);
      push(j.daten); push('\nendstream\nendobj\n');
    });
    const xref = pos;
    const max = 2 + n * 3;
    push(`xref\n0 ${max + 1}\n0000000000 65535 f \n`);
    for (let i = 1; i <= max; i++) push(`${String(offsets[i]).padStart(10, '0')} 00000 n \n`);
    push(`trailer\n<< /Size ${max + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
    const out = new Uint8Array(pos);
    let o = 0; for (const t of teile) { out.set(t, o); o += t.length; }
    return new Blob([out], { type: 'application/pdf' });
  }

  /** Zeilen-Analyse eines gerenderten Fensters (Pixel): wo ist Tinte, wo Seitenumbruch-Markierung (Magenta), wo eine volle Tabellenlinie. */
  function zeilenAnalyse(ctx, breite, hoehe) {
    const d = ctx.getImageData(0, 0, breite, hoehe).data;
    const ink = new Float32Array(hoehe), marker = new Uint8Array(hoehe);
    for (let y = 0; y < hoehe; y++) {
      let n = 0, m = 0, tot = 0;
      for (let x = 0; x < breite; x += 3) {
        const i = (y * breite + x) * 4, r = d[i], g = d[i + 1], bl = d[i + 2];
        tot++;
        if (r > 200 && g < 90 && bl > 200) m++;
        else if (r < 225 || g < 225 || bl < 225) n++;
      }
      ink[y] = n / tot; marker[y] = m / tot > 0.8 ? 1 : 0;
    }
    return { ink, marker };
  }

  /** html: String mit <style> und Inhalt. onProgress(i, n) optional. */
  async function htmlZuPdf(html, onProgress) {
    const host = document.createElement('div');
    host.style.cssText = `position:absolute;left:-12000px;top:0;width:${W}px;${BASIS}`;
    host.innerHTML = html;
    document.body.appendChild(host);
    try {
      await bildGeladen(host);
      await new Promise((r) => requestAnimationFrame(() => r()));
      const gesamt = Math.ceil(host.scrollHeight * 1.35) + 240; // großzügige Obergrenze; das tatsächliche Ende wird im Bild erkannt
      const kopie = host.cloneNode(true);
      kopie.style.cssText = `width:${W}px;${BASIS}`;
      // erzwungene Seitenumbrüche (page-break-before) als Magenta-Streifen markieren; sie werden im Bild wiedererkannt
      kopie.querySelectorAll('[style*="page-break-before"]').forEach((e) => { if (/always|page/.test(e.style.pageBreakBefore || '')) { e.style.cssText = 'height:4px;background:#ff00ff;margin:0;padding:0'; e.setAttribute('data-umbruch', '1'); } });
      const xhtml = new XMLSerializer().serializeToString(kopie);
      const scale = 1.6, pw = Math.round(W * scale);
      const fenster = CONTENT_H + 70;
      const jpegs = [];
      let start = 0, seite = 0;
      while (start < gesamt && seite < 200) {
        seite++;
        if (onProgress) onProgress(seite, Math.max(seite, Math.ceil(gesamt / CONTENT_H)));
        const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${fenster}" viewBox="0 0 ${W} ${fenster}"><rect width="${W}" height="${fenster}" fill="#fff"/>`
          + `<foreignObject x="0" y="${-start}" width="${W}" height="${gesamt + 40}">${xhtml}</foreignObject></svg>`;
        const img = await new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('Seite konnte nicht gezeichnet werden.')); im.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`; });
        const win = document.createElement('canvas');
        win.width = pw; win.height = Math.round(fenster * scale);
        const wctx = win.getContext('2d', { willReadFrequently: true });
        wctx.fillStyle = '#fff'; wctx.fillRect(0, 0, win.width, win.height);
        wctx.drawImage(img, 0, 0, win.width, win.height);
        const { ink, marker } = zeilenAnalyse(wctx, win.width, win.height);
        const px = (y) => Math.round(y * scale);
        // Ende des sichtbaren Inhalts im Fenster
        let letzte = -1; for (let y = win.height - 1; y >= 0; y--) { if (ink[y] > 0.004 || marker[y]) { letzte = y; break; } }
        if (letzte < 0) break; // nichts mehr
        let schnitt, naechster;
        const m = (() => { for (let y = 8; y < px(fenster); y++) if (marker[y]) return y; return -1; })();
        if (m > 0 && m <= px(CONTENT_H) + 4) { schnitt = Math.max(1, m - 3); let e = m; while (e < win.height && marker[e]) e++; naechster = start + Math.round(e / scale); }
        else if (letzte < px(CONTENT_H) - 2) { schnitt = Math.min(win.height, letzte + px(14)); naechster = gesamt; } // letzte Seite
        else {
          schnitt = px(CONTENT_H); // Standard: harter Schnitt
          for (let y = px(CONTENT_H); y > px(CONTENT_H * 0.55); y--) {
            if (ink[y] < 0.004 && ink[y - 1] < 0.004) { schnitt = y; break; }       // leere Zeile zwischen Textzeilen/Zeilen
            if (ink[y - 1] > 0.6 && ink[y] < 0.9 && ink[y] > 0.0) { schnitt = y; break; }     // Tabellenlinie: direkt darunter schneiden
          }
          naechster = start + Math.round(schnitt / scale);
        }
        if (window.RHEA_PDF_DEBUG) console.log('PDF-Seite', seite, { start, gesamt, schnitt: Math.round(schnitt / scale), letzte: Math.round(letzte / scale), naechster });
        const out = document.createElement('canvas');
        out.width = pw; out.height = Math.round(H * scale);
        const octx = out.getContext('2d');
        octx.fillStyle = '#fff'; octx.fillRect(0, 0, out.width, out.height);
        octx.drawImage(win, 0, 0, pw, schnitt, 0, px(M), pw, schnitt);
        jpegs.push({ daten: await canvasZuJpeg(out, 0.86), breite: out.width, hoehe: out.height });
        start = naechster;
      }
      if (!jpegs.length) throw new Error('Leeres Dokument.');
      return pdfBauen(jpegs);
    } finally { host.remove(); }
  }

  window.RheaPdf = { htmlZuPdf };
})();
