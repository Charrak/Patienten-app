/**
 * RheaSport – Physio & fit
 * Lokaler Verwaltungsserver für Rehabilitationssport/Funktionstraining
 * (RSD-Regelwerk: Rahmenvereinbarung BAR, Muster 56, DSGVO – Daten bleiben lokal!)
 */
const express = require('express');
const path = require('path');
const QRCode = require('qrcode');
const db = require('./lib/db');
const mail = require('./lib/mail');
const rules = require('./lib/rules');
const ics = require('./lib/ical');

const app = express();
const PORT = process.env.PORT || 8080;
const APP_TOKEN = process.env.APP_TOKEN || '';

app.use(express.json({ limit: '12mb' }));

// Optionaler Zugriffsschutz über Umgebungsvariable APP_TOKEN
app.use((req, res, next) => {
  if (!APP_TOKEN) return next();
  const t = req.query.t || req.get('x-app-token') || '';
  if (t === APP_TOKEN) return next();
  res.status(401).json({ fehler: 'Zugriffsschutz aktiv – ungültiges Token (APP_TOKEN).' });
});

const fmt = mail.formatDatum;
const heutigesDatum = () => new Date().toISOString().slice(0, 10);

function ok(res, daten) { res.json({ ok: true, ...daten }); }
function fehler(res, msg, code = 400) { res.status(code).json({ ok: false, fehler: msg }); }

function cleanSettings(s) {
  const k = JSON.parse(JSON.stringify(s));
  if (k.smtp) k.smtp.pass = k.smtp.pass ? '••••••' : '';
  return k;
}

/* ------------------------------ Parser für Verordnungs-Codes ------------------------------ */

function zuDatum(iso) { const d = new Date(`${iso}T00:00:00`); return Number.isNaN(d.getTime()) ? null : d; }

const CODE_ALIASE = {
  n: 'name', name: 'name', vn: 'name',
  g: 'geburtsdatum', geb: 'geburtsdatum', geburtsdatum: 'geburtsdatum', dob: 'geburtsdatum',
  kk: 'kostentraeger', kostentraeger: 'kostentraeger', kv: 'kostentraeger',
  vs: 'versichertenNr', vsnr: 'versichertenNr', versichertenNr: 'versichertenNr', ik: 'ikDesKostentraegers',
  von: 'von', beginn: 'von', bis: 'bis', ende: 'bis',
  art: 'art', ma: 'art',
  f: 'frequenzProWoche', freq: 'frequenzProWoche', frequenz: 'frequenzProWoche',
  ue: 'uebungseinheiten', uee: 'uebungseinheiten', uebungseinheiten: 'uebungseinheiten',
  icd: 'icd10', icd10: 'icd10',
  z: 'ziele', ziele: 'ziele',
  arzt: 'arztName', arztname: 'arztName',
  ft: 'formular', formular: 'formular',
  kt: 'kostentraegerArt',
  ku: 'kostenuebernahme', kostenuebernahme: 'kostenuebernahme',
  folge: 'folgeverordnung', folgev: 'folgeverordnung',
  email: 'email', mail: 'email',
  tel: 'telefon', telefon: 'telefon',
  aus: 'ausstellungsdatum', ausstellung: 'ausstellungsdatum',
  b: 'baustein',
  diag: 'icd10',
};

const ART_ALIASE = {
  rs: 'rs', rehasport: 'rs', trocken: 'rs', 'trockengymnastik': 'rs',
  wasser: 'rsWasser', rsWasser: 'rsWasser', 'rs-wasser': 'rsWasser', wassergymnastik: 'rsWasser',
  kinder: 'rsKinder', rsKinder: 'rsKinder', 'rs-kinder': 'rsKinder',
  schwerst: 'rsSchwerstbehindert', rsSchwerstbehindert: 'rsSchwerstbehindert',
  herz: 'herzgruppe', herzgruppe: 'herzgruppe', herzsport: 'herzgruppe', 'herz-gruppe': 'herzgruppe',
  hi: 'herzinsuffizienz', herzinsuffizienz: 'herzinsuffizienz', 'herzinsuffizienzgruppe': 'herzinsuffizienz',
  ft: 'funktionstraining', funktionstraining: 'funktionstraining',
  gb: 'gesundheitsbildung', gesundheitsbildung: 'gesundheitsbildung',
};

function normalisiereRoh(roh) {
  const o = {};
  for (const [k, v] of Object.entries(roh || {})) {
    const key = CODE_ALIASE[String(k).toLowerCase()] || k;
    o[key] = v;
  }
  if (o.art) {
    const a = String(o.art).trim().toLowerCase();
    o.art = ART_ALIASE[a] || ART_ALIASE[String(o.art).trim()] || o.art;
    if (!rules.ARTEN[o.art]) o.art = 'rs';
  }
  if (typeof o.icd10 === 'string') o.icd10 = o.icd10.split(/[;,|]/).map((s) => s.trim()).filter(Boolean);
  if (typeof o.frequenzProWoche === 'string') o.frequenzProWoche = parseInt(o.frequenzProWoche, 10) || 1;
  if (typeof o.uebungseinheiten === 'string') o.uebungseinheiten = parseInt(o.uebungseinheiten, 10) || 0;
  if (o.folgeverordnung !== undefined) o.folgeverordnung = o.folgeverordnung === true || o.folgeverordnung === '1' || o.folgeverordnung === 'true' || o.folgeverordnung === 'ja';
  if (o.kostenuebernahme) {
    o.kostenuebernahme = typeof o.kostenuebernahme === 'object'
      ? { liegtVor: o.kostenuebernahme.liegtVor !== false, datum: o.kostenuebernahme.datum || heutigesDatum(), zeitraum: o.kostenuebernahme.zeitraum || '' }
      : { liegtVor: true, datum: String(o.kostenuebernahme), zeitraum: '' };
  }
  return o;
}

/** QR-/Code-Inhalt -> Verordnungsdaten (JSON, URL-Parameter, RS56-Kurzformat) */
function parseVerordnungsCode(rohText) {
  const roh = String(rohText || '').trim();
  if (!roh) return { quelltext: roh, daten: null, format: 'leer' };
  // 1) JSON
  if (roh.startsWith('{')) {
    try { return { quelltext: roh, daten: normalisiereRoh(JSON.parse(roh)), format: 'json' }; } catch (_) { /* weiter */ }
  }
  // 2) URL mit Query-Parametern
  if (/^https?:\/\//i.test(roh)) {
    try {
      const u = new URL(roh);
      const obj = {};
      u.searchParams.forEach((v, k) => { obj[k] = v; });
      if (u.pathname.includes('/verordnung/')) obj.id = u.pathname.split('/').pop();
      return { quelltext: roh, daten: normalisiereRoh(obj), format: 'url' };
    } catch (_) { /* weiter */ }
  }
  // 3) RS56|... Kurzformat
  if (roh.toUpperCase().startsWith('RS56')) {
    const teile = roh.split('|').map((s) => s.trim());
    const felder = ['kennung', 'name', 'geburtsdatum', 'kostentraeger', 'versichertenNr', 'von', 'bis', 'art', 'frequenzProWoche', 'uebungseinheiten', 'icd10', 'arztName'];
    const obj = {};
    felder.forEach((f, i) => { if (teile[i] !== undefined && i > 0) obj[f] = teile[i]; });
    return { quelltext: roh, daten: normalisiereRoh(obj), format: 'rs56' };
  }
  // 4) nicht erkannt -> Rohtext mitführen, Felder manuell im Datenabgleich
  return { quelltext: roh, daten: null, format: 'unbekannt' };
}

/* ------------------------------ Termine materialisieren ------------------------------ */

function materialisiereKurs(kurs, bisDatumIso) {
  const d = db.laden();
  const bis = zuDatum(bisDatumIso) || new Date(Date.now() + 90 * 86400000);
  const start = zuDatum(kurs.startdatum);
  if (!start || !kurs.wochentag) return 0;
  const vorhanden = new Set(d.termine.filter((t) => t.kursId === kurs.id).map((t) => t.datum));
  let neu = 0;
  const [h, m] = String(kurs.beginn || '00:00').split(':').map(Number);
  for (const c = new Date(start); c <= bis; c.setDate(c.getDate() + 1)) {
    if (c.getDay() !== Number(kurs.wochentag)) continue;
    const iso = `${c.getFullYear()}-${String(c.getMonth() + 1).padStart(2, '0')}-${String(c.getDate()).padStart(2, '0')}`;
    if (kurs.enddatum && iso > kurs.enddatum) break;
    if (vorhanden.has(iso)) continue;
    d.termine.push({
      id: db.id('t'), kursId: kurs.id, datum: iso,
      beginn: kurs.beginn || `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`,
      dauerMin: Number(kurs.dauerMin) || 45,
      status: 'geplant', dokumentation: '', anwesenheit: [],
      leiterBestaetigung: null, arztvisitation: null,
    });
    vorhanden.add(iso); neu++;
  }
  if (neu) db.speichern();
  return neu;
}

function materialisiereAlle(bisIso) {
  const d = db.laden();
  for (const k of d.kurse.filter((k) => k.aktiv)) materialisiereKurs(k, bisIso);
}

function kursInfo(kursId) {
  const d = db.laden();
  const k = d.kurse.find((x) => x.id === kursId);
  if (!k) return null;
  const t = d.trainer.find((x) => x.id === k.trainerId);
  return { ...k, trainerName: t ? `${t.vorname} ${t.nachname}` : '–' };
}

function termineFuerPatient(patientId, wochen = 12) {
  const d = db.laden();
  const kursIds = d.zuordnungen.filter((z) => z.patientId === patientId && z.aktiv !== false).map((z) => z.kursId);
  const heuteIso = heutigesDatum();
  const ziel = new Date(Date.now() + wochen * 7 * 86400000).toISOString().slice(0, 10);
  const liste = [];
  for (const kid of kursIds) {
    const k = d.kurse.find((x) => x.id === kid);
    if (k) materialisiereKurs(k, ziel);
  }
  for (const t of d.termine) {
    if (!kursIds.includes(t.kursId)) continue;
    if (t.datum < heuteIso || t.datum > ziel) continue;
    if (t.status === 'ausgefallen') continue;
    const k = kursInfo(t.kursId);
    liste.push({ ...t, kursTitel: k ? k.titel : '', ort: k ? k.ort : '' });
  }
  liste.sort((a, b) => (a.datum + a.beginn).localeCompare(b.datum + b.beginn));
  return liste;
}

/* ------------------------------ E-Mails ------------------------------ */

async function sendeTermineMail(patient, verordnung) {
  const d = db.laden();
  const termine = termineFuerPatient(patient.id, 8).map((t) => ({ ...t, kursTitel: t.kursTitel }));
  if (!verordnung) {
    return mail.sende({
      typ: 'patient-termine', an: patient.email, patientId: patient.id,
      betreff: `Ihre Rehasport-Termine – ${d.settings.anbieter.name}`,
      text: 'Bitte weisen Sie zuerst eine Verordnung zu, damit Termine versendet werden können.',
      html: '<p>Bitte weisen Sie zuerst eine Verordnung zu.</p>',
    });
  }
  const m = mail.mailTermine(patient, verordnung, termine, { anbieter: d.settings.anbieter });
  return mail.sende({ typ: 'patient-termine', an: patient.email, betreff: m.betreff, text: m.text, html: m.html, patientId: patient.id, verordnungId: verordnung.id });
}

async function sendeVollstaendigMail(v, patient, pruefung, zuweisung) {
  const d = db.laden();
  const empfaenger = (d.settings.fuehrungspersonal || []).map((f) => f.email).filter(Boolean);
  if (!empfaenger.length) {
    return mail.sende({
      typ: 'verordnung-vollstaendig', an: d.settings.anbieter.email || '–', betreff: `(Kein Empfänger hinterlegt) ${patient.nachname}: Verordnung vollständig`,
      text: 'Bitte in den Einstellungen E-Mail-Adressen des Führungspersonals hinterlegen.', html: '<p>Keine Empfänger im Führungspersonal hinterlegt.</p>',
      patientId: patient.id, verordnungId: v.id,
    });
  }
  const m = mail.mailVerordnungVollstaendig(v, patient, pruefung, zuweisung, { anbieter: d.settings.anbieter, appUrl: '' });
  return mail.sende({ typ: 'verordnung-vollstaendig', an: empfaenger, betreff: m.betreff, text: m.text, html: m.html, patientId: patient.id, verordnungId: v.id });
}

/* ------------------------------ State / Dashboard ------------------------------ */

function berechneErbrachteUee(verordnung) {
  const d = db.laden();
  const kid = d.zuordnungen.filter((z) => z.verordnungId === verordnung.id && z.aktiv !== false).map((z) => z.kursId);
  let n = 0;
  const tage = [];
  for (const t of d.termine) {
    if (!kid.includes(t.kursId)) continue;
    if (t.status !== 'stattgefunden') continue;
    if (!t.leiterBestaetigung) continue;
    const a = (t.anwesenheit || []).find((x) => x.patientId === verordnung.patientId);
    if (a && a.wahrgenommen && (a.unterschriftPng || a.unterschriftPapier)) { n++; tage.push(t.datum); }
  }
  return { uee: n, tage: tage.sort() };
}

function dashboard() {
  const d = db.laden();
  const heuteIso = heutigesDatum();
  materialisiereAlle(new Date(Date.now() + 60 * 86400000).toISOString().slice(0, 10));

  const offeneAbgleiche = d.verordnungen.filter((v) => v.status === 'abgleich');
  const aktive = d.verordnungen.filter((v) => v.status === 'aktiv' || v.status === 'vollstaendig');
  const termineHeute = d.termine.filter((t) => t.datum === heuteIso && t.status !== 'ausgefallen');
  const ausstehendSignatur = [];
  for (const t of termineHeute) {
    const k = kursInfo(t.kursId);
    if (!k) continue;
    const zuordnen = d.zuordnungen.filter((z) => z.kursId === t.kursId && z.aktiv !== false);
    for (const z of zuordnen) {
      const a = (t.anwesenheit || []).find((x) => x.patientId === z.patientId);
      if (!a || !(a.unterschriftPng || a.unterschriftPapier)) {
        const p = d.patienten.find((x) => x.id === z.patientId);
        if (p) ausstehendSignatur.push({ terminId: t.id, patient: `${p.nachname}, ${p.vorname}`, kurs: k.titel, datum: t.datum });
      }
    }
  }
  const jetzt = new Date();
  const zertifikatWarnungen = d.trainer.filter((t) => t.aktiv && t.zertifikateBis && zuDatum(t.zertifikateBis) && (zuDatum(t.zertifikateBis) - jetzt) / 86400000 < 90)
    .map((t) => ({ trainer: `${t.vorname} ${t.nachname}`, bis: t.zertifikateBis }));
  const herzKurse = d.kurse.filter((k) => k.aktiv && (k.art === 'herzgruppe' || k.art === 'herzinsuffizienz'));
  const visitationWarnungen = [];
  for (const k of herzKurse) {
    let letzte = d.termine.filter((t) => t.kursId === k.id && t.arztvisitation).map((t) => t.arztvisitation.datum).sort().pop();
    const kursFeld = k.betreuungsArzt && k.betreuungsArzt.visitationAm;
    if (kursFeld && (!letzte || kursFeld > letzte)) letzte = kursFeld;
    if (!letzte || (jetzt - zuDatum(letzte)) / 86400000 > 42) {
      visitationWarnungen.push({ kurs: k.titel, letzte: letzte || 'nie', noetig: true });
    } else if ((jetzt - zuDatum(letzte)) / 86400000 > 28) {
      visitationWarnungen.push({ kurs: k.titel, letzte, noetig: false });
    }
  }
  const abrechnungBereit = [];
  for (const v of [...aktive]) {
    const { uee } = berechneErbrachteUee(v);
    if (uee >= (v.uebungseinheiten || 0) || (v.bis && v.bis < heuteIso && uee > 0)) abrechnungBereit.push({ id: v.id, uee });
  }
  const hf = rules.HILFSFRISTEN[d.settings.bundesland || 'NW'];
  return {
    zaehler: {
      patienten: d.patienten.length, trainer: d.trainer.filter((t) => t.aktiv).length,
      kurse: d.kurse.filter((k) => k.aktiv).length,
      aktiveVerordnungen: aktive.length, offeneAbgleiche: offeneAbgleiche.length,
      termineHeute: termineHeute.length, abrechnungBereit: abrechnungBereit.length,
      signaturenOffen: ausstehendSignatur.length,
    },
    offeneAbgleiche: offeneAbgleiche.map((v) => ({ id: v.id, name: v.name || v.patientId, von: v.von })),
    termineHeute: termineHeute.map((t) => ({ ...t, kurs: (kursInfo(t.kursId) || {}).titel })),
    ausstehendSignatur: ausstehendSignatur.slice(0, 20),
    zertifikatWarnungen, visitationWarnungen, abrechnungBereit,
    hilfsfrist: { text: hf.text, bundesland: d.settings.bundesland || 'NW', laendlich: Boolean(d.settings.ortLändlich) },
    smtp: mail.smtpKonfiguriert(d.settings),
  };
}

/* ================================ Routen ================================ */

app.get('/api/state', (req, res) => {
  const d = db.laden();
  ok(res, {
    settings: cleanSettings(d.settings),
    trainer: d.trainer, patienten: d.patienten, verordnungen: d.verordnungen,
    kurse: d.kurse, termine: d.termine, zuordnungen: d.zuordnungen,
    outbox: d.outbox, audit: d.audit.slice(0, 200),
    regeln: {
      arten: rules.ARTEN, qualifikationen: rules.QUALIFIKATIONEN,
      notfallqualifikationen: rules.NOTFALLQUALIFIKATIONEN, bundeslaender: rules.BUNDESLAENDER,
      hilfsfristen: rules.HILFSFRISTEN, diag120: rules.DIAGNOSEN_120.map((x) => x.label),
    },
    kursPruefungen: Object.fromEntries(d.kurse.map((k) => [
      k.id,
      rules.pruefeKurs(k, d.trainer.find((t) => t.id === k.trainerId), { bundesland: d.settings.bundesland }),
    ])),
    mailKonfiguriert: mail.smtpKonfiguriert(d.settings),
  });
});

app.get('/api/dashboard', (req, res) => ok(res, { dashboard: dashboard() }));

app.put('/api/settings', (req, res) => {
  const d = db.laden();
  const b = req.body || {};
  if (b.anbieter) d.settings.anbieter = { ...d.settings.anbieter, ...b.anbieter };
  if (b.smtp) {
    const pass = b.smtp.pass === '••••••' ? d.settings.smtp.pass : b.smtp.pass;
    d.settings.smtp = { ...d.settings.smtp, ...b.smtp, pass };
  }
  if (b.fuehrungspersonal) d.settings.fuehrungspersonal = b.fuehrungspersonal;
  if (b.datenschutz) d.settings.datenschutz = { ...d.settings.datenschutz, ...b.datenschutz };
  if (b.kalender) d.settings.kalender = { ...d.settings.kalender, ...b.kalender };
  if (b.abrechnung) d.settings.abrechnung = { ...d.settings.abrechnung, ...b.abrechnung };
  if (b.bundesland) d.settings.bundesland = b.bundesland;
  if (b.ortLändlich !== undefined) d.settings.ortLändlich = Boolean(b.ortLändlich);
  db.speichern(); db.audit('einstellungen-geaendert', { keys: Object.keys(b) });
  ok(res, { settings: cleanSettings(d.settings) });
});

/* ---------------- Trainer ---------------- */
app.post('/api/trainer', (req, res) => {
  const d = db.laden();
  const b = req.body || {};
  if (!b.vorname || !b.nachname) return fehler(res, 'Vor- und Nachname sind erforderlich.');
  const t = {
    id: db.id('tr'), vorname: b.vorname, nachname: b.nachname,
    email: b.email || '', telefon: b.telefon || '',
    qualifikationen: b.qualifikationen || ['uebungsleiter'],
    zertifikateBis: b.zertifikateBis || '', zertifikatHerzBis: b.zertifikatHerzBis || '',
    notfallqualifikation: b.notfallqualifikation || 'keine',
    notfallGueltigBis: b.notfallGueltigBis || '',
    barAnerkennung: b.barAnerkennung || 'anerkannt',
    rsdMitglied: Boolean(b.rsdMitglied),
    verschwiegenheit: b.verchwiegenheit || b.verchwiegenheitDatum || '',
    datenschutzBelehrung: b.datenschutzBelehrung || '',
    bemerkung: b.bemerkung || '', aktiv: b.aktiv !== false, angelegtAm: new Date().toISOString(),
  };
  d.trainer.push(t); db.speichern(); db.audit('trainer-angelegt', { id: t.id, name: `${t.vorname} ${t.nachname}` });
  ok(res, { trainer: t });
});

app.put('/api/trainer/:id', (req, res) => {
  const d = db.laden();
  const t = d.trainer.find((x) => x.id === req.params.id);
  if (!t) return fehler(res, 'Trainer nicht gefunden.', 404);
  const b = req.body || {};
  Object.assign(t, b, { id: t.id });
  db.speichern(); db.audit('trainer-geaendert', { id: t.id, keys: Object.keys(b) });
  ok(res, { trainer: t });
});

app.delete('/api/trainer/:id', (req, res) => {
  const d = db.laden();
  const t = d.trainer.find((x) => x.id === req.params.id);
  if (!t) return fehler(res, 'Trainer nicht gefunden.', 404);
  const genutzt = d.kurse.some((k) => k.trainerId === t.id);
  if (genutzt) { t.aktiv = false; db.speichern(); db.audit('trainer-deaktiviert', { id: t.id }); return ok(res, { deaktiviert: true }); }
  d.trainer = d.trainer.filter((x) => x.id !== t.id);
  db.speichern(); db.audit('trainer-geloescht', { id: t.id });
  ok(res, {});
});

/* ---------------- Kurse ---------------- */
app.post('/api/kurse', (req, res) => {
  const d = db.laden();
  const b = req.body || {};
  if (!b.titel || !b.art || !b.trainerId || !b.wochentag || !b.beginn || !b.startdatum) {
    return fehler(res, 'Titel, Art, Übungsleitung, Wochentag, Beginn und Startdatum sind erforderlich.');
  }
  const k = {
    id: db.id('k'), titel: b.titel, art: b.art, trainerId: b.trainerId,
    ort: b.ort || '', raumflaecheQm: Number(b.raumflaecheQm) || 0,
    wochentag: Number(b.wochentag), beginn: b.beginn, dauerMin: Number(b.dauerMin) || rules.ARTEN[b.art].minDauerMin,
    maxTeilnehmer: Number(b.maxTeilnehmer) || rules.ARTEN[b.art].maxTN,
    startdatum: b.startdatum, enddatum: b.enddatum || '',
    betreuungsArzt: b.betreuungsArzt || null,
    notfallplan: Boolean(b.notfallplan), aed: b.aed || { vorhanden: false, wartungAm: '' },
    notfallkoffer: Boolean(b.notfallkoffer), notfallUebungAm: b.notfallUebungAm || '',
    technischeGeraete: Boolean(b.technischeGeraete), ergometer: Boolean(b.ergometer),
    gemischtMitPraevention: Boolean(b.gemischtMitPraevention), zusatzleistungGleichzeitig: Boolean(b.zusatzleistungGleichzeitig),
    bemerkung: b.bemerkung || '', aktiv: true, angelegtAm: new Date().toISOString(),
  };
  const trainer = d.trainer.find((x) => x.id === k.trainerId);
  const pr = rules.pruefeKurs(k, trainer, { bundesland: d.settings.bundesland });
  d.kurse.push(k);
  if (!pr.blockiert) materialisiereKurs(k, new Date(Date.now() + 90 * 86400000).toISOString().slice(0, 10));
  db.speichern(); db.audit('kurs-angelegt', { id: k.id, titel: k.titel, fehler: pr.fehler });
  ok(res, { kurs: k, pruefung: pr });
});

app.put('/api/kurse/:id', (req, res) => {
  const d = db.laden();
  const k = d.kurse.find((x) => x.id === req.params.id);
  if (!k) return fehler(res, 'Kurs nicht gefunden.', 404);
  const b = req.body || {};
  const alt = { ...k };
  Object.assign(k, b, { id: k.id, art: b.art || k.art });
  if (k.dauerMin && !b.dauerMin) k.dauerMin = Number(k.dauerMin);
  const trainer = d.trainer.find((x) => x.id === k.trainerId);
  const pr = rules.pruefeKurs(k, trainer, { bundesland: d.settings.bundesland });
  if (!pr.blockiert && k.aktiv) materialisiereKurs(k, new Date(Date.now() + 90 * 86400000).toISOString().slice(0, 10));
  db.speichern(); db.audit('kurs-geaendert', { id: k.id, von: { wochentag: alt.wochentag, beginn: alt.beginn, startdatum: alt.startdatum } });
  ok(res, { kurs: k, pruefung: pr });
});

app.delete('/api/kurse/:id', (req, res) => {
  const d = db.laden();
  const k = d.kurse.find((x) => x.id === req.params.id);
  if (!k) return fehler(res, 'Kurs nicht gefunden.', 404);
  const belegt = d.zuordnungen.some((z) => z.kursId === k.id && z.aktiv !== false);
  if (belegt) { k.aktiv = false; db.speichern(); db.audit('kurs-deaktiviert', { id: k.id }); return ok(res, { deaktiviert: true }); }
  d.kurse = d.kurse.filter((x) => x.id !== k.id);
  d.termine = d.termine.filter((t) => t.kursId !== k.id);
  db.speichern(); db.audit('kurs-geloescht', { id: k.id });
  ok(res, {});
});

/* ---------------- Patienten ---------------- */
app.post('/api/patienten', (req, res) => {
  const d = db.laden();
  const b = req.body || {};
  if (!b.vorname || !b.nachname || !b.geburtsdatum) return fehler(res, 'Vorname, Nachname und Geburtsdatum sind erforderlich.');
  const dup = d.patienten.find((p) => p.nachname.toLowerCase() === b.nachname.toLowerCase() && p.vorname.toLowerCase() === b.vorname.toLowerCase() && p.geburtsdatum === b.geburtsdatum);
  if (dup) return fehler(res, `Patient/in existiert bereits (ID ${dup.id}).`);
  const p = {
    id: db.id('p'), vorname: b.vorname, nachname: b.nachname, geburtsdatum: b.geburtsdatum,
    geschlecht: b.geschlecht || '', strasse: b.strasse || '', plz: b.plz || '', ort: b.ort || '',
    email: b.email || '', telefon: b.telefon || '',
    einwilligung: b.einwilligung || null, bemerkung: b.bemerkung || '',
    angelegtAm: new Date().toISOString(),
  };
  d.patienten.push(p); db.speichern(); db.audit('patient-angelegt', { id: p.id, name: `${p.nachname}, ${p.vorname}` }, 'rezeption');
  ok(res, { patient: p });
});

app.put('/api/patienten/:id', (req, res) => {
  const d = db.laden();
  const p = d.patienten.find((x) => x.id === req.params.id);
  if (!p) return fehler(res, 'Patient nicht gefunden.', 404);
  const b = req.body || {};
  if (b.einwilligung) {
    p.einwilligung = b.einwilligung;
    db.audit('einwilligung-dokumentiert', { patientId: p.id }, 'rezeption');
    delete b.einwilligung;
  }
  Object.assign(p, b, { id: p.id });
  db.speichern(); db.audit('patient-geaendert', { id: p.id, keys: Object.keys(b) }, 'rezeption');
  ok(res, { patient: p });
});

app.get('/api/patienten/:id/termine', (req, res) => {
  const d = db.laden();
  const p = d.patienten.find((x) => x.id === req.params.id);
  if (!p) return fehler(res, 'Patient nicht gefunden.', 404);
  ok(res, { termine: termineFuerPatient(p.id, 16) });
});

app.post('/api/patienten/:id/termine-mail', async (req, res) => {
  const d = db.laden();
  const p = d.patienten.find((x) => x.id === req.params.id);
  if (!p) return fehler(res, 'Patient nicht gefunden.', 404);
  if (!p.email) return fehler(res, 'Keine E-Mail-Adresse hinterlegt.');
  const v = d.verordnungen.find((x) => x.patientId === p.id && ['aktiv', 'vollstaendig', 'abgeschlossen'].includes(x.status));
  const eintrag = await sendeTermineMail(p, v);
  ok(res, { outbox: eintrag });
});

/* ---------------- Scan / Datenabgleich / Verordnungen ---------------- */
app.post('/api/verordnungen/scan', (req, res) => {
  const d = db.laden();
  const { code, manuell, format, quelltext } = req.body || {};
  let parsed = parseVerordnungsCode(code || '');
  if (!parsed.daten && manuell && format) parsed = { quelltext: String(quelltext || ''), daten: null, format };
  const daten = parsed.daten || (manuell && typeof manuell === 'object' ? normalisiereRoh(manuell) : {});
  const art = daten.art && rules.ARTEN[daten.art] ? daten.art : 'rs';
  const v = {
    id: db.id('v'),
    quelle: (parsed.format === 'unbekannt' || parsed.format === 'leer') ? 'manuell' : 'scan',
    codeFormat: parsed.format, codeQuelltext: (parsed.quelltext || '').slice(0, 4000),
    formular: daten.formular || 'muster56',
    name: daten.name || '', geburtsdatum: daten.geburtsdatum || '',
    kostentraeger: daten.kostentraeger || '', kostentraegerArt: daten.kostentraegerArt || 'gkv',
    versichertenNr: daten.versichertenNr || '', ik: daten.ik || '',
    ausstellungsdatum: daten.ausstellungsdatum || '',
    von: daten.von || '', bis: daten.bis || '',
    art,
    frequenzProWoche: daten.frequenzProWoche || 1,
    frequenzBegruendung: '', uebungseinheiten: daten.uebungseinheiten || rules.ARTEN[art].ueeRegel,
    ueeBegruendung: '', dauerBegruendung: '',
    icd10: daten.icd10 || [], ziele: daten.ziele || '',
    folgeverordnung: Boolean(daten.folgeverordnung), folgeBegruendung: '',
    baustein: daten.baustein || '',
    arztName: daten.arztName || '',
    kostenuebernahme: daten.kostenuebernahme || { liegtVor: false, datum: '', zeitraum: '' },
    email: daten.email || '', telefon: daten.telefon || '',
    patientId: null, trainerId: '', kursIds: [],
    einwilligung: false, status: 'abgleich',
    angelegtAm: new Date().toISOString(),
  };
  // Doppelterkennung: gleicher Code erneut scannen -> bestehenden offenen Abgleich öffnen
  const bestehend = d.verordnungen.find((x) => x.status === 'abgleich' && x.codeQuelltext && x.codeQuelltext === v.codeQuelltext && v.codeQuelltext);
  if (bestehend) return ok(res, { verordnung: bestehend, wiederholung: true, pruefung: rules.pruefeVerordnung(bestehend) });

  d.verordnungen.push(v);
  db.speichern(); db.audit('verordnung-gescannt', { id: v.id, format: parsed.format }, 'rezeption');
  ok(res, { verordnung: v, pruefung: rules.pruefeVerordnung(v), wiederholung: false });
});

app.post('/api/verordnungen', (req, res) => {
  // Anlegen ohne Scan (manuelle Erfassung)
  const v = req.body || {};
  if (!v.name && !v.patientId) return fehler(res, 'Pflichtangaben fehlen.');
  const d = db.laden();
  const neu = {
    id: db.id('v'), quelle: 'manuell', codeFormat: 'manuell', codeQuelltext: '',
    status: 'abgleich', angelegtAm: new Date().toISOString(),
    formular: v.formular || 'muster56', art: v.art || 'rs', icd10: v.icd10 || [],
    kursIds: [], trainerId: '', einwilligung: false,
    kostenuebernahme: { liegtVor: false, datum: '', zeitraum: '' }, ...v,
  };
  d.verordnungen.push(neu); db.speichern(); db.audit('verordnung-angelegt', { id: neu.id }, 'rezeption');
  ok(res, { verordnung: neu, pruefung: rules.pruefeVerordnung(neu) });
});

app.get('/api/verordnungen', (req, res) => {
  const d = db.laden();
  ok(res, {
    verordnungen: d.verordnungen.map((v) => {
      const { uee, tage } = berechneErbrachteUee(v);
      return { ...v, erbrachteUee: uee, erbrachteTage: tage };
    }),
  });
});

function zuordnungsText(v) {
  const d = db.laden();
  const kursIds = v.kursIds || d.zuordnungen.filter((z) => z.verordnungId === v.id && z.aktiv !== false).map((z) => z.kursId);
  const t = d.trainer.find((x) => x.id === v.trainerId);
  const teile = kursIds.map((kid) => (kursInfo(kid) || {}).titel).filter(Boolean);
  return `${t ? t.vorname + ' ' + t.nachname : '–'} · ${teile.join(' + ') || 'kein Kurs'}`;
}

app.put('/api/verordnungen/:id', async (req, res) => {
  const d = db.laden();
  const v = d.verordnungen.find((x) => x.id === req.params.id);
  if (!v) return fehler(res, 'Verordnung nicht gefunden.', 404);
  const b = req.body || {};
  const vorher = { status: v.status, trainerId: v.trainerId, kursIds: v.kursIds };

  // Felder übernehmen
  const erlaubt = ['name', 'geburtsdatum', 'kostentraeger', 'kostentraegerArt', 'versichertenNr', 'ik',
    'ausstellungsdatum', 'von', 'bis', 'art', 'frequenzProWoche', 'frequenzBegruendung',
    'uebungseinheiten', 'ueeBegruendung', 'dauerBegruendung', 'icd10', 'ziele', 'folgeverordnung',
    'folgeBegruendung', 'baustein', 'arztName', 'kostenuebernahme', 'email', 'telefon',
    'formular', 'trainerId', 'kursIds', 'patientId', 'status'];
  for (const k of erlaubt) if (b[k] !== undefined) v[k] = b[k];

  // Patient anlegen/finden (erst beim Abschluss des Datenabgleichs)
  let patient = d.patienten.find((p) => p.id === v.patientId);
  if (!patient && b.abschliessen === true && b.anlegen !== false && v.name && v.geburtsdatum) {
    const [nach, vor] = String(v.name).split(',').map((s) => s.trim());
    const dup = d.patienten.find((p) => p.nachname.toLowerCase() === (nach || '').toLowerCase() && p.vorname.toLowerCase() === (vor || '').toLowerCase() && p.geburtsdatum === v.geburtsdatum);
    if (dup) { patient = dup; v.patientId = dup.id; }
    else {
      patient = {
        id: db.id('p'), vorname: vor || '', nachname: nach || '', geburtsdatum: v.geburtsdatum,
        strasse: '', plz: '', ort: '', email: v.email || '', telefon: v.telefon || '',
        einwilligung: b.einwilligung || null, bemerkung: '', angelegtAm: new Date().toISOString(),
      };
      d.patienten.push(patient);
      v.patientId = patient.id;
      db.audit('patient-im-datenabgleich-angelegt', { patientId: patient.id, verordnungId: v.id }, 'rezeption');
    }
  } else if (patient && (b.email !== undefined || b.telefon !== undefined || b.einwilligung)) {
    if (b.email !== undefined) patient.email = b.email;
    if (b.telefon !== undefined) patient.telefon = b.telefon;
    if (b.einwilligung) patient.einwilligung = b.einwilligung;
  }

  // Unterschriften: Anmeldung/DSGVO am Ende des Datenabgleichs
  if (b.anmeldungUnterschrift) {
    v.anmeldung = { datum: b.anmeldungDatum || heutigesDatum(), unterschriftPng: b.anmeldungUnterschrift, ts: new Date().toISOString() };
    if (patient && !patient.einwilligung && b.einwilligung) patient.einwilligung = b.einwilligung;
  }
  if (b.einwilligung) {
    v.einwilligung = true;
    v.einwilligungAm = new Date().toISOString();
    if (patient) patient.einwilligung = b.einwilligung;
  }

  // Zuordnungen feste Gruppe (Kurs = Gruppe)
  if (b.kursIds !== undefined) {
    // Art der festen Gruppe muss zur Verordnung passen (Rahmenvereinbarung)
    const unpassend = (b.kursIds || []).map((kid) => d.kurse.find((k) => k.id === kid))
      .filter((k) => k && rules.pruefeKursZuordnung(v, k).blockiert);
    if (unpassend.length) {
      return res.status(422).json({
        ok: false,
        fehler: unpassend.flatMap((k) => rules.pruefeKursZuordnung(v, k).fehler).join(' · '),
        pruefung: rules.pruefeVerordnung(v), verordnung: v,
      });
    }
    const vorhanden = d.zuordnungen.filter((z) => z.verordnungId === v.id);
    for (const z of vorhanden) z.aktiv = (b.kursIds || []).includes(z.kursId);
    for (const kid of b.kursIds || []) {
      if (!vorhanden.some((z) => z.kursId === kid)) {
        d.zuordnungen.push({ id: db.id('z'), verordnungId: v.id, patientId: v.patientId, kursId: kid, seit: heutigesDatum(), aktiv: true });
      }
    }
    if (b.gruppenwechselGrund) db.audit('gruppenwechsel', { verordnungId: v.id, grund: b.gruppenwechselGrund, von: vorher.kursIds, auf: b.kursIds }, 'rezeption');
    v.kursIds = b.kursIds;
  }

  // Prüfung nach allen Änderungen (inkl. Einwilligung) berechnen
  const pruefung = rules.pruefeVerordnung(v);

  // Kurs-Zuordnung rechtlich prüfen
  const kursFe = [];
  for (const kid of v.kursIds || []) {
    const k = d.kurse.find((x) => x.id === kid);
    if (k) kursFe.push(...rules.pruefeKursZuordnung(v, k).fehler);
  }

  // Abschluss des Datenabgleichs?
  let mails = [];
  const fertig = b.abschliessen === true;
  if (fertig) {
    const gesamtFehler = [...pruefung.fehler, ...kursFe];
    if (gesamtFehler.length) {
      db.speichern();
      return res.status(422).json({ ok: false, fehler: 'Verordnung ist noch nicht vollständig.', pruefung: { ...pruefung, fehler: gesamtFehler }, verordnung: v });
    }
    if (!patient) return fehler(res, 'Kein Patient angelegt.');
    if (!(v.kursIds || []).length) return fehler(res, 'Keine feste Gruppe (Kurs) zugeordnet.');
    v.status = 'aktiv';
    v.vollstaendigAm = new Date().toISOString();
    db.audit('verordnung-vollstaendig', { verordnungId: v.id, patientId: patient.id, zuweisung: zuordnungsText(v) }, 'rezeption');
    // Termine materialisieren und E-Mails senden
    for (const kid of v.kursIds) { const k = d.kurse.find((x) => x.id === kid); if (k) materialisiereKurs(k, new Date(Date.now() + 60 * 86400000).toISOString().slice(0, 10)); }
    db.speichernSync();
    mails.push(await sendeTermineMail(patient, v));
    mails.push(await sendeVollstaendigMail(v, patient, pruefung, zuordnungsText(v)));
  } else {
    db.speichern();
    if (b.status === undefined) v.status = v.status === 'abgleich' ? 'abgleich' : v.status;
  }
  db.audit('verordnung-geaendert', { verordnungId: v.id, keys: Object.keys(b) }, 'rezeption');
  ok(res, { verordnung: v, pruefung: rules.pruefeVerordnung(v), kurseFehler: kursFe, mails });
});

app.delete('/api/verordnungen/:id', (req, res) => {
  const d = db.laden();
  const v = d.verordnungen.find((x) => x.id === req.params.id);
  if (!v) return fehler(res, 'Verordnung nicht gefunden.', 404);
  if (v.status === 'aktiv') return fehler(res, 'Aktive Verordnungen können nicht gelöscht werden (Nachvollziehbarkeit) – ggf. Status/Zeitraum ändern.');
  d.verordnungen = d.verordnungen.filter((x) => x.id !== v.id);
  d.zuordnungen = d.zuordnungen.filter((z) => z.verordnungId !== v.id);
  db.speichern(); db.audit('verordnung-geloescht', { id: v.id }, 'rezeption');
  ok(res, {});
});

app.get('/api/verordnungen/:id/qrcode.png', async (req, res) => {
  const d = db.laden();
  const v = d.verordnungen.find((x) => x.id === req.params.id);
  if (!v) return fehler(res, 'Verordnung nicht gefunden.', 404);
  const payload = JSON.stringify({
    rs: '1', n: v.name, g: v.geburtsdatum, kk: v.kostentraeger, vs: v.versichertenNr,
    von: v.von, bis: v.bis, art: v.art, f: v.frequenzProWoche, ue: v.uebungseinheiten,
    icd: (v.icd10 || []).join(','), z: v.ziele, arzt: v.arztName, ft: v.formular, id: v.id,
  });
  const url = await QRCode.toDataURL(payload, { width: 480, margin: 1 });
  res.type('png').send(Buffer.from(url.split(',')[1], 'base64'));
});

app.post('/api/verordnungen/:id/abrechnung', (req, res) => {
  const d = db.laden();
  const v = d.verordnungen.find((x) => x.id === req.params.id);
  if (!v) return fehler(res, 'Verordnung nicht gefunden.', 404);
  const b = req.body || {};
  v.abrechnung = {
    satz: Number(b.satz) || 0, satzQuelle: b.satzQuelle || 'manuell',
    berechnetAm: heutigesDatum(), rechnungsNr: b.rechnungsNr || '',
    uee: berechneErbrachteUee(v).uee,
  };
  if (b.abrechnen) v.status = 'abgerechnet';
  db.speichern(); db.audit('abrechnung-dokumentiert', { verordnungId: v.id, satz: v.abrechnung.satz }, 'buchhaltung');
  ok(res, { verordnung: v });
});

/* ---------------- Matching ---------------- */
app.post('/api/matching', (req, res) => {
  const d = db.laden();
  const v = req.body && req.body.verordnung;
  if (!v) return fehler(res, 'Keine Verordnungsdaten.');
  // Belegung der Kurse ermitteln
  const belegung = {};
  for (const z of d.zuordnungen.filter((z) => z.aktiv !== false)) belegung[z.kursId] = (belegung[z.kursId] || 0) + 1;
  const kurse = d.kurse.map((k) => ({ ...k, belegt: belegung[k.id] || 0 }));
  const treffer = rules.waehleTrainer(v, d.trainer, kurse);
  ok(res, { treffer });
});

/* ---------------- Termine / Anwesenheit / Unterschriften ---------------- */
app.get('/api/termine', (req, res) => {
  const d = db.laden();
  const von = req.query.von || new Date().toISOString().slice(0, 10);
  const bis = req.query.bis || new Date(Date.now() + 90 * 86400000).toISOString().slice(0, 10);
  materialisiereAlle(bis);
  const liste = d.termine
    .filter((t) => t.datum >= von && t.datum <= bis)
    .map((t) => {
      const k = kursInfo(t.kursId) || {};
      const teilnehmer = d.zuordnungen.filter((z) => z.kursId === t.kursId && z.aktiv !== false).map((z) => {
        const p = d.patienten.find((x) => x.id === z.patientId) || {};
        const a = (t.anwesenheit || []).find((x) => x.patientId === z.patientId) || {};
        return { patientId: z.patientId, name: `${p.nachname || '?'}, ${p.vorname || ''}`, wahrgenommen: Boolean(a.wahrgenommen), unterschrift: Boolean(a.unterschriftPng), zeitstempel: a.zeitstempel || null, verordnungId: z.verordnungId };
      });
      return { ...t, kurs: { id: k.id, titel: k.titel, art: k.art, ort: k.ort, trainerName: k.trainerName, beginn: k.beginn, dauerMin: k.dauerMin, wochentag: k.wochentag }, teilnehmer };
    });
  ok(res, { termine: liste });
});

app.put('/api/termine/:id', (req, res) => {
  const d = db.laden();
  const t = d.termine.find((x) => x.id === req.params.id);
  if (!t) return fehler(res, 'Termin nicht gefunden.', 404);
  const b = req.body || {};
  if (b.status) t.status = b.status;
  if (b.dokumentation !== undefined) t.dokumentation = b.dokumentation;
  if (b.arztvisitation) t.arztvisitation = { ...b.arztvisitation, ts: new Date().toISOString() };
  if (b.leiterBestaetigung) {
    const name = typeof b.leiterBestaetigung === 'object' ? b.leiterBestaetigung.name : b.leiterBestaetigung;
    t.leiterBestaetigung = {
      name: name || '',
      unterschriftPng: (typeof b.leiterBestaetigung === 'object' && b.leiterBestaetigung.unterschriftPng) || null,
      ts: new Date().toISOString(),
    };
    if (t.status === 'geplant') t.status = 'stattgefunden';
    db.audit('teilnahmebestaetigung-leitung', { terminId: t.id });
  }
  if (b.neuesDatum || b.neueBeginn) {
    t.status = 'verschoben';
    t.neuesDatum = b.neuesDatum || '';
    t.neueBeginn = b.neueBeginn || '';
    db.audit('termin-verschoben', { terminId: t.id, auf: `${t.neuesDatum} ${t.neueBeginn}` });
  }
  db.speichern();
  ok(res, { termin: t });
});

app.post('/api/termine/:id/anwesenheit', (req, res) => {
  const d = db.laden();
  const t = d.termine.find((x) => x.id === req.params.id);
  if (!t) return fehler(res, 'Termin nicht gefunden.', 404);
  const b = req.body || {};
  const { patientId } = b;
  if (!patientId) return fehler(res, 'Patient fehlt.');
  const zugeordnet = d.zuordnungen.some((z) => z.kursId === t.kursId && z.patientId === patientId && z.aktiv !== false);
  if (!zugeordnet) return fehler(res, 'Patient/in ist nicht Teil dieser festen Gruppe.');

  // Regel: Unterschrift nur nach / unmittelbar an der Übungseinheit (kein Vorab-Unterschreiben!)
  const k = kursInfo(t.kursId);
  const [h, m] = String(t.beginn || '00:00').split(':').map(Number);
  const start = new Date(`${t.datum}T${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:00`);
  const ende = new Date(start.getTime() + (t.dauerMin || 45) * 60000);
  const jetzt = new Date();
  const abgeschlossen = jetzt >= ende || t.status === 'stattgefunden';
  if ((b.unterschriftPng || b.unterschriftPapier || b.wahrgenommen === true) && !abgeschlossen) {
    return fehler(res, 'Die Übungseinheit hat noch nicht stattgefunden. Teilnahme/Unterschrift ist laut Rahmenvereinbarung unmittelbar vor oder nach der Übungseinheit zu dokumentieren – Vorab-Eintragungen sind unzulässig.');
  }
  let eintrag = (t.anwesenheit || []).find((x) => x.patientId === patientId);
  if (!eintrag) { eintrag = { patientId, wahrgenommen: false, unterschriftPng: null, zeitstempel: null }; t.anwesenheit = t.anwesenheit || []; t.anwesenheit.push(eintrag); }
  if (b.wahrgenommen !== undefined) eintrag.wahrgenommen = Boolean(b.wahrgenommen);
  if (b.unterschriftPng) {
    eintrag.unterschriftPng = b.unterschriftPng;
    eintrag.unterschriftPapier = false;
    eintrag.zeitstempel = new Date().toISOString();
    db.audit('teilnehmerunterschrift', { terminId: t.id, patientId }, 'teilnehmer');
  }
  if (b.unterschriftPapier) {
    eintrag.unterschriftPapier = true;
    eintrag.zeitstempel = new Date().toISOString();
    db.audit('teilnehmerunterschrift-papier', { terminId: t.id, patientId }, 'leitung');
  }
  if (b.unterschriftLoeschen) {
    eintrag.unterschriftPng = null; eintrag.unterschriftPapier = false; eintrag.zeitstempel = null;
    db.audit('unterschrift-korrigiert', { terminId: t.id, patientId }, 'leitung');
  }
  db.speichern();
  ok(res, { termin: t, eintrag });
});

app.get('/api/patienten/:id/anwesenheit', (req, res) => {
  const d = db.laden();
  const p = d.patienten.find((x) => x.id === req.params.id);
  if (!p) return fehler(res, 'Patient nicht gefunden.', 404);
  const kid = d.zuordnungen.filter((z) => z.patientId === p.id && z.aktiv !== false).map((z) => z.kursId);
  const liste = d.termine.filter((t) => kid.includes(t.kursId) && (t.anwesenheit || []).some((a) => a.patientId === p.id))
    .map((t) => {
      const a = t.anwesenheit.find((x) => x.patientId === p.id);
      return { datum: t.datum, beginn: t.beginn, status: t.status, kurs: (kursInfo(t.kursId) || {}).titel, wahrgenommen: a.wahrgenommen, zeitstempel: a.zeitstempel, unterschrift: Boolean(a.unterschriftPng), leiter: Boolean(t.leiterBestaetigung) };
    }).sort((a, b2) => b2.datum.localeCompare(a.datum));
  ok(res, { anwesenheit: liste });
});

/* ---------------- Abrechnung ---------------- */
app.get('/api/abrechnung', (req, res) => {
  const d = db.laden();
  const heuteIso = heutigesDatum();
  const zeilen = [];
  for (const v of d.verordnungen) {
    if (!['aktiv', 'abgeschlossen', 'abgerechnet'].includes(v.status)) continue;
    const { uee, tage } = berechneErbrachteUee(v);
    const fertig = uee >= (v.uebungseinheiten || 0) || (v.bis && v.bis < heuteIso);
    const patient = d.patienten.find((p) => p.id === v.patientId) || {};
    const art = rules.ARTEN[v.art] || {};
    const key = `${v.kostentraegerArt || 'gkv'}:${v.art}`;
    const satzVorgaben = (d.settings.abrechnung && d.settings.abrechnung.satzMap) || {};
    const satz = v.abrechnung?.satz || satzVorgaben[key] || 0;
    zeilen.push({
      id: v.id, status: v.status, fertig, erbrachteUee: uee, geplanteUee: v.uebungseinheiten || 0,
      patient: `${patient.nachname || v.name || '?'}, ${patient.vorname || ''}`,
      kostentraeger: v.kostentraeger, kostentraegerArt: v.kostentraegerArt || 'gkv',
      art: v.art, artLabel: art.label || v.art, von: v.von, bis: v.bis,
      letzterTermin: tage.length ? tage[tage.length - 1] : null,
      satz, betrag: satz ? Math.round(satz * uee * 100) / 100 : null,
      abrechnung: v.abrechnung || null,
      hinweis: !fertig && v.bis && v.bis < heuteIso ? 'Verordnung abgelaufen – erbrachte ÜE abrechnen, Rest verfällt.' : '',
    });
  }
  ok(res, { zeilen, satzMap: (d.settings.abrechnung && d.settings.abrechnung.satzMap) || {}, quelle: 'https://verguetungssaetze.rehasport-deutschland.de/' });
});

app.get('/api/abrechnung/export.csv', (req, res) => {
  const d = db.laden();
  const rows = [['Rechnungsnr', 'Patient', 'Geb.', 'Kostenträger', 'Art', 'Verordnung von', 'bis', 'ÜE erbracht', 'Satz EUR', 'Betrag EUR', 'Status', 'abgerechnet am']];
  for (const v of d.verordnungen) {
    if (!['aktiv', 'abgeschlossen', 'abgerechnet'].includes(v.status)) continue;
    const { uee } = berechneErbrachteUee(v);
    const p = d.patienten.find((x) => x.id === v.patientId) || {};
    const satz = v.abrechnung?.satz || 0;
    rows.push([v.abrechnung?.rechnungsNr || '', `${p.nachname || ''}, ${p.vorname || ''}`, p.geburtsdatum || '', v.kostentraeger || '',
      (rules.ARTEN[v.art] || {}).label || v.art, v.von || '', v.bis || '', uee, satz, satz ? (satz * uee).toFixed(2) : '',
      v.status, v.abrechnung?.berechnetAm || '']);
  }
  const csv = '﻿' + rows.map((r) => r.map((z) => `"${String(z ?? '').replace(/"/g, '""')}"`).join(';')).join('\r\n');
  res.set('Content-Type', 'text/csv; charset=utf-8');
  res.set('Content-Disposition', 'attachment; filename="rehasport-abrechnung.csv"');
  res.send(csv);
});

/* ---------------- Outbox / Mail ---------------- */
app.get('/api/outbox', (req, res) => ok(res, { outbox: db.laden().outbox }));
app.get('/api/outbox/:id/mailto', (req, res) => {
  const e = db.laden().outbox.find((x) => x.id === req.params.id);
  if (!e) return fehler(res, 'Eintrag nicht gefunden.', 404);
  ok(res, { mailto: mail.mailtoLink(e) });
});
app.post('/api/outbox/:id/erneut', async (req, res) => {
  const d = db.laden();
  const e = d.outbox.find((x) => x.id === req.params.id);
  if (!e) return fehler(res, 'Eintrag nicht gefunden.', 404);
  const neu = await mail.sende({ typ: e.typ, an: e.an, betreff: e.betreff, text: e.text, html: e.html, patientId: e.patientId, verordnungId: e.verordnungId });
  ok(res, { outbox: neu });
});
app.post('/api/testmail', async (req, res) => {
  const d = db.laden();
  const an = (req.body && req.body.an) || d.settings.anbieter.email;
  if (!an) return fehler(res, 'Keine Zieladresse.');
  const eintrag = await mail.sende({ typ: 'test', an, betreff: 'RheaSport Test-E-Mail', text: 'Die SMTP-Konfiguration funktioniert.', html: '<p>Die SMTP-Konfiguration funktioniert ✔</p>' });
  ok(res, { outbox: eintrag });
});

/* ---------------- Geteilter Kalender (ICS) ---------------- */
app.get('/api/calendar/:token.ics', (req, res) => {
  const d = db.laden();
  const token = req.params.token.replace(/\.ics$/, '');
  if (!d.settings.kalender.geteilt || d.settings.kalender.token !== token) return fehler(res, 'Kalender-Link ungültig oder geteilt deaktiviert.', 404);
  materialisiereAlle(new Date(Date.now() + 330 * 86400000).toISOString().slice(0, 10));
  const text = ics.erstelleIcs(d.kurse, d.termine, d.trainer, d.settings);
  res.set('Content-Type', 'text/calendar; charset=utf-8');
  res.set('Content-Disposition', `inline; filename="${(d.settings.kalender.titel || 'kalender').replace(/[^\w\d-]+/g, '_')}.ics"`);
  res.send(text);
});
app.get('/api/kalender/share', (req, res) => {
  const d = db.laden();
  const base = `${req.protocol}://${req.get('host')}`;
  ok(res, {
    url: `${base}/api/calendar/${d.settings.kalender.token}.ics`,
    titel: d.settings.kalender.titel, geteilt: d.settings.kalender.geteilt,
    datenschutzHinweis: 'Der Kalender-Link enthält nur Kurs-/Termindaten – keine Patientennamen oder Gesundheitsdaten (Art. 9 DSGVO).',
  });
});
app.post('/api/kalender/rotate', (req, res) => {
  const d = db.laden();
  const crypto = require('crypto');
  d.settings.kalender.token = crypto.randomBytes(16).toString('hex');
  db.speichern(); db.audit('kalender-link-erneuert', {});
  ok(res, { token: d.settings.kalender.token });
});

/* ---------------- Datenexport/-import ---------------- */
app.post('/api/demo-reset', (req, res) => {
  db.resetDemo();
  db.audit('stammdaten-geloescht', {});
  ok(res, {});
});

app.get('/api/export', (req, res) => {
  res.set('Content-Disposition', `attachment; filename="rheasport-backup-${heutigesDatum()}.json"`);
  res.type('application/json').send(db.exportJson());
});
app.post('/api/import', (req, res) => {
  try {
    const erg = db.importJson(JSON.stringify(req.body || {}));
    ok(res, erg);
  } catch (e) { fehler(res, `Import fehlgeschlagen: ${e.message}`); }
});

/* ---------------- Statische Auslieferung ---------------- */
app.use('/vendor', express.static(path.join(__dirname, 'public', 'vendor')));
app.use(express.static(path.join(__dirname, 'public')));
app.use((req, res) => {
  if (req.method === 'GET' && !req.path.startsWith('/api/')) return res.sendFile(path.join(__dirname, 'public', 'index.html'));
  res.status(404).json({ ok: false, fehler: 'Nicht gefunden.' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`RheaSport-App läuft auf Port ${PORT} (lokal, Daten: data/db.json)`);
  if (APP_TOKEN) console.log('APP_TOKEN-Zugriffsschutz aktiv.');
});
