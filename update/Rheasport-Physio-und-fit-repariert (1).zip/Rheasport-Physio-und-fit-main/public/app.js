/* RheaSport – Physio & fit · Frontend (lokal, DSGVO-konform) */
'use strict';

/* Lokalmodus (APK/WebView oder ?local=1): Daten & API laufen im Browser,
   es wird kein Server benötigt. Sonst: lokaler Node-Server wie gehabt. */
window.LOCAL_MODE = Boolean(window.Capacitor)
  || location.protocol === 'capacitor:' || location.protocol === 'file:'
  || /(?:\?|&)local=1(?:&|$)/.test(location.search);

/* ----------------------------- Helfer ----------------------------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (iso) => { if (!iso) return '–'; const [j, m, t] = iso.split('-'); return t && m ? `${t}.${m}.${j}` : iso; };
const heutigesISO = () => new Date().toISOString().slice(0, 10);
const euroFmt = (n) => (Number(n) || 0).toLocaleString('de-DE', { style: 'currency', currency: 'EUR' });
const WOCHENTAGE = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
const WOCHENTAGE_LANG = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];

function toast(msg, cls = '') {
  const t = document.createElement('div');
  t.className = `toast ${cls}`;
  t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = '.4s'; setTimeout(() => t.remove(), 450); }, cls === 'err' ? 6500 : 3800);
}

async function api(methode, url, body) {
  if (window.LOCAL_MODE && window.localApi) {
    // APK/WebView: komplette API lokal im Gerät (localStorage)
    return window.localApi(methode, url, body);
  }
  const r = await fetch(url, {
    method: methode,
    headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let j = null;
  try { j = await r.json(); } catch (_) { /* z. B. CSV */ }
  if (!r.ok) {
    const err = new Error((j && (j.fehler || (j.pruefung && j.pruefung.fehler || []).join(' · '))) || `HTTP ${r.status}`);
    err.status = r.status; err.daten = j;
    throw err;
  }
  return j;
}

/* ----------------------------- Modal ----------------------------- */
let modalOnClose = null;
function openModal(titel, bodyHtml, footButtons = [], opts = {}) {
  const root = $('#modal-root');
  root.hidden = false;
  root.querySelector('.modal').className = `modal${opts.wide ? ' wide' : ''}`;
  $('#modal-title').textContent = titel;
  $('#modal-body').innerHTML = bodyHtml;
  const foot = $('#modal-foot');
  foot.innerHTML = '';
  for (const b of footButtons) {
    const btn = document.createElement('button');
    btn.className = b.cls || 'btn';
    btn.innerHTML = b.label;
    btn.onclick = b.onClick;
    foot.appendChild(btn);
  }
  modalOnClose = opts.onClose || null;
  return $('#modal-body');
}
function closeModal() {
  $('#modal-root').hidden = true;
  $('#modal-body').innerHTML = '';
  if (modalOnClose) { const f = modalOnClose; modalOnClose = null; f(); }
}
$('#modal-close').onclick = closeModal;
$('#modal-root .modal-backdrop').onclick = closeModal;
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('#modal-root').hidden) closeModal(); });

/* ------------------------- Unterschriften-Pad ------------------------- */
function openSigPad(titel, hinweisText) {
  return new Promise((resolve) => {
    let fertig = false;
    const body = openModal(titel, `
      <div class="sig-wrap">
        <div class="sig-meta"><strong>${esc(hinweisText || '')}</strong><br>
        Zeitstempel: ${new Date().toLocaleString('de-DE')} · Die Unterschrift wird unmittelbar vor/nach der Übungseinheit geleistet.
        Korrekturen werden protokolliert – Vordatierung/Tipp-Ex sind unzulässig (Rahmenvereinbarung/RSD).</div>
        <div class="sig-pad-box">
          <canvas class="sig-pad" id="sig-canvas"></canvas>
          <div class="sig-baseline"></div>
          <div class="sig-hintline">Hier mit Maus, Finger oder Stift unterschreiben</div>
        </div>
      </div>`, [
      { label: '🧽 Löschen', cls: 'btn', onClick: () => clearPad() },
      { label: 'Verwerfen', cls: 'btn', onClick: () => { fertig = true; closeModal(); resolve(null); } },
      { label: '✔ Unterschrift übernehmen', cls: 'btn primary', onClick: () => {
        const png = leer ? null : canvas.toDataURL('image/png');
        if (!png) { toast('Bitte zuerst unterschreiben.', 'err'); return; }
        fertig = true; closeModal(); resolve(png);
      } },
    ], { onClose: () => { if (!fertig) resolve(null); } });

    const canvas = $('#sig-canvas', body);
    const ctx = canvas.getContext('2d');
    let zeichnet = false, leer = true;
    const dpr = window.devicePixelRatio || 1;
    function resize() {
      const r = canvas.getBoundingClientRect();
      const alt = leer ? null : canvas.toDataURL();
      canvas.width = Math.max(1, r.width * dpr); canvas.height = Math.max(1, r.height * dpr);
      ctx.scale(dpr, dpr);
      ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#12323a';
      if (alt) {
        const i = new Image();
        i.onload = () => ctx.drawImage(i, 0, 0, r.width, r.height);
        i.src = alt;
        leer = false;
      }
    }
    function clearPad() { ctx.clearRect(0, 0, canvas.width, canvas.height); leer = true; }
    requestAnimationFrame(() => {
      resize();
      const pos = (e) => { const r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
      canvas.addEventListener('pointerdown', (e) => {
        zeichnet = true;
        try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
        const [x, y] = pos(e);
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 0.6, y + 0.6); ctx.stroke();
        leer = false;
      });
      canvas.addEventListener('pointermove', (e) => {
        if (!zeichnet) return;
        const [x, y] = pos(e);
        ctx.lineTo(x, y); ctx.stroke();
        leer = false;
      });
      canvas.addEventListener('pointerup', () => { zeichnet = false; });
      canvas.addEventListener('pointercancel', () => { zeichnet = false; });
      canvas.addEventListener('pointerleave', () => { zeichnet = false; });
    });
  });
}

/* ----------------------------- State ----------------------------- */
let S = null;   // /api/state
let D = null;   // Dashboard
let termineCache = [];
let aktuelleView = 'dashboard';

async function reload(renderView = true) {
  const [s, d] = await Promise.all([api('GET', '/api/state'), api('GET', '/api/dashboard')]);
  S = s; D = d.dashboard;
  renderNavBadges();
  $('#side-hilfsfrist').innerHTML = `⚠ Hilfsfrist ${esc(D.hilfsfrist.bundesland)}: <strong>${esc(D.hilfsfrist.text)}</strong>${D.hilfsfrist.laendlich ? ' (ländl. Gebiet)' : ''}`;
  if (renderView) renderAktuelleView();
  if (googleAktiv() && RheaGoogle.optionen().autoMail && RheaGoogle.status().angemeldet) setTimeout(() => gmailOffeneSenden(true), 300);
}

function renderNavBadges() {
  const a = $('#nav-abgleiche'), s = $('#nav-signaturen'), o = $('#nav-outbox');
  a.hidden = !D.zaehler.offeneAbgleiche; a.textContent = D.zaehler.offeneAbgleiche;
  const sig = D.zaehler.signaturenOffen;
  s.hidden = !sig; s.textContent = sig; s.classList.add('amber');
  const offen = (S.outbox || []).filter((m) => m.status !== 'gesendet').length;
  o.hidden = !offen; o.textContent = offen; o.classList.add('amber');
}

/* ----------------------------- Navigation ----------------------------- */
$$('#nav button').forEach((b) => {
  b.onclick = () => zeigeView(b.dataset.view);
});
function zeigeView(view) {
  aktuelleView = view;
  $$('#nav button').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
  $$('.view').forEach((v) => { v.hidden = v.id !== `view-${view}`; });
  renderAktuelleView();
}
function renderAktuelleView() {
  if (!S || !D) return;
  switch (aktuelleView) {
    case 'dashboard': renderDashboard(); break;
    case 'scan': renderScan(); break;
    case 'patienten': renderPatienten(); break;
    case 'trainer': renderTrainer(); break;
    case 'kurse': renderKurse(); break;
    case 'kalender': renderKalender(); break;
    case 'abrechnung': renderAbrechnung(); break;
    case 'dokumente': renderDokumente(); break;
    case 'azh': renderAzh(); break;
    case 'admin': renderAdmin(); break;
    case 'postfach': renderPostfach(); break;
    case 'einstellungen': renderEinstellungen(); break;
  }
}

/* ============================== DASHBOARD ============================== */
function renderDashboard() {
  const z = D.zaehler;
  const stat = (n, t, cls = '', view = '') => `<div class="stat" data-v="${view}"><div class="n ${cls}">${n}</div><div class="t">${t}</div></div>`;
  $('#dash-stats').innerHTML =
    stat(z.offeneAbgleiche, 'Offene Datenabgleiche', z.offeneAbgleiche ? 'amber' : '', 'scan') +
    stat(z.termineHeute, 'Termine heute', '', 'kalender') +
    stat(z.aktiveVerordnungen, 'Aktive Verordnungen', '', 'patienten') +
    stat(z.signaturenOffen, 'Signaturen offen', z.signaturenOffen ? 'red' : '', 'kalender') +
    stat(z.abrechnungBereit, 'Abrechnung bereit', z.abrechnungBereit ? 'amber' : '', 'abrechnung') +
    stat(`${z.kurse}/${z.trainer}`, 'Kurse / Trainer', '', 'kurse');
  $$('#dash-stats .stat').forEach((el) => { el.onclick = () => zeigeView(el.dataset.v); });

  const warns = [];
  if (!D.smtp && S.lokalModus) warns.push('<div class="warnbox info"><strong>APK-Lokalmodus</strong>Termine- und Vollständigkeits-E-Mails liegen als Entwurf bereit und werden über die Mail-App des Geräts versendet (<button class="link" onclick="zeigeView(\'postfach\')">E-Mail-Journal</button>).</div>');
  else if (!D.smtp) warns.push(`<div class="warnbox wa"><strong>SMTP nicht konfiguriert</strong>E-Mails (Patienten-Termine &amp; Bestätigung ans Führungspersonal) werden als Entwurf vorgehalten. <button class="link" onclick="zeigeView('einstellungen')">Einstellungen öffnen</button></div>`);
  for (const w of D.zertifikatWarnungen) warns.push(`<div class="warnbox wa"><strong>Zertifikat läuft ab</strong>${esc(w.trainer)}: Qualifikationsnachweis bis ${fmt(w.bis)}</div>`);
  for (const v of D.visitationWarnungen) warns.push(v.noetig
    ? `<div class="warnbox err"><strong>Arztvisitation fällig</strong>${esc(v.kurs)}: Herzgruppen-Visitation mind. alle 6 Wochen (letzte: ${v.letzte === 'nie' ? 'nie' : fmt(v.letzte)})</div>`
    : `<div class="warnbox wa"><strong>Arztvisitation in Kürze</strong>${esc(v.kurs)}: letzte Visitation ${fmt(v.letzte)} (Intervall max. 6 Wochen)</div>`);
  warns.push(`<div class="warnbox info"><strong>Notfallabsicherung NRW</strong>Hilfsfrist ${esc(D.hilfsfrist.text)} – Notfallplan, (A)ED-Prüfung und Notfallübungen (2×/Jahr) für Herzgruppen bereithalten.</div>`);
  $('#dash-warn').innerHTML = `<div class="warn-grid">${warns.join('')}</div>`;

  $('#dash-heute').innerHTML = D.termineHeute.length ? D.termineHeute.map((t) =>
    `<div class="item"><div><strong>${esc(t.beginn)} Uhr</strong> · ${esc(t.kurs || '')} <span class="muted">(${esc(t.status)})</span></div>
     <button class="btn small" onclick="oeffneTermin('${t.id}')">Verwalten</button></div>`).join('')
    : '<div class="muted">Heute keine Termine.</div>';

  $('#dash-abgleiche').innerHTML = D.offeneAbgleiche.length ? D.offeneAbgleiche.map((v) =>
    `<div class="item"><div><strong>${esc(v.name || 'Ohne Namen')}</strong><div class="muted">Verordnung von ${fmt(v.von)}</div></div>
     <button class="btn small" onclick="fortsetzeAbgleich('${v.id}')">Datenabgleich fortsetzen</button></div>`).join('')
    : '<div class="muted">Keine offenen Datenabgleiche.</div>';

  $('#dash-signaturen').innerHTML = D.ausstehendSignatur.length ? D.ausstehendSignatur.map((s) =>
    `<div class="item"><div>${pLink(s.patientId, s.patient)} <span class="muted">· ${esc(s.kurs)} · ${fmt(s.datum)}</span></div>
     <button class="btn small" onclick="oeffneTermin('${s.terminId}')">Unterschrift erfassen</button></div>`).join('')
    : '<div class="muted">Keine offenen Signaturen.</div>';
}

/* ============================== SCAN / WIZARD ============================== */
const WIZ = { v: null, pruefung: null, step: 1, trainerId: null, kursIds: [], sig: null, match: [], saveTimer: null };

function renderScan() {
  setTimeout(filterAbgleich, 0);
  const off = (S.verordnungen || []).filter((v) => v.status === 'abgleich');
  $('#offene-abgleiche').innerHTML = off.length ? off.map((v) =>
    `<div class="item"><div><strong>${esc(v.name || v.id)}</strong><div class="muted">${fmt(v.von)} – ${fmt(v.bis)} · ${esc((S.regeln.arten[v.art] || {}).label || '')}</div></div>
     <button class="btn small" onclick="fortsetzeAbgleich('${v.id}')">Öffnen</button></div>`).join('')
    : '<div class="muted">Keine weiteren offenen Abgleiche.</div>';

  const kassen = [...new Set((S.verordnungen || []).map((v) => v.kostentraeger).filter(Boolean))];
  $('#kk-liste').innerHTML = kassen.map((k) => `<option value="${esc(k)}">`).join('');

  if (!WIZ.v) { $('#scan-start').hidden = false; $('#wizard').hidden = true; }
}

window.fortsetzeAbgleich = async (id) => {
  const v = (S.verordnungen || []).find((x) => x.id === id);
  if (!v) return;
  WIZ.v = { ...v, icd10: v.icd10 || [] };
  WIZ.pruefung = null; WIZ.trainerId = v.trainerId || null; WIZ.kursIds = v.kursIds || [];
  WIZ.sig = v.anmeldung ? v.anmeldung.unterschriftPng : null;
  $('#scan-start').hidden = true;
  $('#wizard').hidden = false;
  befuelleWizard();
  zeigeSchritt(1);
};

function befuelleWizard() {
  const v = WIZ.v;
  const set = (id, val) => { const el = $(id); if (el) el.value = val ?? ''; };
  set('#f-name', v.name); set('#f-geb', v.geburtsdatum); set('#f-kk', v.kostentraeger);
  set('#f-kkart', v.kostentraegerArt); set('#f-vs', v.versichertenNr); set('#f-ik', v.ik);
  set('#f-aus', v.ausstellungsdatum); set('#f-von', v.von); set('#f-bis', v.bis);
  const artSel = $('#f-art');
  artSel.innerHTML = Object.entries(S.regeln.arten).map(([id, a]) => `<option value="${id}">${esc(a.label)}</option>`).join('');
  set('#f-art', v.art);
  set('#f-freq', String(v.frequenzProWoche || 1));
  const uee = String(v.uebungseinheiten || 50);
  const ueeSel = $('#f-uee');
  if (['50', '90', '120'].includes(uee)) { ueeSel.value = uee; $('#f-uee-custom-wrap').hidden = true; }
  else { ueeSel.value = 'custom'; $('#f-uee-custom-wrap').hidden = false; set('#f-uee-custom', uee); }
  set('#f-formular', v.formular || 'muster56'); set('#f-arzt', v.arztName);
  set('#f-icd', (v.icd10 || []).join(', ')); set('#f-ziele', v.ziele);
  $('#f-folge').checked = Boolean(v.folgeverordnung); set('#f-folge-beg', v.folgeBegruendung);
  const ku = v.kostenuebernahme || {};
  $('#f-ku').checked = Boolean(ku.liegtVor); set('#f-ku-datum', ku.datum); set('#f-ku-zeitraum', ku.zeitraum);
  set('#f-freq-beg', v.frequenzBegruendung); set('#f-uee-beg', v.ueeBegruendung); set('#f-dauer-beg', v.dauerBegruendung);
  set('#f-email', v.email); set('#f-tel', v.telefon);
  $('#scan-format-note').textContent = v.codeFormat ? `Quelle: ${v.codeFormat}` : '';
  $('#text-version').textContent = (S.settings.datenschutz || {}).textVersion || '';
  $('#wiz-sig-preview').innerHTML = WIZ.sig ? `<img src="${WIZ.sig}" alt="Unterschrift">` : '– noch keine Unterschrift –';
  aktualisiereSichtbarkeiten();
  entwurfSpeichern(); // Validierung/Lebenslauf sofort anstoßen
}

function aktualisiereSichtbarkeiten() {
  $('#wrap-folge-beg').hidden = !$('#f-folge').checked;
  $('#wrap-freq-beg').hidden = Number($('#f-freq').value) < 3;
  const monate = (() => {
    const a = $('#f-von').value, b = $('#f-bis').value;
    if (!a || !b) return 0;
    const da = new Date(a), dbm = new Date(b);
    return (dbm.getFullYear() - da.getFullYear()) * 12 + (dbm.getMonth() - da.getMonth()) + (dbm.getDate() >= da.getDate() ? 0 : -1);
  })();
  $('#wrap-dauer-beg').hidden = monate <= 6;
  const ueeWert = $('#f-uee').value === 'custom' ? Number($('#f-uee-custom').value || 0) : Number($('#f-uee').value);
  const artRegel = (S.regeln.arten[$('#f-art').value] || {}).ueeRegel || 50;
  $('#wrap-uee-beg').hidden = !(ueeWert > artRegel && ueeWert !== 120);
}

function sammleFelder() {
  const v = WIZ.v;
  const get = (id) => $(id).value.trim();
  const uee = $('#f-uee').value === 'custom' ? Number($('#f-uee-custom').value || 0) : Number($('#f-uee').value);
  Object.assign(v, {
    name: get('#f-name'), geburtsdatum: get('#f-geb'), kostentraeger: get('#f-kk'),
    kostentraegerArt: $('#f-kkart').value, versichertenNr: get('#f-vs'), ik: get('#f-ik'),
    ausstellungsdatum: get('#f-aus'), von: get('#f-von'), bis: get('#f-bis'),
    art: $('#f-art').value, frequenzProWoche: Number($('#f-freq').value),
    uebungseinheiten: uee, formular: $('#f-formular').value, arztName: get('#f-arzt'),
    icd10: get('#f-icd').split(/[;,]/).map((s) => s.trim()).filter(Boolean),
    ziele: $('#f-ziele').value.trim(),
    folgeverordnung: $('#f-folge').checked, folgeBegruendung: $('#f-folge-beg').value.trim(),
    kostenuebernahme: { liegtVor: $('#f-ku').checked, datum: get('#f-ku-datum'), zeitraum: get('#f-ku-zeitraum') },
    frequenzBegruendung: $('#f-freq-beg').value.trim(), ueeBegruendung: $('#f-uee-beg').value.trim(),
    dauerBegruendung: $('#f-dauer-beg').value.trim(),
    email: get('#f-email'), telefon: get('#f-tel'),
  });
  return v;
}

async function entwurfSpeichern() {
  if (!WIZ.v) return null;
  const v = sammleFelder();
  try {
    const r = await api('PUT', `/api/verordnungen/${v.id}`, v);
    WIZ.v = r.verordnung; WIZ.pruefung = r.pruefung;
    zeichneAbgleichLive();
    if (WIZ.step === 2) zeichnePruefliste();
    return r;
  } catch (e) { toast(`Speichern fehlgeschlagen: ${e.message}`, 'err'); return null; }
}

function debounceEntwurf() {
  aktualisiereSichtbarkeiten();
  clearTimeout(WIZ.saveTimer);
  WIZ.saveTimer = setTimeout(entwurfSpeichern, 700);
}

function zeichneAbgleichLive() {
  const p = WIZ.pruefung;
  if (!p) { $('#abgleich-live').innerHTML = ''; return; }
  const fehlend = p.felder.filter((f) => f.blockiert && !f.ok);
  const ok = p.felder.filter((f) => f.blockiert && f.ok).length;
  $('#abgleich-live').innerHTML = fehlend.length
    ? `<div class="bad">${ok}/${p.felder.filter((f) => f.blockiert).length} Pflichtprüfungen – noch offen:</div>` +
      fehlend.slice(0, 6).map((f) => `<div class="bad">✕ ${esc(f.text)}</div>`).join('') +
      (fehlend.length > 6 ? `<div class="warn">… +${fehlend.length - 6} weitere</div>` : '')
    : `<div class="ok">✔ Alle ${ok} Pflichtprüfungen bestanden – Verordnung vollständig.</div>` +
      p.hinweise.map((h) => `<div class="warn">⚠ ${esc(h)}</div>`).join('');
}

function zeichnePruefliste() {
  const p = WIZ.pruefung;
  if (!p) { $('#pruef-liste').innerHTML = '<div class="muted">Bitte zuerst die Daten im Schritt 1 erfassen.</div>'; return; }
  $('#pruef-liste').innerHTML = p.felder.map((f) => {
    const cls = f.ok ? 'ok' : (f.blockiert ? 'bad' : 'warn');
    const ic = f.ok ? '✓' : (f.blockiert ? '✕' : '!');
    return `<div class="check-item ${cls}"><span class="ic">${ic}</span><div><strong>${esc(f.name)}</strong><div>${esc(f.text)}</div></div></div>`;
  }).join('') + (p.hinweise.length ? p.hinweise.map((h) => `<div class="check-item warn"><span class="ic">!</span><div>${esc(h)}</div></div>`).join('') : '');
}

function zeigeSchritt(n) {
  WIZ.step = n;
  $$('#wizard-steps span').forEach((s) => {
    const i = Number(s.dataset.step);
    s.classList.toggle('active', i === n);
    s.classList.toggle('done', i < n);
  });
  $$('.step').forEach((s) => { s.hidden = s.id !== `step-${n}`; });
  if (n === 2) entwurfSpeichern().then(() => zeichnePruefliste());
}

/* --- Schritt 3: Matching --- */
async function ladeMatching() {
  const v = sammleFelder();
  const r = await api('POST', '/api/matching', { verordnung: v });
  WIZ.match = r.treffer;
  const box = $('#trainer-match');
  if (!r.treffer.length) { box.innerHTML = '<div class="muted">Keine Trainer/innen hinterlegt. Bitte zuerst Trainer &amp; Kurse anlegen.</div>'; return; }
  box.innerHTML = r.treffer.map((m, i) => {
    const t = m.trainer;
    const quals = (t.qualifikationen || []).map((q) => `<span class="chip ${m.kann ? 'green' : 'gray'}">${esc((S.regeln.qualifikationen.find((x) => x.id === q) || {}).label || q)}</span>`).join(' ');
    const kuTxt = m.passteKurse.map((k) => `${WOCHENTAGE[k.wochentag]} ${esc(k.beginn)} (${k.belegt}/${k.maxTeilnehmer} belegt)`).join(' · ');
    return `<div class="match ${m.kann ? 'can' : 'no'} ${WIZ.trainerId === t.id ? 'selected' : ''}" data-i="${i}" ${m.kann ? '' : 'aria-disabled="true"'}>
      <div>
        <div class="who">${esc(t.vorname)} ${esc(t.nachname)} ${m.kann ? '<span class="chip green">geeignet</span>' : '<span class="chip red">nicht geeignet</span>'}</div>
        <div class="chips" style="margin:6px 0">${quals}</div>
        <div class="reasons">${m.gruende.map((g) => `<div>${esc(g)}</div>`).join('')}</div>
        ${m.hart.length ? `<div class="hart">${m.hart.map((g) => `<div>${esc(g)}</div>`).join('')}</div>` : ''}
        <div class="muted small">Feste Gruppe(n): ${kuTxt || '–'}</div>
      </div>
      <div class="score"><div class="big">${m.kann ? m.score : '–'}</div><div>Match-Punkte</div>
      <div style="margin-top:6px">${m.kann ? `<span class="chip blue">freie Plätze: ${m.freiePlaetze}</span>` : ''}</div></div>
    </div>`;
  }).join('');
  $$('#trainer-match .match').forEach((el) => {
    el.onclick = () => {
      const m = r.treffer[Number(el.dataset.i)];
      if (!m.kann) { toast('Diese/r Trainer/in erfüllt die Anforderungen nicht.', 'err'); return; }
      WIZ.trainerId = m.trainer.id;
      WIZ.kursIds = [];
      $$('#trainer-match .match').forEach((x) => x.classList.remove('selected'));
      el.classList.add('selected');
      $('#btn-zu-gruppe').disabled = false;
    };
  });
  $('#btn-zu-gruppe').disabled = !WIZ.trainerId;
}

/* --- Schritt 4: Gruppen --- */
function zeichneGruppen() {
  const m = WIZ.match.find((x) => x.trainer.id === WIZ.trainerId);
  const box = $('#gruppen-liste');
  if (!m) { box.innerHTML = ''; return; }
  const v = sammleFelder();
  const freq = v.frequenzProWoche || 1;
  const volleTage = new Set();
  box.innerHTML = m.passteKurse.map((k) => {
    const voll = k.belegt >= k.maxTeilnehmer && !WIZ.kursIds.includes(k.id);
    if (voll) volleTage.add(k.wochentag);
    const artRegeln = S.regeln.arten[k.art] || {};
    return `<div class="gruppe ${WIZ.kursIds.includes(k.id) ? 'selected' : ''} ${voll ? 'nein' : ''}" data-id="${k.id}">
      <div><div class="t">${WOCHENTAGE_LANG[k.wochentag]} · ${esc(k.beginn)} Uhr · ${k.dauerMin} Min.</div>
      <div class="muted small">${esc(k.titel)} · ${esc(k.ort || 'Ort offen')} · max. ${k.maxTeilnehmer} TN (Regel: ${artRegeln.maxTN || '–'}) ${k.belegt ? `· ${k.belegt} belegt` : ''}${voll ? ' · <strong>ausgebucht</strong>' : ''}</div></div>
      <div>${WIZ.kursIds.includes(k.id) ? '<span class="chip green">zugewiesen</span>' : '<span class="chip gray">hinzufügen</span>'}</div>
    </div>`;
  }).join('') || '<div class="muted">Für diese Verordnung wurde keine feste Gruppe dieses Trainers gefunden.</div>';
  $$('#gruppen-liste .gruppe').forEach((el) => {
    el.onclick = () => {
      const id = el.dataset.id;
      const idx = WIZ.kursIds.indexOf(id);
      if (idx >= 0) WIZ.kursIds.splice(idx, 1); else WIZ.kursIds.push(id);
      zeichneGruppen();
    };
  });
  const tage = new Set(m.passteKurse.filter((k) => WIZ.kursIds.includes(k.id)).map((k) => k.wochentag));
  if (WIZ.kursIds.length && tage.size < freq) {
    box.insertAdjacentHTML('beforeend', `<div class="hint">Hinweis: Die Verordnung sieht <strong>${freq}×/Woche</strong> vor, zugewiesen sind <strong>${tage.size}×</strong> – ggf. weitere Gruppe(n) wählen oder Frequenzbegründung prüfen.</div>`);
  }
}

$('#btn-wiz-sig').onclick = async () => {
  const name = sammleFelder().name || 'Versicherte/r';
  const png = await openSigPad('Unterschrift – Anmeldung & Einwilligung (Art. 9 DSGVO)', `${name} · ${new Date().toLocaleDateString('de-DE')}`);
  if (png) { WIZ.sig = png; $('#wiz-sig-preview').innerHTML = `<img src="${png}" alt="Unterschrift">`; $('#chk-anmeldung').checked = true; }
};

$('#btn-zu-pruefung').onclick = async () => {
  const v = sammleFelder();
  if (!v.name || !v.geburtsdatum) { toast('Name und Geburtsdatum sind Pflicht.', 'err'); return; }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email)) { toast('Im Datenabgleich ist eine gültige E-Mail-Adresse einzutragen.', 'err'); return; }
  if ((v.telefon || '').replace(/[^\d+]/g, '').length < 6) { toast('Im Datenabgleich ist eine Telefonnummer einzutragen.', 'err'); return; }
  await entwurfSpeichern();
  zeigeSchritt(2);
};
$('#btn-zu-trainer').onclick = async () => {
  try { await ladeMatching(); zeigeSchritt(3); }
  catch (e) { toast(`Matching fehlgeschlagen: ${e.message}`, 'err'); }
};
function zeichneKontrolle() {
  const v = sammleFelder();
  const abhaken = (S.settings.scan || {}).punkteAbhaken !== false;
  const artL = (S.regeln.arten[v.art] || {}).label || v.art;
  const punkte = [
    ['Name, Vorname', v.name], ['Geburtsdatum', fmt(v.geburtsdatum)], ['Kostenträger', `${v.kostentraeger || ''} (${(v.kostentraegerArt || '').toUpperCase()})`],
    ['Versichertennummer', v.versichertenNr], ['Formular', v.formular], ['Ausstellungsdatum', fmt(v.ausstellungsdatum)], ['Ärztin/Arzt', v.arztName],
    ['Maßnahme', artL], ['Zeitraum', `${fmt(v.von)} – ${fmt(v.bis)}`], ['Frequenz / Übungseinheiten', `${v.frequenzProWoche || '–'}×/Woche · ${v.uebungseinheiten || '–'} ÜE`],
    ['Diagnose(n) ICD-10', (v.icd10 || []).join(', ')], ['Ziele', v.ziele], ['Kostenübernahme', v.kostenuebernahme && v.kostenuebernahme.liegtVor ? `liegt vor ${fmt(v.kostenuebernahme.datum)}` : 'nicht vorhanden'],
    ['Folgeverordnung', v.folgeverordnung ? 'ja' : 'nein'], ['E-Mail / Telefon', `${v.email || '–'} · ${v.telefon || '–'}`],
  ];
  $('#scan-kontrolle').innerHTML = `<h2 style="font-size:15px">Kontrolle des Scans</h2>
    <p class="hint">${abhaken ? 'Jeden Punkt mit dem Original (Verordnung/Ausweis) vergleichen und abhaken – erst dann kann abgeschlossen werden.' : 'Zur Kontrolle: Angaben aus dem Scan.'}</p>
    ${punkte.map(([l, w]) => `<label class="check"><input type="checkbox" class="sk-punkt" ${abhaken ? '' : 'hidden'}> <strong>${esc(l)}:</strong> ${esc(w || '–')}</label>`).join('')}
    <label style="margin-top:8px">Angelegt von (Pflicht) *<input id="wiz-angelegt" list="angelegt-liste" value="${esc(localStorage.getItem('rhea.angelegtVon') || '')}" placeholder="Name der erfassenden Person"></label>
    <datalist id="angelegt-liste">${(S.trainer || []).map((t) => `<option value="${esc(t.vorname + ' ' + t.nachname)}">`).join('')}</datalist>`;
}
$('#btn-zu-gruppe').onclick = () => { zeichneGruppen(); zeichneKontrolle(); zeigeSchritt(4); };
$$('[data-goto-step]').forEach((b) => { b.onclick = () => zeigeSchritt(Number(b.dataset.gotoStep)); });

$('#btn-abschliessen').onclick = async () => {
  const v = sammleFelder();
  if (!WIZ.kursIds.length) { toast('Bitte mindestens eine feste Gruppe zuweisen.', 'err'); return; }
  if (!$('#chk-einwilligung').checked) { toast('Einwilligungserklärung (DSGVO) muss bestätigt sein.', 'err'); return; }
  if (!$('#chk-anmeldung').checked || !WIZ.sig) { toast('Anmeldung und digitale Unterschrift sind erforderlich.', 'err'); return; }
  const kontrollen = $$('.sk-punkt');
  if ((S.settings.scan || {}).punkteAbhaken !== false && kontrollen.some((c) => !c.checked)) { toast('Bitte alle Punkte der Scan-Kontrolle abhaken.', 'err'); return; }
  const angelegtVon = ($('#wiz-angelegt') || {}).value ? $('#wiz-angelegt').value.trim() : '';
  if (!angelegtVon) { toast('Bitte eintragen, wer den Patienten angelegt hat.', 'err'); return; }
  localStorage.setItem('rhea.angelegtVon', angelegtVon);
  const payload = {
    angelegtVon, scanKontrolliert: true, scanPunkte: kontrollen.length,
    ...v,
    trainerId: WIZ.trainerId, kursIds: WIZ.kursIds,
    einwilligung: { erteiltAm: new Date().toISOString(), textVersion: (S.settings.datenschutz || {}).textVersion || '', unterschriftPng: WIZ.sig },
    anmeldungUnterschrift: WIZ.sig, anmeldungDatum: heutigesISO(),
    abschliessen: true,
  };
  try {
    const r = await api('PUT', `/api/verordnungen/${v.id}`, payload);
    await reload(true);
    const mails = r.mails || [];
    const mailTxt = mails.map((m) => `• ${esc((m.an || []).join(', '))}: ${m.status === 'gesendet' ? '<span class="chip green">gesendet</span>' : m.status === 'konfiguration-offen' ? '<span class="chip amber">Entwurf (SMTP offen)</span>' : `<span class="chip red">Fehler: ${esc(m.fehler || '')}</span>`}<div class="muted small">${esc(m.betreff)}</div>`).join('');
    openModal('✔ Datenabgleich abgeschlossen', `
      <div class="hint" style="background:var(--green-l)">Die Verordnung ist <strong>vollständig</strong> und als <strong>aktiv</strong> markiert. Patient/in wurde angelegt und der festen Gruppe zugeordnet.</div>
      <h2 style="font-size:15px">Versandte Nachrichten</h2>
      ${mailTxt || '<div class="muted">Keine Nachrichten erzeugt.</div>'}
      <ul class="hint" style="background:var(--blue-l)">
        <li><strong>Patient/in</strong> erhält die Terminübersicht per E-Mail.</li>
        <li><strong>Führungspersonal</strong> erhält die Bestätigung, dass die Verordnung vollständig ist (inkl. Prüfprotokoll).</li>
      </ul>
      <p class="muted small">Hinweis: Abrechnung erst nach tatsächlich stattgefundenen Übungseinheiten mit digitaler Teilnahmebestätigung (Zeitstempel).</p>`,
      [{ label: 'Zur Übersicht', cls: 'btn primary', onClick: () => { closeModal(); resetWizard(); zeigeView('dashboard'); } },
       { label: 'Weitere Verordnung scannen', cls: 'btn', onClick: () => { closeModal(); resetWizard(); } }]);
  } catch (e) {
    if (e.daten && e.daten.pruefung) {
      WIZ.pruefung = e.daten.pruefung;
      zeigeSchritt(2);
      toast('Noch nicht vollständig – bitte die roten Punkte in der Prüfliste beheben.', 'err');
    } else toast(e.message, 'err');
  }
};

function resetWizard() {
  WIZ.v = null; WIZ.pruefung = null; WIZ.step = 1; WIZ.trainerId = null; WIZ.kursIds = []; WIZ.sig = null; WIZ.match = [];
  $('#scan-start').hidden = false; $('#wizard').hidden = true;
  $('#scan-code').value = ''; $('#scan-manuell-box').hidden = true; $('#scan-live').hidden = true;
  renderScan();
}

/* --- Scan-Optionen --- */
$$('#view-scan [data-f]').forEach((el) => {
  el.addEventListener('input', debounceEntwurf);
  el.addEventListener('change', debounceEntwurf);
});
$('#f-ku').addEventListener('change', debounceEntwurf);
$('#f-uee').addEventListener('change', () => { $('#f-uee-custom-wrap').hidden = $('#f-uee').value !== 'custom'; debounceEntwurf(); });
$('#f-uee-custom').addEventListener('input', debounceEntwurf);

/* Bekannte Formate (JSON/URL/RS56) gehen direkt an den Parser; PDF417-/Strichcode-Inhalte werden über RSD_OCR ausgewertet */
async function handleCode(raw, opts = {}) {
  stopKamera();
  try {
    const roh = String(raw || '').trim();
    const bekannt = /^\{/.test(roh) || /^https?:\/\//i.test(roh) || /^RS56/i.test(roh);
    let body = { code: roh };
    let info = '';
    if (!bekannt && window.RSD_OCR) {
      const b = window.RSD_OCR.parseBarcodeText(roh);
      body = { manuell: b.felder, format: opts.format || b.format, quelltext: roh };
      info = b.gefunden.length ? ` ${b.gefunden.length} Feld(er) übernommen.` : ' Inhalt nicht lesbar zuordenbar – bitte im Datenabgleich ergänzen.';
    }
    const r = await api('POST', '/api/verordnungen/scan', body);
    await reload(false);
    if (r.wiederholung) toast('Dieser Code wurde bereits erfasst – offener Abgleich geöffnet.');
    else toast(`Code erkannt – Datenabgleich geöffnet.${info}`, 'ok');
    window.fortsetzeAbgleich(r.verordnung.id);
  } catch (e) { toast(`Scan fehlgeschlagen: ${e.message}`, 'err'); }
}

/* --- Bibliotheken bei Bedarf nachladen (ZXing für PDF417, Tesseract für OCR) --- */
const _skripte = {};
function ladeSkript(url) {
  if (_skripte[url]) return _skripte[url];
  _skripte[url] = new Promise((res, rej) => {
    const el = document.createElement('script');
    el.src = url; el.onload = res; el.onerror = () => { delete _skripte[url]; rej(new Error(`Bibliothek fehlt: ${url}`)); };
    document.head.appendChild(el);
  });
  return _skripte[url];
}

/* --- Barcode-Erkennung: BarcodeDetector (QR/DataMatrix/PDF417), sonst jsQR + ZXing --- */
let _detector;
async function holeDetector() {
  if (_detector !== undefined) return _detector;
  _detector = null;
  try {
    if ('BarcodeDetector' in window) {
      const gewuenscht = ['qr_code', 'data_matrix', 'pdf417', 'code_128', 'aztec'];
      const unterstuetzt = window.BarcodeDetector.getSupportedFormats ? await window.BarcodeDetector.getSupportedFormats() : gewuenscht;
      const formate = gewuenscht.filter((f) => unterstuetzt.includes(f));
      if (formate.length) _detector = { det: new window.BarcodeDetector({ formats: formate }), formate };
    }
  } catch (_) { _detector = null; }
  return _detector;
}
let _zxing = null;
async function holeZxing() {
  if (_zxing) return _zxing;
  try {
    if (!window.ZXing) await ladeSkript('/vendor/zxing.js');
    const Z = window.ZXing;
    const hints = new Map();
    hints.set(Z.DecodeHintType.POSSIBLE_FORMATS, [Z.BarcodeFormat.PDF_417, Z.BarcodeFormat.QR_CODE, Z.BarcodeFormat.DATA_MATRIX]);
    hints.set(Z.DecodeHintType.TRY_HARDER, true);
    const reader = new Z.MultiFormatReader();
    reader.setHints(hints);
    _zxing = { Z, reader };
  } catch (_) { _zxing = null; }
  return _zxing;
}
/* quelle: <video>, <img> oder <canvas>. Gibt den Rohtext oder null zurück.
   optionen: max (längste Kante in px), drehen (90 = Quer-/Hochformat tauschen), nurZxing */
async function dekodiereQuelle(quelle, optionen = {}) {
  const det = await holeDetector();
  if (det && !optionen.drehen) {
    try {
      const codes = await det.det.detect(quelle);
      if (codes.length) return codes[0].rawValue;
    } catch (_) { /* weiter */ }
  }
  const breite = quelle.videoWidth || quelle.naturalWidth || quelle.width;
  const hoehe = quelle.videoHeight || quelle.naturalHeight || quelle.height;
  if (!breite || !hoehe) return null;
  const max = optionen.max || 1600;
  const sk = Math.min(1, max / Math.max(breite, hoehe));
  const w = Math.round(breite * sk), h = Math.round(hoehe * sk);
  const c = document.createElement('canvas');
  const dreh = optionen.drehen === 90;
  c.width = dreh ? h : w; c.height = dreh ? w : h;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  if (dreh) { ctx.translate(c.width, 0); ctx.rotate(Math.PI / 2); }
  ctx.drawImage(quelle, 0, 0, w, h);
  if (dreh) ctx.setTransform(1, 0, 0, 1, 0, 0);
  if (window.jsQR && !optionen.nurZxing) {
    const d = ctx.getImageData(0, 0, c.width, c.height);
    const erg = window.jsQR(d.data, d.width, d.height);
    if (erg && erg.data) return erg.data;
  }
  if (optionen.ohneZxing) return null;
  const zx = await holeZxing();
  if (zx) {
    const { Z, reader } = zx;
    const lum = new Z.HTMLCanvasElementLuminanceSource(c);
    for (const Binarizer of [Z.HybridBinarizer, Z.GlobalHistogramBinarizer]) {
      try {
        const res = reader.decode(new Z.BinaryBitmap(new Binarizer(lum)));
        if (res && res.getText()) return res.getText();
      } catch (_) { /* nichts gefunden – nächster Binarizer */ }
    }
  }
  return null;
}
/* Foto/Bild: mehrere Auflösungen und Drehungen durchprobieren (PDF417 ist breit und fein) */
async function dekodiereBildGruendlich(quelle) {
  for (const drehen of [0, 90]) {
    for (const max of [2400, 1600, 1000]) {
      const raw = await dekodiereQuelle(quelle, { max, drehen });
      if (raw) return raw;
    }
  }
  return null;
}

$('#btn-manuell').onclick = () => { $('#scan-manuell-box').hidden = false; $('#scan-code').focus(); };
$('#btn-scan-code').onclick = () => {
  const raw = $('#scan-code').value.trim();
  if (!raw) { toast('Bitte Code eingeben.', 'err'); return; }
  handleCode(raw);
};
$('#btn-scan-vollstaendig-manuell').onclick = async () => {
  const r = await api('POST', '/api/verordnungen/scan', { manuell: {} });
  await reload(false);
  window.fortsetzeAbgleich(r.verordnung.id);
};

/* Kamera / Bild */
let kameraStream = null, kameraTimer = null;
async function startKamera() {
  $('#scan-manuell-box').hidden = true;
  try {
    kameraStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } } });
  } catch (e) {
    toast('Kein Kamerazugriff – bitte Code eingeben oder ein Bild mit QR-/PDF417-Code wählen.', 'err');
    $('#scan-manuell-box').hidden = false;
    return;
  }
  const video = $('#scan-video');
  $('#scan-live').hidden = false;
  video.srcObject = kameraStream;
  await video.play();
  let laeuft = false, takt = 0;
  const VARIANTEN = [{ max: 1920 }, { max: 1280 }, { max: 1920, drehen: 90 }];
  kameraTimer = setInterval(async () => {
    if (!kameraStream || laeuft || !video.videoWidth) return;
    laeuft = true;
    try {
      const raw = await dekodiereQuelle(video, VARIANTEN[takt++ % VARIANTEN.length]);
      if (raw) handleCode(raw);
    } catch (_) { /* Frame überspringen */ } finally { laeuft = false; }
  }, 350);
}
function stopKamera() {
  clearInterval(kameraTimer); kameraTimer = null;
  if (kameraStream) { kameraStream.getTracks().forEach((t) => t.stop()); kameraStream = null; }
  $('#scan-live').hidden = true;
}
$('#btn-kamera').onclick = startKamera;
$('#btn-kamera-stop').onclick = stopKamera;

async function ladeBild(file) {
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = url; });
    return img;
  } finally { setTimeout(() => URL.revokeObjectURL(url), 30000); }
}
$('#qr-file').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const img = await ladeBild(file);
    const raw = await dekodiereBildGruendlich(img);
    if (raw) await handleCode(raw);
    else toast('Kein Code (QR/DataMatrix/PDF417) im Bild erkannt. Bitte näher/schärfer fotografieren oder „Foto auslesen (OCR)“ nutzen.', 'err');
  } catch (err) {
    toast(`Bild konnte nicht gelesen werden: ${err.message}`, 'err');
  } finally { e.target.value = ''; }
});

/* ======================= Foto-OCR (Tesseract, komplett offline) ======================= */
function bereiteOcrBildVor(img) {
  const lang = Math.max(img.naturalWidth || img.width, img.naturalHeight || img.height);
  const sk = lang > 2600 ? 2600 / lang : (lang < 1600 ? Math.min(2, 1800 / lang) : 1);
  const c = document.createElement('canvas');
  c.width = Math.round((img.naturalWidth || img.width) * sk); c.height = Math.round((img.naturalHeight || img.height) * sk);
  const ctx = c.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(img, 0, 0, c.width, c.height);
  const d = ctx.getImageData(0, 0, c.width, c.height);
  const px = d.data;
  let min = 255, max = 0;
  for (let i = 0; i < px.length; i += 4) {
    const g = Math.round(0.299 * px[i] + 0.587 * px[i + 1] + 0.114 * px[i + 2]);
    px[i] = px[i + 1] = px[i + 2] = g;
    if (g < min) min = g; if (g > max) max = g;
  }
  const spanne = Math.max(1, max - min);
  for (let i = 0; i < px.length; i += 4) {
    const v = Math.max(0, Math.min(255, ((px[i] - min) * 255) / spanne));
    px[i] = px[i + 1] = px[i + 2] = v;
  }
  ctx.putImageData(d, 0, 0);
  return c;
}
async function erkenneText(canvas, fortschritt) {
  await ladeSkript('/vendor/tesseract/tesseract.min.js');
  const basis = `${location.origin}/vendor/tesseract`;
  const worker = await window.Tesseract.createWorker('deu', 1, {
    workerPath: `${basis}/worker.min.js`,
    corePath: basis,
    langPath: `${basis}/lang`,
    gzip: true,
    workerBlobURL: false,
    cacheMethod: 'none',
    logger: (m) => { if (m && m.status === 'recognizing text' && fortschritt) fortschritt(Math.round((m.progress || 0) * 100)); },
  });
  try {
    await worker.setParameters({ preserve_interword_spaces: '1', tessedit_pageseg_mode: '4' });
    const { data } = await worker.recognize(canvas);
    return data.text || '';
  } finally { try { await worker.terminate(); } catch (_) { /* ignorieren */ } }
}
const FELD_NAMEN = {
  name: 'Name', geburtsdatum: 'Geburtsdatum', kostentraeger: 'Kostenträger', versichertenNr: 'Versicherten-Nr.', ausstellungsdatum: 'Ausstellung',
  von: 'von', bis: 'bis', art: 'Art', frequenzProWoche: 'Frequenz/Woche', uebungseinheiten: 'Übungseinheiten', icd10: 'ICD-10',
  arztName: 'Ärztin/Arzt', ziele: 'Ziele', folgeverordnung: 'Folgeverordnung', formular: 'Formular', kostentraegerArt: 'Kostenträgerart',
};
function ocrFelderHtml(felder) {
  const zeilen = Object.entries(felder).filter(([k]) => FELD_NAMEN[k]).map(([k, v]) =>
    `<tr><td class="muted">${esc(FELD_NAMEN[k])}</td><td><strong>${esc(Array.isArray(v) ? v.join(', ') : (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) ? fmt(v) : v))}</strong></td></tr>`).join('');
  return zeilen ? `<table class="mini-table">${zeilen}</table>` : '<div class="muted">Keine Felder sicher erkannt – Text unten korrigieren oder im Datenabgleich manuell erfassen.</div>';
}
function zeigeOcrErgebnis(text, barcodeRoh, quelleName) {
  let felder = {};
  const auswerten = () => {
    const o = window.RSD_OCR.parseOcrText($('#ocr-text').value);
    felder = Object.assign({}, o.felder);
    if (barcodeRoh) {
      const b = window.RSD_OCR.parseBarcodeText(barcodeRoh);
      felder = Object.assign(felder, b.felder); // Barcode-Werte haben Vorrang
    }
    $('#ocr-felder').innerHTML = ocrFelderHtml(felder);
  };
  openModal('Verordnung ausgelesen', `
    <p class="hint">${barcodeRoh ? '✔ Barcode im Foto gefunden und ausgewertet. ' : ''}Bitte <strong>alle Werte im nächsten Schritt prüfen</strong> – OCR kann sich verlesen (besonders Ziffern in ICD-Codes und Versicherten-Nr.).</p>
    <div id="ocr-felder"></div>
    <label style="display:block;margin-top:10px">Erkannter Text (korrigierbar)
      <textarea id="ocr-text" rows="9" style="width:100%;font-family:monospace;font-size:12px"></textarea></label>`,
  [
    { label: 'Neu auswerten', cls: 'btn', onClick: () => auswerten() },
    { label: 'Abbrechen', cls: 'btn', onClick: () => closeModal() },
    { label: '✔ Übernehmen & Datenabgleich öffnen', cls: 'btn primary', onClick: async () => {
      auswerten();
      const quell = barcodeRoh ? `${barcodeRoh}\n---\n${$('#ocr-text').value}` : $('#ocr-text').value;
      closeModal();
      try {
        const r = await api('POST', '/api/verordnungen/scan', { manuell: felder, format: barcodeRoh ? 'foto-barcode+ocr' : 'foto-ocr', quelltext: quell });
        await reload(false);
        toast(r.wiederholung ? 'Bereits erfasst – offener Abgleich geöffnet.' : 'Foto ausgewertet – Datenabgleich geöffnet.', 'ok');
        window.fortsetzeAbgleich(r.verordnung.id);
      } catch (e) { toast(`Übernahme fehlgeschlagen: ${e.message}`, 'err'); }
    } },
  ], { wide: true });
  $('#ocr-text').value = text;
  auswerten();
}
$('#ocr-file').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  stopKamera();
  openModal('Verordnung wird ausgelesen …', '<div id="ocr-status">Bild wird vorbereitet …</div><div class="muted small">Die Texterkennung läuft komplett auf diesem Gerät (keine Übertragung).</div>', [], { wide: false });
  const status = (t) => { const el = $('#ocr-status'); if (el) el.textContent = t; };
  try {
    const img = await ladeBild(file);
    status('Suche Barcode (PDF417/QR) im Foto …');
    const barcode = await dekodiereBildGruendlich(img);
    status('Texterkennung (OCR) läuft … 0 %');
    const canvas = bereiteOcrBildVor(img);
    const text = await erkenneText(canvas, (p) => status(`Texterkennung (OCR) läuft … ${p} %`));
    closeModal();
    if (!text.trim() && !barcode) { toast('Es konnte kein Text erkannt werden. Bitte gerade, hell und scharf fotografieren.', 'err'); return; }
    zeigeOcrErgebnis(text, barcode, file.name);
  } catch (err) {
    closeModal();
    toast(`OCR fehlgeschlagen: ${err.message}. Alternativ Code eingeben oder manuell erfassen.`, 'err');
  }
});
$('#btn-foto').onclick = () => $('#ocr-file').click();

/* ============================== Filterleisten (Suche, Auswahl, Sortierung) ============================== */
const FILTER_STATE = {};
/** Filterleiste über einer Liste. Blendet Einträge per Text/Auswahl ein/aus und sortiert – ohne die Liste neu zu rendern. */
function installFilter(hostSel, itemSel, cfg = {}) {
  const host = document.querySelector(hostSel);
  if (!host) return;
  const key = hostSel.replace(/\W+/g, '_');
  const st = FILTER_STATE[key] = FILTER_STATE[key] || { q: '', sel: {}, sort: '' };
  const anchor = cfg.anchor ? host.closest(cfg.anchor) || host : host;
  let bar = document.getElementById(`fb-${key}`);
  if (!bar) { bar = document.createElement('div'); bar.id = `fb-${key}`; bar.className = 'filterbar'; anchor.parentNode.insertBefore(bar, anchor); }
  bar.innerHTML = `<label class="small">Suche<input type="search" class="fb-q" value="${esc(st.q)}" placeholder="${esc(cfg.placeholder || 'Suchen …')}"></label>`
    + (cfg.selects || []).map((f) => `<label class="small">${esc(f.label)}<select data-f="${f.id}"><option value="">alle</option>${f.options.map(([v, l]) => `<option value="${esc(v)}" ${st.sel[f.id] === v ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`).join('')
    + (cfg.sorts ? `<label class="small">Sortieren<select class="fb-sort"><option value="">Standard</option>${cfg.sorts.map((s) => `<option value="${s.id}" ${st.sort === s.id ? 'selected' : ''}>${esc(s.label)}</option>`).join('')}</select></label>` : '')
    + '<span class="muted small fb-z"></span>';
  const wende = () => {
    const items = [...host.querySelectorAll(itemSel)];
    items.forEach((el, i) => { if (el.dataset.o === undefined) el.dataset.o = String(i); });
    const q = st.q.trim().toLowerCase();
    let sichtbar = 0;
    for (const el of items) {
      let ok = !q || el.textContent.toLowerCase().includes(q);
      for (const f of cfg.selects || []) { const v = st.sel[f.id]; if (ok && v) ok = f.match(el, v); }
      el.hidden = !ok; if (ok) sichtbar++;
    }
    const sort = (cfg.sorts || []).find((s) => s.id === st.sort);
    const reihe = items.slice().sort((a, b) => (sort ? sort.key(a).localeCompare(sort.key(b), 'de', { numeric: true }) * (sort.dir || 1) : Number(a.dataset.o) - Number(b.dataset.o)));
    reihe.forEach((el) => el.parentNode.appendChild(el));
    const z = bar.querySelector('.fb-z'); if (z) z.textContent = items.length ? `${sichtbar} von ${items.length}` : '';
    if (cfg.after) cfg.after(host);
  };
  bar.querySelector('.fb-q').oninput = (e) => { st.q = e.target.value; wende(); };
  bar.querySelectorAll('select[data-f]').forEach((s) => { s.onchange = () => { st.sel[s.dataset.f] = s.value; wende(); }; });
  const so = bar.querySelector('.fb-sort'); if (so) so.onchange = () => { st.sort = so.value; wende(); };
  wende();
}
const nameKey = (el) => (el.querySelector('h3, strong, .t') || el).textContent.trim();
const SORT_NAME = [{ id: 'az', label: 'Name A–Z', key: nameKey }, { id: 'za', label: 'Name Z–A', key: nameKey, dir: -1 }];
const aktivFilter = { id: 'status', label: 'Status', options: [['aktiv', 'aktiv'], ['inaktiv', 'inaktiv']], match: (el, v) => (v === 'inaktiv') === el.classList.contains('nein') };

function filterTrainer() {
  installFilter('#trainer-karten', '.karte', { placeholder: 'Name, Qualifikation …', sorts: SORT_NAME,
    selects: [aktivFilter,
      { id: 'qual', label: 'Qualifikation', options: (S.regeln.qualifikationen || []).map((q) => [q.label, q.label]), match: (el, v) => el.textContent.includes(v) },
      { id: 'anerk', label: 'BAR/RSD', options: [['ja', 'anerkannt'], ['nein', 'keine Anerkennung']], match: (el, v) => (v === 'ja') === el.textContent.includes('BAR/RSD ✓') }] });
}
function filterKurse() {
  installFilter('#kurs-liste', '.karte', { placeholder: 'Gruppe, Ort, Übungsleitung …', sorts: SORT_NAME,
    selects: [aktivFilter,
      { id: 'art', label: 'Maßnahme', options: Object.values(S.regeln.arten).map((a) => [a.label, a.label]), match: (el, v) => el.textContent.includes(v) },
      { id: 'tag', label: 'Wochentag', options: WOCHENTAGE_LANG.map((n) => [n, n]).filter(([n]) => n), match: (el, v) => el.textContent.includes(v) },
      { id: 'tr', label: 'Übungsleitung', options: (S.trainer || []).map((t) => [`${t.vorname} ${t.nachname}`, `${t.vorname} ${t.nachname}`]), match: (el, v) => el.textContent.includes(v) }] });
}
function filterPostfach() {
  installFilter('#outbox-tabelle tbody', 'tr', { anchor: '.table-wrap', placeholder: 'Empfänger, Betreff …',
    selects: [{ id: 'st', label: 'Status', options: [['gesendet', 'gesendet'], ['Entwurf', 'Entwurf'], ['Fehler', 'Fehler']], match: (el, v) => el.textContent.toLowerCase().includes(v.toLowerCase()) },
      { id: 'typ', label: 'Art', options: [['Patient: Termine', 'Patient: Termine'], ['Vollständigkeit', 'Vollständigkeit'], ['Abrechnung', 'Abrechnung']], match: (el, v) => el.textContent.includes(v) }] });
}
function filterAbgleich() {
  installFilter('#offene-abgleiche', '.item', { placeholder: 'Name, Maßnahme …', sorts: SORT_NAME });
}
/* Kalender: Filter nach Übungsleitung/Gruppe/Status */
const KAL_FILTER = { trainer: '', kurs: '', status: '' };
function kalenderFilterLeiste() {
  const grid = $('#kalender-grid');
  let bar = $('#fb-kalender');
  if (!bar) { bar = document.createElement('div'); bar.id = 'fb-kalender'; bar.className = 'filterbar'; grid.parentNode.insertBefore(bar, grid); }
  bar.innerHTML = `<label class="small">Übungsleitung<select data-k="trainer"><option value="">alle</option>${(S.trainer || []).map((t) => `<option value="${t.id}" ${KAL_FILTER.trainer === t.id ? 'selected' : ''}>${esc(t.vorname)} ${esc(t.nachname)}</option>`).join('')}</select></label>
    <label class="small">Gruppe<select data-k="kurs"><option value="">alle</option>${(S.kurse || []).map((k) => `<option value="${k.id}" ${KAL_FILTER.kurs === k.id ? 'selected' : ''}>${esc(k.titel)}</option>`).join('')}</select></label>
    <label class="small">Status<select data-k="status"><option value="">alle</option>${['geplant', 'stattgefunden', 'ausgefallen', 'verschoben'].map((s) => `<option ${KAL_FILTER.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label>`;
  bar.querySelectorAll('select').forEach((s) => { s.onchange = () => { KAL_FILTER[s.dataset.k] = s.value; renderKalender(); }; });
}
const kalenderFiltern = (liste) => liste.filter((t) => (!KAL_FILTER.trainer || t.kurs.trainerId === KAL_FILTER.trainer) && (!KAL_FILTER.kurs || t.kursId === KAL_FILTER.kurs || (t.kurs && t.kurs.id === KAL_FILTER.kurs)) && (!KAL_FILTER.status || t.status === KAL_FILTER.status));

/* Patienten: zusätzliche Filter (Kostenträger, Maßnahme, Übungsleitung, Mängel) */
const PAT_X = { kt: '', art: '', tr: '', mangel: '' };
function patientenExtraLeiste() {
  const anker = $('#pat-sort').closest('label');
  let bar = $('#pat-extra');
  if (!bar) { bar = document.createElement('div'); bar.id = 'pat-extra'; bar.className = 'filterbar'; anker.parentNode.insertAdjacentElement('afterend', bar); }
  const kts = [...new Set((S.verordnungen || []).map((v) => v.kostentraeger).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'de'));
  const arten = [...new Set((S.verordnungen || []).map((v) => v.art).filter(Boolean))];
  const opt = (v, sel, l) => `<option value="${esc(v)}" ${sel === v ? 'selected' : ''}>${esc(l)}</option>`;
  bar.innerHTML = `<label class="small">Kostenträger<select data-x="kt"><option value="">alle</option>${kts.map((k) => opt(k, PAT_X.kt, k)).join('')}</select></label>
    <label class="small">Maßnahme<select data-x="art"><option value="">alle</option>${arten.map((a) => opt(a, PAT_X.art, (S.regeln.arten[a] || {}).label || a)).join('')}</select></label>
    <label class="small">Übungsleitung<select data-x="tr"><option value="">alle</option>${(S.trainer || []).map((t) => opt(t.id, PAT_X.tr, `${t.vorname} ${t.nachname}`)).join('')}</select></label>
    <label class="small">Offene Punkte<select data-x="mangel"><option value="">alle</option>${[['unterschrift', 'Unterschrift fehlt'], ['beratung', 'Beratungsprotokoll fehlt'], ['genehmigung', 'Genehmigung/Kennzeichen fehlt'], ['abbruch', 'Verordnung abgebrochen']].map(([v, l]) => opt(v, PAT_X.mangel, l)).join('')}</select></label>
    <span class="muted small" id="pat-zaehler"></span>`;
  bar.querySelectorAll('select').forEach((s) => { s.onchange = () => { PAT_X[s.dataset.x] = s.value; renderPatienten(); }; });
}
function patientPasstX(p, vs) {
  if (PAT_X.kt && !vs.some((v) => v.kostentraeger === PAT_X.kt)) return false;
  if (PAT_X.art && !vs.some((v) => v.art === PAT_X.art)) return false;
  if (PAT_X.tr && !vs.some((v) => zuordnungenFuerVerordnung(v.id).some((z) => ((S.kurse || []).find((k) => k.id === z.kursId) || {}).trainerId === PAT_X.tr))) return false;
  if (PAT_X.mangel === 'unterschrift') return fehlendeUnterschriften(p.id).length > 0;
  if (PAT_X.mangel === 'beratung') return vs.some((v) => bpBraucht(v) && !v.beratungsprotokoll);
  if (PAT_X.mangel === 'genehmigung') return vs.some((v) => ['aktiv', 'vollstaendig'].includes(v.status) && !(v.kostenuebernahme && v.kostenuebernahme.kennzeichen));
  if (PAT_X.mangel === 'abbruch') return vs.some((v) => v.status === 'abgebrochen');
  return true;
}

/* ============================== PATIENTEN ============================== */
function verordnungFuerPatient(pid) {
  return (S.verordnungen || []).filter((v) => v.patientId === pid);
}
function statusChip(status) {
  const map = { abgleich: ['amber', 'Datenabgleich'], vollstaendig: ['green', 'vollständig'], aktiv: ['green', 'aktiv'], abgeschlossen: ['blue', 'abgeschlossen'], abgerechnet: ['purple', 'abgerechnet'], abgebrochen: ['red', 'abgebrochen'] };
  const [c, t] = map[status] || ['gray', status];
  return `<span class="chip ${c}">${t}</span>`;
}
const TRAINER_FARBEN = ['#0b6b6b', '#d9480f', '#5f3dc4', '#1971c2', '#c2255c', '#2b8a3e', '#e67700', '#495057'];
function trainerFarbe(tid) {
  const i = (S.trainer || []).findIndex((t) => t.id === tid);
  const t = (S.trainer || [])[i];
  return (t && t.farbe) || TRAINER_FARBEN[(i < 0 ? 0 : i) % TRAINER_FARBEN.length];
}
const farbPunkt = (tid) => `<span class="fdot" style="background:${trainerFarbe(tid)}"></span>`;
const pLink = (pid, text) => (pid ? `<a href="#" class="golink" data-gp="${pid}">${esc(text)}</a>` : esc(text));
const tLink = (tid, text) => (tid ? `<a href="#" class="golink" data-gt="${tid}">${farbPunkt(tid)}${esc(text)}</a>` : esc(text));
const trainerName = (tid) => { const t = (S.trainer || []).find((x) => x.id === tid); return t ? `${t.vorname} ${t.nachname}` : '–'; };
document.addEventListener('click', (e) => {
  const a = e.target.closest && e.target.closest('[data-gp],[data-gt]');
  if (!a) return;
  e.preventDefault();
  if (a.dataset.gp) window.gotoPatient(a.dataset.gp); else window.gotoTrainer(a.dataset.gt);
});
window.gotoPatient = (pid) => { closeModal(); zeigeView('patienten'); setTimeout(() => window.oeffnePatient(pid), 60); };
window.gotoTrainer = (tid) => {
  closeModal(); zeigeView('trainer');
  setTimeout(() => { const el = document.getElementById(`trk-${tid}`); if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 2400); } }, 80);
};
function kursname(kid) { const k = (S.kurse || []).find((x) => x.id === kid); return k ? k.titel : kid; }
function zuordnungenFuerVerordnung(vid) {
  return (S.zuordnungen || []).filter((z) => z.verordnungId === vid && z.aktiv !== false);
}

function renderPatienten() {
  patientenExtraLeiste();
  const such = ($('#pat-suche').value || '').toLowerCase();
  const filter = $('#pat-filter').value, gruppe = $('#pat-gruppe').value, sort = $('#pat-sort').value;
  const gSel = $('#pat-gruppe');
  if (gSel.options.length - 1 !== (S.kurse || []).length) {
    gSel.innerHTML = '<option value="">alle</option>' + (S.kurse || []).map((k) => `<option value="${k.id}">${esc(k.titel)}</option>`).join('');
    gSel.value = gruppe;
  }
  const info = (p) => {
    const vs = verordnungFuerPatient(p.id);
    const aktiv = vs.find((v) => v.status === 'aktiv') || vs[0];
    const kid = aktiv ? zuordnungenFuerVerordnung(aktiv.id).map((z) => z.kursId) : [];
    return { vs, aktiv, kid };
  };
  const liste = (S.patienten || [])
    .filter((p) => !such || `${p.nachname} ${p.vorname} ${p.email} ${p.telefon} ${verordnungFuerPatient(p.id).map((v) => `${v.versichertenNr || ''} ${v.kostentraeger || ''} ${v.angelegtVon || ''}`).join(' ')}`.toLowerCase().includes(such))
    .filter((p) => {
      const { vs, kid } = info(p);
      if (!patientPasstX(p, vs)) return false;
      if (gruppe && !kid.includes(gruppe)) return false;
      if (!filter) return true;
      if (filter === 'keine') return !vs.length;
      if (filter === 'ohne-einwilligung') return !p.einwilligung;
      return vs.some((v) => v.status === filter);
    });
  const cmp = {
    name: (x, y) => x.nachname.localeCompare(y.nachname, 'de') || x.vorname.localeCompare(y.vorname, 'de'),
    'name-z': (x, y) => y.nachname.localeCompare(x.nachname, 'de'),
    geb: (x, y) => String(x.geburtsdatum || '').localeCompare(String(y.geburtsdatum || '')),
    ende: (x, y) => String((info(x).aktiv || {}).bis || '9999').localeCompare(String((info(y).aktiv || {}).bis || '9999')),
    kt: (x, y) => String((info(x).aktiv || {}).kostentraeger || 'zzz').localeCompare(String((info(y).aktiv || {}).kostentraeger || 'zzz'), 'de'),
    neu: (x, y) => String(y.angelegtAm || y.id).localeCompare(String(x.angelegtAm || x.id)),
  }[sort] || ((x, y) => 0);
  const rows = liste.sort(cmp)
    .map((p) => {
      const { aktiv, kid } = info(p);
      return `<tr>
        <td><strong>${pLink(p.id, `${p.nachname}, ${p.vorname}`)}</strong></td>
        <td>${fmt(p.geburtsdatum)}</td>
        <td><div>${esc(p.email || '–')}</div><div class="muted small">${esc(p.telefon || '–')}</div></td>
        <td>${aktiv ? `${statusChip(aktiv.status)} <span class="muted small">${aktiv.uebungseinheiten} ÜE · ${fmt(aktiv.von)}–${fmt(aktiv.bis)}</span>${aktiv.abbruch ? `<div class="muted small">Grund: ${esc(aktiv.abbruch.grund)}</div>` : ''}` : '<span class="chip amber">keine Verordnung</span>'}</td>
        <td>${kid.map((k) => `<span class="chip blue">${esc(kursname(k))}</span>`).join(' ') || '–'}</td>
        <td>${p.einwilligung ? '<span class="chip green">DSGVO ✓</span>' : '<span class="chip red">Einwilligung fehlt</span>'}</td>
        <td class="row"><button class="btn small" onclick="oeffnePatient('${p.id}')">Öffnen</button> <button class="btn small" onclick="druckDialog('${p.id}')" ${info(p).vs.length ? '' : 'disabled'}>🖨 Drucken</button></td>
      </tr>`;
    }).join('');
  $('#pat-tabelle tbody').innerHTML = rows || '<tr><td colspan="7" class="muted">Keine Patienten gefunden.</td></tr>';
  const zz = $('#pat-zaehler'); if (zz) zz.textContent = `${liste.length} von ${(S.patienten || []).length} Patienten`;
}
['#pat-filter', '#pat-gruppe', '#pat-sort'].forEach((id) => $(id).addEventListener('change', renderPatienten));
$('#pat-suche').addEventListener('input', renderPatienten);

$('#btn-neuer-patient').onclick = () => {
  openModal('Neue/r Patient/in anlegen', `
    <div class="form2">
      <label>Vorname *<input id="np-vor"></label>
      <label>Nachname *<input id="np-nach"></label>
      <label>Geburtsdatum *<input type="date" id="np-geb"></label>
      <label>Telefon<input id="np-tel"></label>
      <label class="span2">E-Mail<input id="np-mail" type="email"></label>
      <label>Straße/Nr.<input id="np-str"></label>
      <div class="row" style="align-items:flex-end"><label>PLZ<input id="np-plz"></label><label>Ort<input id="np-ort"></label></div>
      <label class="span2">Bemerkung<textarea id="np-bem" rows="2"></textarea></label>
      <label class="span2">Angelegt von (Pflicht) *<input id="np-von" list="angelegt-liste" value="${esc(localStorage.getItem('rhea.angelegtVon') || '')}" placeholder="Name der erfassenden Person"></label>
      <datalist id="angelegt-liste">${(S.trainer || []).map((t) => `<option value="${esc(t.vorname + ' ' + t.nachname)}">`).join('')}</datalist>
    </div>
    <p class="hint">Empfehlung (RSD): Stammdaten &amp; Unterschrift möglichst direkt an der Rezeption erfassen. Eine Verordnung kann anschließend per Scan zugeordnet werden.</p>`,
    [
      { label: 'Abbrechen', cls: 'btn', onClick: closeModal },
      { label: 'Anlegen', cls: 'btn primary', onClick: async () => {
        if (!$('#np-von').value.trim()) { toast('Bitte eintragen, wer den Patienten angelegt hat.', 'err'); return; }
        localStorage.setItem('rhea.angelegtVon', $('#np-von').value.trim());
        try {
          await api('POST', '/api/patienten', {
            angelegtVon: $('#np-von').value.trim(),
            vorname: $('#np-vor').value.trim(), nachname: $('#np-nach').value.trim(), geburtsdatum: $('#np-geb').value,
            email: $('#np-mail').value.trim(), telefon: $('#np-tel').value.trim(),
            strasse: $('#np-str').value.trim(), plz: $('#np-plz').value.trim(), ort: $('#np-ort').value.trim(),
            bemerkung: $('#np-bem').value.trim(),
          });
          closeModal(); await reload(true); toast('Patient/in angelegt.', 'ok');
        } catch (e) { toast(e.message, 'err'); }
      } },
    ]);
};

window.verordnungAbbrechen = (vid) => {
  const v = (S.verordnungen || []).find((x) => x.id === vid);
  if (!v) return;
  const gruende = ['Patient/in hat abgebrochen', 'Krankheit / Krankenhausaufenthalt', 'Umzug', 'Kostenträger hat Leistung beendet', 'Ärztlicher Rat', 'Nicht erschienen / nicht erreichbar', 'Sonstiges'];
  openModal('Verordnung abbrechen', `
    <p class="hint">Bereits erbrachte und unterschriebene Übungseinheiten bleiben abrechenbar. Die Zuordnung zur Gruppe endet.</p>
    <div class="form2">
      <label>Abbruchdatum<input type="date" id="ab-datum" value="${heutigesISO()}"></label>
      <label>Grund *<select id="ab-sel">${gruende.map((g) => `<option>${esc(g)}</option>`).join('')}</select></label>
      <label class="span2">Begründung / Details *<textarea id="ab-text" rows="3" placeholder="z. B. Umzug nach …, ab 12.11. keine Teilnahme mehr"></textarea></label>
    </div>`,
    [
      { label: 'Zurück', cls: 'btn', onClick: closeModal },
      { label: 'Verordnung abbrechen', cls: 'btn danger', onClick: async () => {
        const grund = `${$('#ab-sel').value}${$('#ab-text').value.trim() ? ' – ' + $('#ab-text').value.trim() : ''}`;
        if (!$('#ab-text').value.trim()) { toast('Bitte eine Begründung eintragen.', 'err'); return; }
        try {
          const r = await api('POST', `/api/verordnungen/${vid}/abbruch`, { grund, datum: $('#ab-datum').value });
          closeModal(); await reload(true);
          toast(r.kalenderEntfernt ? `Verordnung abgebrochen – ${r.kalenderEntfernt} künftige Kalendereinträge entfernt.` : 'Verordnung abgebrochen.', 'ok');
          if (r.kalenderEntfernt && window.RheaGoogle) {
            try { const gs = await RheaGoogle.status(); if (gs && (gs.verbunden || gs.angemeldet)) { await RheaGoogle.kalenderAbgleichen({ termine: S.termine || [], kurse: S.kurse || [], trainer: S.trainer || [], titel: (S.settings.kalender || {}).titel, heute: heutigesISO(), tage: 60 }); toast('Google-Kalender aktualisiert.', 'ok'); } } catch (_) { /* Abgleich manuell in den Einstellungen */ }
          }
        }
        catch (e) { toast(e.message, 'err'); }
      } },
    ]);
};

window.oeffnePatient = async (pid) => {
  const p = (S.patienten || []).find((x) => x.id === pid);
  if (!p) return;
  const vs = verordnungFuerPatient(pid);
  let termine = [], anw = [], abrZeilen = [];
  try {
    [termine, anw, abrZeilen] = await Promise.all([
      api('GET', `/api/patienten/${pid}/termine`).then((r) => r.termine),
      api('GET', `/api/patienten/${pid}/anwesenheit`).then((r) => r.anwesenheit),
      api('GET', '/api/abrechnung').then((r) => r.zeilen || []),
    ]);
  } catch (_) { /* egal */ }

  const vHtml = vs.map((v) => {
    const kid = zuordnungenFuerVerordnung(v.id);
    const erb = v.erbrachteUee ?? (v.abrechnung && v.abrechnung.uee) ?? '–';
    return `<div class="item"><div>
      <strong>${esc((S.regeln.arten[v.art] || {}).label || v.art)}</strong> ${statusChip(v.status)}
      <div class="muted small">${fmt(v.von)} – ${fmt(v.bis)} · ${v.uebungseinheiten} ÜE · ${v.frequenzProWoche}×/Woche · erbracht: ${erb} · ${esc(v.kostentraeger || '')}</div>
      ${v.annahmeDatum || v.anmeldungDatum ? `<div class="muted small">Verordnung angenommen am ${fmt(v.annahmeDatum || v.anmeldungDatum)}${v.angelegtVon ? ' · angelegt von ' + esc(v.angelegtVon) : ''}</div>` : ''}
      ${v.abbruch ? `<div class="errline">Abgebrochen am ${fmt(v.abbruch.datum)} – Grund: ${esc(v.abbruch.grund)}</div>` : ''}
      <div>${kid.map((z) => `<span class="chip blue">${esc(kursname(z.kursId))}</span>`).join(' ')}</div>
    </div><div class="row">
      ${['abgleich', 'vollstaendig', 'aktiv'].includes(v.status) ? `<button class="btn small danger" onclick="verordnungAbbrechen('${v.id}')">Abbrechen</button>` : ''}
      ${kid.length ? `<button class="btn small" onclick="gruppeAendern('${v.id}')">Gruppe ändern</button>` : ''}
      <button class="btn small" onclick="oeffneVerordnung('${v.id}')">Details/Code</button>
    </div></div>`;
  }).join('') || '<div class="muted">Keine Verordnung – per Scan im Menü „Verordnung/Datenabgleich“ hinzufügen.</div>';

  const tHtml = termine.slice(0, 10).map((t) =>
    `<div class="item"><div><strong>${fmt(t.datum)}</strong> ${esc(t.beginn)} Uhr <span class="muted">· ${esc(t.kursTitel)} · ${esc(t.ort)}</span></div><span class="chip ${t.status === 'ausgefallen' ? 'gray' : 'green'}">${esc(t.status)}</span></div>`).join('')
    || '<div class="muted">Keine anstehenden Termine.</div>';

  const aHtml = anw.slice(0, 15).map((a) =>
    `<div class="item"><div><strong>${fmt(a.datum)}</strong> <span class="muted">${esc(a.kurs)}</span>
      <div class="muted small">Zeitstempel: ${a.zeitstempel ? new Date(a.zeitstempel).toLocaleString('de-DE') : '–'} · Leitung bestätigt: ${a.leiter ? 'ja' : 'nein'}</div></div>
      <div>${a.unterschriftBild ? `<img class="sig" src="${a.unterschriftBild}" alt="Unterschrift" style="height:38px"> ` : ''}${a.unterschrift ? '<span class="chip green">digital unterschrieben</span>' : a.papier ? '<span class="chip green">Papierliste</span>' : a.wahrgenommen ? '<span class="chip amber">ohne Sig.</span>' : '<span class="chip gray">nicht teilgenommen</span>'}</div></div>`).join('')
    || '<div class="muted">Noch keine Teilnahmen dokumentiert.</div>';

  const fehlend = fehlendeUnterschriften(pid);
  const druckZeilen = vs.filter((v) => !['abgleich'].includes(v.status)).map((v) => {
    const vorg = v.kostentraegerArt === 'rv' || v.formular === 'g0850' ? 'drv' : (v.kostentraegerArt === 'uv' || v.formular === 'dguv' ? 'dguv' : 'standard');
    return `<div class="item"><div><strong>${esc((S.regeln.arten[v.art] || {}).label || v.art)}</strong> <span class="muted small">${fmt(v.von)} – ${fmt(v.bis)}</span></div>
      <div class="row"><select id="pr-var-${v.id}"><option value="standard" ${vorg === 'standard' ? 'selected' : ''}>Standard (GKV)</option><option value="drv" ${vorg === 'drv' ? 'selected' : ''}>Rentenversicherung</option><option value="dguv" ${vorg === 'dguv' ? 'selected' : ''}>DGUV</option></select>
      <button class="btn small" onclick="druckeListe('${v.id}', document.getElementById('pr-var-${v.id}').value)">🖨 Unterschriftenliste</button>
      <button class="btn small" onclick="druckeVerordnung('${v.id}')">🖨 Verordnung mit Unterschriften</button></div></div>`;
  }).join('') || '<div class="muted">Keine Verordnung für eine Liste vorhanden.</div>';
  const bpZeilen = vs.filter(bpBraucht).map((v) => {
    const bp = v.beratungsprotokoll;
    return `<div class="item"><div><strong>${esc((S.regeln.arten[v.art] || {}).label || v.art)}</strong> <span class="muted small">${fmt(v.von)} – ${fmt(v.bis)}</span>
      <div>${bp ? `<span class="chip green">unterschrieben ${fmt(bp.datum)}</span>` : '<span class="chip amber">fehlt noch</span>'}</div></div>
      <div class="row"><button class="btn small ${bp ? '' : 'primary'}" onclick="beratungDialog('${v.id}')">${bp ? 'Bearbeiten' : '✍ Erfassen'}</button><button class="btn small" onclick="druckeBeratung('${v.id}')">🖨 ${bp ? 'Drucken' : 'Leer drucken'}</button></div></div>`;
  }).join('') || '<div class="muted">Für Funktionstraining ist kein Beratungsprotokoll vorgesehen.</div>';
  const abrHtml = vs.map((v) => {
    const z = abrZeilen.find((x) => x.id === v.id);
    if (!z) return `<div class="item"><div><strong>${esc((S.regeln.arten[v.art] || {}).label || v.art)}</strong> ${statusChip(v.status)}<div class="muted small">Noch nicht abrechnungsrelevant.</div></div></div>`;
    return `<div class="item"><div><strong>${esc(z.artLabel)}</strong> ${statusChip(z.status)}
      <div class="muted small">${fmt(z.von)} – ${fmt(z.bis)} · ${z.erbrachteUee} von ${z.geplanteUee} ÜE erbracht · Satz ${z.satz ? euroFmt(z.satz) : '–'} · Betrag ${z.betrag != null ? euroFmt(z.betrag) : '–'}</div>
      ${z.abrechnung && z.abrechnung.rechnungsNr ? `<div class="muted small">Rechnungs-Nr. ${esc(z.abrechnung.rechnungsNr)}${z.abrechnung.auto ? ' (automatisch erstellt)' : ''} · ${fmt(z.abrechnung.berechnetAm)}</div>` : ''}
      ${z.abbruch ? `<div class="errline">Abbruch ${fmt(z.abbruch.datum)}: ${esc(z.abbruch.grund)}</div>` : ''}</div></div>`;
  }).join('') || '<div class="muted">Keine Verordnung.</div>';
  const tAlle = termine.slice(0, 25).map((t) =>
    `<div class="item"><div><strong>${fmt(t.datum)}</strong> ${esc(t.beginn)} Uhr <span class="muted">· ${esc(t.kursTitel)} · ${esc(t.ort)}</span></div><span class="chip ${t.status === 'ausgefallen' ? 'gray' : 'green'}">${esc(t.status)}</span></div>`).join('')
    || '<div class="muted">Keine anstehenden Termine.</div>';
  const aAlle = anw.slice(0, 40).map((a) =>
    `<div class="item"><div><strong>${fmt(a.datum)}</strong> <span class="muted">${esc(a.kurs)}</span>
      <div class="muted small">Zeitstempel: ${a.zeitstempel ? new Date(a.zeitstempel).toLocaleString('de-DE') : '–'} · Leitung bestätigt: ${a.leiter ? 'ja' : 'nein'}</div></div>
      <div>${a.unterschriftBild ? `<img class="sig" src="${a.unterschriftBild}" alt="Unterschrift" style="height:38px"> ` : ''}${a.unterschrift ? '<span class="chip green">digital unterschrieben</span>' : a.papier ? '<span class="chip green">Papierliste</span>' : a.wahrgenommen ? '<span class="chip amber">ohne Sig.</span>' : '<span class="chip gray">nicht teilgenommen</span>'}</div></div>`).join('')
    || '<div class="muted">Noch keine Teilnahmen dokumentiert.</div>';

  openModal(`${p.nachname}, ${p.vorname}`, `
    <div class="ptabs">
      <button class="ptab active" data-pt="ue">Übersicht</button>
      <button class="ptab" data-pt="te">Termine</button>
      <button class="ptab" data-pt="un">Unterschriften${fehlend.length ? ` <span class="chip red">${fehlend.length}</span>` : ''}</button>
      <button class="ptab" data-pt="ab">Abrechnung</button>
      <button class="ptab" data-pt="dk">Dokumente</button>
    </div>
    <div class="ppanel" data-pp="ue">
      <div class="grid2">
      <div>
        <h2 style="font-size:15px">Kontakt &amp; Einwilligung</h2>
        <div class="form2">
          <label>E-Mail<input id="op-mail" value="${esc(p.email || '')}"></label>
          <label>Telefon<input id="op-tel" value="${esc(p.telefon || '')}"></label>
        </div>
        <div class="row" style="margin-top:8px">
          <button class="btn small" id="op-save">Kontakt speichern</button>
          <button class="btn small" id="op-mailbtn">📅 Termin-E-Mail senden</button>
        </div>
        <div style="margin-top:8px">${p.einwilligung
          ? `<span class="chip green">DSGVO-Einwilligung ${fmt((p.einwilligung.erteiltAm || '').slice(0, 10))}</span>${p.einwilligung.unterschriftPng ? ` <img class="sig" style="height:38px;vertical-align:middle" src="${p.einwilligung.unterschriftPng}" alt="Unterschrift">` : ''}`
          : '<button class="btn small" id="op-einw">✍ Einwilligung einholen</button>'}</div>
        <div class="muted small" style="margin-top:6px">Geb.: ${fmt(p.geburtsdatum)} · ${esc(p.strasse || '')} ${esc(p.plz || '')} ${esc(p.ort || '')}</div>
      </div>
        <div>
          <h2 style="font-size:15px">Nächste Termine</h2><div class="list">${tHtml}</div>
        </div>
      </div>
      <h2 style="font-size:15px;margin-top:14px">Verordnungen</h2><div class="list">${vHtml}</div>
      ${(p.angelegtVon || (vs.find((v) => v.angelegtVon) || {}).angelegtVon) ? `<p class="muted small">Angelegt von: <strong>${esc(p.angelegtVon || vs.find((v) => v.angelegtVon).angelegtVon)}</strong>${p.angelegtAm ? ' am ' + fmt(p.angelegtAm.slice(0, 10)) : ''}</p>` : ''}
    </div>
    <div class="ppanel" data-pp="te" hidden><h2 style="font-size:15px">Anstehende Termine (12 Wochen)</h2><div class="list">${tAlle}</div></div>
    <div class="ppanel" data-pp="un" hidden>
      ${fehlend.length ? `<div class="errline">⚠ ${fehlend.length} Einheit(en) ohne Unterschrift/Grund: ${fehlend.slice(-5).map((x) => fmt(x.datum)).join(', ')} <button class="btn small" id="pt-fehlt">Nachholen / Grund</button></div>` : '<div class="muted small">Keine fehlenden Unterschriften.</div>'}
      <h2 style="font-size:15px;margin-top:10px">Beratungsprotokoll</h2><div class="list">${bpZeilen}</div>
      <h2 style="font-size:15px;margin-top:10px">Unterschriftenlisten drucken</h2><div class="list">${druckZeilen}</div>
      <h2 style="font-size:15px;margin-top:10px">Teilnahmen (Anwesenheit &amp; Unterschriften)</h2><div class="list">${aAlle}</div>
    </div>
    <div class="ppanel" data-pp="ab" hidden><h2 style="font-size:15px">Abrechnung</h2><div class="list">${abrHtml}</div></div>
    <div class="ppanel" data-pp="dk" hidden><div id="pt-dok"></div></div>`,
    [{ label: 'Schließen', cls: 'btn primary', onClick: closeModal }], { wide: true });

  $$('#modal-body .ptab').forEach((b) => { b.onclick = () => {
    $$('#modal-body .ptab').forEach((x) => x.classList.toggle('active', x === b));
    $$('#modal-body .ppanel').forEach((x) => { x.hidden = x.dataset.pp !== b.dataset.pt; });
    if (b.dataset.pt === 'dk') dokScansInto($('#pt-dok'), pid);
  }; });
  const ptf = $('#pt-fehlt');
  if (ptf) ptf.onclick = () => fehlendeDialog(pid, `${p.nachname}, ${p.vorname}`, () => window.oeffnePatient(pid));

  $('#op-save').onclick = async () => {
    try {
      await api('PUT', `/api/patienten/${pid}`, { email: $('#op-mail').value.trim(), telefon: $('#op-tel').value.trim() });
      await reload(true); toast('Kontaktdaten gespeichert.', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  };
  $('#op-mailbtn').onclick = async () => {
    try { const r = await api('POST', `/api/patienten/${pid}/termine-mail`); toast(mailStatusText(r.outbox), r.outbox.status === 'gesendet' ? 'ok' : ''); }
    catch (e) { toast(e.message, 'err'); }
  };
  const einw = $('#op-einw');
  if (einw) einw.onclick = async () => {
    const png = await openSigPad(`Einwilligung Art. 9 DSGVO – ${p.vorname} ${p.nachname}`, 'Einwilligungserklärung zur Verarbeitung von Gesundheitsdaten');
    if (!png) return;
    try {
      await api('PUT', `/api/patienten/${pid}`, { einwilligung: { erteiltAm: new Date().toISOString(), textVersion: (S.settings.datenschutz || {}).textVersion || '', unterschriftPng: png } });
      await reload(true); closeModal(); toast('Einwilligung dokumentiert.', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  };
};

/* ------------------------- Unterschriftenlisten (Druck) ------------------------- */
const PRINT_CSS = `
  .pr-page{font-family:Arial,Helvetica,sans-serif;color:#000;max-width:900px;margin:0 auto;padding:18px;font-size:12.5px}
  .pr-page h1{font-size:17px;margin:0 0 4px}.pr-page .sub{color:#333;margin-bottom:10px}
  .pr-page table{border-collapse:collapse;width:100%}.pr-page th,.pr-page td{border:1px solid #000;padding:5px 6px;vertical-align:middle}
  .pr-page th{background:#eee;text-align:left}.pr-page thead{display:table-header-group}.pr-page tr{page-break-inside:avoid}
  .pr-page .kopf td{border:none;padding:2px 8px 2px 0}.pr-page .kopf{margin-bottom:10px;width:auto}
  .pr-page td.sig{height:34px;width:34%}.pr-page td.sig img{max-height:30px;max-width:100%}
  .pr-page .foot{margin-top:18px;display:flex;gap:30px}.pr-page .foot div{flex:1;border-top:1px solid #000;padding-top:4px;font-size:11.5px}
  .pr-page .fine{margin-top:10px;font-size:11px;color:#333}`;

function listeHtml(v, variante) {
  const p = (S.patienten || []).find((x) => x.id === v.patientId) || {};
  const an = S.settings.anbieter || {};
  const kids = (S.zuordnungen || []).filter((z) => z.verordnungId === v.id).map((z) => z.kursId);
  const kurse = kids.map((k) => (S.kurse || []).find((x) => x.id === k)).filter(Boolean);
  const trainer = [...new Set(kurse.map((k) => { const t = (S.trainer || []).find((x) => x.id === k.trainerId); return t ? `${t.vorname} ${t.nachname}` : ''; }).filter(Boolean))].join(', ');
  const termine = (S.termine || []).filter((t) => kids.includes(t.kursId) && t.status !== 'ausgefallen' && t.status !== 'verschoben'
    && (!v.von || t.datum >= v.von) && (!v.bis || t.datum <= v.bis)).sort((a, b) => (a.datum + a.beginn).localeCompare(b.datum + b.beginn));
  const n = Math.max(termine.length, Number(v.uebungseinheiten) || 0, 10);
  let zeilen = '';
  for (let i = 0; i < n; i++) {
    const t = termine[i];
    const a = t ? (t.anwesenheit || []).find((x) => x.patientId === v.patientId) : null;
    const sig = a && a.unterschriftPng ? `<img src="${a.unterschriftPng}" alt="">` : (a && a.unterschriftPapier ? '<em>Papier</em>' : '');
    zeilen += `<tr><td style="width:6%">${i + 1}</td><td style="width:14%">${t ? fmt(t.datum) : ''}</td><td style="width:10%">${t ? esc(t.beginn || '') : ''}</td><td class="sig">${sig}</td><td style="width:20%"></td></tr>`;
  }
  const artLabel = (S.regeln.arten[v.art] || {}).label || v.art;
  const titel = { standard: 'Teilnahmenachweis / Unterschriftenliste – Rehabilitationssport und Funktionstraining',
    drv: 'Teilnahmenachweis Rehabilitationssport – Deutsche Rentenversicherung',
    dguv: 'Teilnahmenachweis Rehabilitationssport – gesetzliche Unfallversicherung (DGUV)' }[variante] || 'Unterschriftenliste';
  const extra = variante === 'drv'
    ? `<tr><td>Versicherungsnummer (DRV):</td><td><strong>${esc(v.versichertenNr || '______________')}</strong></td></tr><tr><td>Aktenzeichen / Bewilligung:</td><td>______________________</td></tr>`
    : variante === 'dguv'
      ? `<tr><td>Aktenzeichen / Schadensnummer:</td><td>______________________</td></tr><tr><td>Unfalltag:</td><td>______________________</td></tr>`
      : `<tr><td>Versichertennummer:</td><td><strong>${esc(v.versichertenNr || '______________')}</strong></td></tr>`;
  return `<style>${PRINT_CSS}</style><div class="pr-page">
    <h1>${esc(titel)}</h1><div class="sub">${esc(an.name || '')}${an.ik ? ' · IK ' + esc(an.ik) : ''}${an.strasse ? ' · ' + esc(an.strasse) : ''} ${esc(an.plz || '')} ${esc(an.ort || '')}</div>
    <table class="kopf">
      <tr><td>Teilnehmer/in:</td><td><strong>${esc(p.nachname || v.name || '')}, ${esc(p.vorname || '')}</strong> (geb. ${fmt(p.geburtsdatum || v.geburtsdatum)})</td></tr>
      ${extra}
      <tr><td>Kostenträger:</td><td>${esc(v.kostentraeger || '')}</td></tr>
      <tr><td>Maßnahme:</td><td>${esc(artLabel)} · ${v.uebungseinheiten || '–'} ÜE · ${v.frequenzProWoche || '–'}×/Woche</td></tr>
      <tr><td>Verordnungszeitraum:</td><td>${fmt(v.von)} – ${fmt(v.bis)}</td></tr>
      <tr><td>Gruppe / Ort:</td><td>${esc(kurse.map((k) => k.titel + (k.ort ? ' (' + k.ort + ')' : '')).join(' + ') || '–')}</td></tr>
      <tr><td>Übungsleitung:</td><td>${esc(trainer || '–')}</td></tr>
    </table>
    <table><thead><tr><th>Nr.</th><th>Datum</th><th>Uhrzeit</th><th>Unterschrift Teilnehmer/in</th><th>Kürzel Übungsleitung</th></tr></thead><tbody>${zeilen}</tbody></table>
    <div class="foot"><div>Ort, Datum</div><div>Unterschrift Übungsleitung</div></div>
    <div class="fine">Mit der Unterschrift bestätigt die/der Teilnehmende die Teilnahme an der jeweiligen Übungseinheit. Unterschrift unmittelbar vor oder nach der Einheit, keine Vordatierung.</div>
  </div>`;
}

function zeigeDruckansicht(html, dateiname) {
  let root = $('#print-root');
  if (!root) { root = document.createElement('div'); root.id = 'print-root'; document.body.appendChild(root); }
  root.innerHTML = `<div class="pr-bar noprint"><button class="btn primary" id="pr-print">🖨 Drucken</button><button class="btn" id="pr-share">Als HTML teilen/speichern</button><button class="btn" id="pr-close">Schließen</button>
    <span class="muted small">Nachbildung der üblichen Teilnahmenachweise – kein amtliches Formular; bitte mit dem Original des Kostenträgers abgleichen.</span></div>${html}`;
  root.hidden = false; document.body.classList.add('printing');
  const zu = () => { root.hidden = true; root.innerHTML = ''; document.body.classList.remove('printing'); };
  $('#pr-close').onclick = zu;
  $('#pr-print').onclick = () => { try { window.print(); } catch (_) { toast('Drucken wird hier nicht unterstützt – bitte „Als HTML teilen/speichern“ nutzen.', 'err'); } };
  $('#pr-share').onclick = () => dateiTeilen(dateiname, `<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(dateiname)}</title></head><body>${html}</body></html>`, 'text/html');
}

function verordnungHtml(v) {
  const p = (S.patienten || []).find((x) => x.id === v.patientId) || {};
  const an = S.settings.anbieter || {};
  const kurse = (S.zuordnungen || []).filter((z) => z.verordnungId === v.id).map((z) => (S.kurse || []).find((k) => k.id === z.kursId)).filter(Boolean);
  const zeile = (l, w) => `<tr><td style="width:32%"><strong>${l}</strong></td><td>${w || '–'}</td></tr>`;
  return `<style>${PRINT_CSS}</style><div class="pr-page"><h1>Verordnung – Datenblatt mit Teilnahmenachweis</h1>
    <div class="sub">${esc(an.name || '')}${an.ik ? ' · IK ' + esc(an.ik) : ''} · gedruckt am ${fmt(heutigesISO())}</div>
    <table>
      ${zeile('Versicherte/r', `${esc(p.nachname || v.name || '')}, ${esc(p.vorname || '')} (geb. ${fmt(p.geburtsdatum || v.geburtsdatum)})`)}
      ${zeile('Anschrift', esc([p.strasse, [p.plz, p.ort].filter(Boolean).join(' ')].filter(Boolean).join(', ')))}
      ${zeile('Kostenträger', `${esc(v.kostentraeger || '')} (${esc((v.kostentraegerArt || 'gkv').toUpperCase())})${v.ik ? ' · IK ' + esc(v.ik) : ''}`)}
      ${zeile('Versichertennummer', esc(v.versichertenNr))}
      ${zeile('Formular', esc(({ muster56: 'Muster 56', g0850: 'G0850 (DRV)', dguv: 'DGUV-Verordnung' })[v.formular] || v.formular))}
      ${zeile('Ausstellungsdatum / Arzt', `${fmt(v.ausstellungsdatum)} · ${esc(v.arztName)}`)}
      ${zeile('Maßnahme', `${esc((S.regeln.arten[v.art] || {}).label || v.art)} · ${v.frequenzProWoche || '–'}×/Woche · ${v.uebungseinheiten || '–'} ÜE`)}
      ${zeile('Zeitraum', `${fmt(v.von)} – ${fmt(v.bis)}`)}
      ${zeile('Diagnose(n) ICD-10', esc((v.icd10 || []).join(', ')))}
      ${zeile('Ziele', esc(v.ziele))}
      ${zeile('Kostenübernahme', v.kostenuebernahme && v.kostenuebernahme.liegtVor ? `liegt vor${v.kostenuebernahme.datum ? ' (' + fmt(v.kostenuebernahme.datum) + ')' : ''}` : 'nicht erforderlich/nicht vorhanden')}
      ${zeile('Folgeverordnung', v.folgeverordnung ? `ja – ${esc(v.folgeBegruendung)}` : 'nein (Erstverordnung)')}
      ${zeile('Gruppe(n)', esc(kurse.map((k) => `${k.titel} (${k.ort || ''})`).join(' + ')))}
      ${zeile('DSGVO-Einwilligung / Anmeldung', v.anmeldung ? `${fmt(v.anmeldung.datum)}${v.anmeldung.unterschriftPng ? ` <img src="${v.anmeldung.unterschriftPng}" alt="" style="height:34px;vertical-align:middle">` : ''}` : (p.einwilligung ? 'erteilt' : 'fehlt'))}
      ${zeile('Angelegt von / Scan kontrolliert', v.angelegtVon ? `${esc(v.angelegtVon)}${v.scanKontrolle ? ' · Scan kontrolliert ' + new Date(v.scanKontrolle.ts).toLocaleString('de-DE') : ''}` : '')}
      ${v.abbruch ? zeile('Abbruch', `${fmt(v.abbruch.datum)} – ${esc(v.abbruch.grund)}`) : ''}
    </table></div>
    <div style="page-break-before:always"></div>${listeHtml(v, 'standard')}`;
}
window.druckeVerordnung = (vid) => {
  const v = (S.verordnungen || []).find((x) => x.id === vid);
  if (!v) return;
  zeigeDruckansicht(verordnungHtml(v), `Verordnung_${RheaStore ? RheaStore.sanit((v.name || 'Patient')) : 'Patient'}.html`);
};
window.druckDialog = (pid) => {
  const p = (S.patienten || []).find((x) => x.id === pid);
  const vs = (S.verordnungen || []).filter((v) => v.patientId === pid);
  if (!p || !vs.length) { toast('Keine Verordnung vorhanden.', 'err'); return; }
  openModal(`Drucken – ${p.nachname}, ${p.vorname}`, `
    <div class="form2">
      <label>Verordnung<select id="dd-v">${vs.map((v) => `<option value="${v.id}">${esc((S.regeln.arten[v.art] || {}).label || v.art)} · ${fmt(v.von)}–${fmt(v.bis)} (${esc(v.status)})</option>`).join('')}</select></label>
      <label>Dokument<select id="dd-art"><option value="liste-standard">Unterschriftenliste (Standard/GKV)</option><option value="liste-drv">Unterschriftenliste Rentenversicherung</option><option value="liste-dguv">Unterschriftenliste DGUV</option><option value="verordnung">Verordnung mit Unterschriften</option></select></label>
    </div>`,
    [{ label: 'Abbrechen', cls: 'btn', onClick: closeModal },
     { label: '🖨 Anzeigen / Drucken', cls: 'btn primary', onClick: () => { const vid = $('#dd-v').value, art = $('#dd-art').value; closeModal(); if (art === 'verordnung') druckeVerordnung(vid); else druckeListe(vid, art.replace('liste-', '')); } }]);
  const vSel = (vs.find((v) => v.status === 'aktiv') || vs[0]);
  $('#dd-v').value = vSel.id;
  $('#dd-art').value = vSel.kostentraegerArt === 'rv' ? 'liste-drv' : vSel.kostentraegerArt === 'uv' ? 'liste-dguv' : 'liste-standard';
};

/* ------------------------- Beratungsprotokoll (Rehabilitationssport) ------------------------- */
const bpBraucht = (v) => v && v.art !== 'funktionstraining' && v.status !== 'abgleich';
function beratungHtml(v) {
  const bp = (v && v.beratungsprotokoll) || {};
  const p = v ? ((S.patienten || []).find((x) => x.id === v.patientId) || {}) : {};
  const name = v ? `${p.vorname || ''} ${p.nachname || v.name || ''}`.trim() : '';
  const leer = (t, n) => (t ? `<u>&nbsp;${esc(t)}&nbsp;</u>` : '_'.repeat(n));
  const box = (on) => (on ? '☒' : '☐');
  const sig = (img) => (img ? `<img src="${img}" alt="Unterschrift" style="height:46px;display:block">` : '<div style="height:46px"></div>');
  return `<style>${PRINT_CSS} .pr-page ul{margin:4px 0 10px 18px;padding:0}.pr-page li{margin:3px 0}</style><div class="pr-page">
    <h1>Beratungsprotokoll</h1>
    <p>Am ${leer(bp.datum ? fmt(bp.datum) : '', 16)} legte Herr/Frau ${leer(name, 44)} eine Verordnung über Rehabilitationssport vor.</p>
    <p>Es erfolgte eine Information zum Angebot als Leistungserbringer für Rehabilitationssport. Dabei wurden folgende Punkte besprochen:</p>
    <ul>
      <li>Tag, Zeit und Ort der Angebote bzw. des ausgewählten Angebotes.</li>
      <li>Dauer einer Übungsveranstaltung (Rehabilitationssport: mind. 45 Minuten bzw. 60 Minuten im Herzsport).</li>
      <li>Größe der Gruppe (maximal 15 TN, im Herzsport maximal 20 TN).</li>
      <li>Inhalt des Rehabilitationssports: Gymnastik (Gymnastik auch im Wasser), Ausdauer- und Kraftausdauerübungen, Schwimmen, Bewegungsspiele, soweit es sich um Übungen in der Gruppe handelt, mit denen das Ziel des Rehabilitationssports erreicht werden kann. Es können auch geeignete Inhalte anderer Sportarten (z. B. Entspannung o. ä.) zum Einsatz kommen.</li>
      <li>Ausgenommen von Rehabilitationssport sind Übungen an technischen Geräten bzw. individuelle Einzelübungen (Gerätetraining, Muskelaufbautraining wie z. B. in Fitnesscenter, KG-Praxen). Sportarten, die gemessen an den Kosten für den Rehabilitationssport einen unverhältnismäßig hohen finanziellen Aufwand fordern.</li>
      <li>Organisatorischer Rahmen (Fach-Übungsleiter und ärztliche Betreuung bzw. Überwachung im Herzsport).</li>
      <li>Eine Unfallversicherung ist über den RehaSport Deutschland e.V. abgeschlossen.</li>
      <li>Absicherung durch Defibrillator/Notfallkoffer im Herzsport.</li>
    </ul>
    <p>Zur Mitgliedschaft und Zuzahlung wurden folgende Informationen weitergegeben:</p>
    <ul>
      <li>Es gibt keine Verpflichtung, Mitglied beim Anbieter zu werden oder Zuzahlungen zu entrichten, um am Rehabilitationssport teilzunehmen.</li>
      <li>Vom Versicherten werden für die Teilnahme am Rehabilitationssport für die Dauer der vertragsärztlichen Verordnung zu Lasten eines Rehabilitationsträgers keine zusätzlichen Vorauszahlungen oder sonstige Eigenbeteiligungen erhoben.</li>
      <li>Die Vertragspartner der Vereinbarung über die Durchführung des Rehabilitationssports begrüßen eine Mitgliedschaft in den Rehabilitationssportgruppen auf freiwilliger Basis, um die eigenverantwortliche Durchführung des Bewegungstrainings zu fördern und nachhaltig zu sichern.</li>
    </ul>
    <p>Sofern eine freiwillige Mitgliedschaft eingegangen wird oder freiwillige Zuzahlungen geleistet werden, können ergänzend zum Rehabilitationssport folgende Leistungen in Anspruch genommen werden:<br>${leer(bp.leistungen, 90)}</p>
    <p>Der Beitrag beträgt in diesem Fall ${leer(bp.beitrag ? String(bp.beitrag).replace('.', ',') : '', 8)} € &nbsp;${box(bp.turnus === 'einmalig')} einmalig &nbsp;${box(bp.turnus === 'monatlich')} monatlich &nbsp;${box(bp.turnus === 'sonstiges')} ${leer(bp.turnus === 'sonstiges' ? bp.turnusText : '', 14)}</p>
    <p>Die Möglichkeit der Teilnahme am Rehabilitationssport endet für Nicht-Mitglieder nach Ablauf der Verordnungsdauer bzw. nach Absolvierung der verordneten Einheiten ohne Kündigungsfrist.</p>
    <p>${box(bp.kopie)} Von diesem Protokoll wurde dem Versicherten eine Kopie ausgehändigt.</p>
    <div class="foot" style="margin-top:26px"><div>${sig(bp.unterschriftVersicherte)}${bp.ort || bp.datum ? esc([bp.ort, bp.datum ? fmt(bp.datum) : ''].filter(Boolean).join(', ')) + '<br>' : ''}Versicherte/r (Ort, Datum, Unterschrift)</div>
      <div>${sig(bp.unterschriftAnbieter)}${bp.ort || bp.datum ? esc([bp.ort, bp.datum ? fmt(bp.datum) : ''].filter(Boolean).join(', ')) + '<br>' : ''}Vertreter/in des Anbieters (Ort, Datum, Unterschrift)${bp.anbieterName ? ' – ' + esc(bp.anbieterName) : ''}</div></div>
  </div>`;
}
window.druckeBeratung = (vid) => {
  const v = vid ? (S.verordnungen || []).find((x) => x.id === vid) : null;
  const p = v ? ((S.patienten || []).find((x) => x.id === v.patientId) || {}) : {};
  zeigeDruckansicht(beratungHtml(v), `Beratungsprotokoll_${v ? RheaStore.sanit(p.nachname || v.name || 'Patient') : 'Vorlage'}.html`);
};
/** Beratungsprotokoll erfassen: Angaben + zwei digitale Unterschriften. st = Zwischenstand (bleibt beim Unterschreiben erhalten). */
window.beratungDialog = (vid, st) => {
  const v = (S.verordnungen || []).find((x) => x.id === vid);
  if (!v) return;
  const p = (S.patienten || []).find((x) => x.id === v.patientId) || {};
  const name = `${p.nachname || v.name || ''}, ${p.vorname || ''}`;
  st = st || Object.assign({ datum: heutigesISO(), ort: (S.settings.anbieter || {}).ort || '', leistungen: '', beitrag: '', turnus: '', turnusText: '', kopie: false,
    anbieterName: localStorage.getItem('rhea.angelegtVon') || '', unterschriftVersicherte: null, unterschriftAnbieter: null }, v.beratungsprotokoll || {});
  const lesen = () => {
    const g = (id) => { const e = $(`#bp-${id}`); return e ? e.value : undefined; };
    for (const k of ['datum', 'ort', 'leistungen', 'beitrag', 'turnus', 'turnusText', 'anbieterName']) { const x = g(k); if (x !== undefined) st[k] = x; }
    const c = $('#bp-kopie'); if (c) st.kopie = c.checked;
  };
  openModal(`Beratungsprotokoll – ${name}`, `
    <p class="hint">Rehabilitationssport · ${esc((S.regeln.arten[v.art] || {}).label || v.art)} · ${fmt(v.von)} – ${fmt(v.bis)}. Der Text des Protokolls wird mit allen Pflichtpunkten ausgedruckt; hier nur die Angaben und Unterschriften.</p>
    <div class="form2">
      <label>Datum der Beratung<input type="date" id="bp-datum" value="${esc(st.datum)}"></label>
      <label>Ort<input id="bp-ort" value="${esc(st.ort)}"></label>
      <label class="span2">Leistungen bei freiwilliger Mitgliedschaft/Zuzahlung (leer = keine)<input id="bp-leistungen" value="${esc(st.leistungen)}"></label>
      <label>Beitrag (€)<input id="bp-beitrag" inputmode="decimal" value="${esc(st.beitrag)}"></label>
      <label>Turnus<select id="bp-turnus"><option value="">–</option><option value="einmalig" ${st.turnus === 'einmalig' ? 'selected' : ''}>einmalig</option><option value="monatlich" ${st.turnus === 'monatlich' ? 'selected' : ''}>monatlich</option><option value="sonstiges" ${st.turnus === 'sonstiges' ? 'selected' : ''}>sonstiges</option></select></label>
      <label>Sonstiges (Turnus)<input id="bp-turnusText" value="${esc(st.turnusText)}"></label>
      <label>Vertreter/in des Anbieters (Name)<input id="bp-anbieterName" value="${esc(st.anbieterName)}"></label>
    </div>
    <label class="check"><input type="checkbox" id="bp-kopie" ${st.kopie ? 'checked' : ''}> Eine Kopie des Protokolls wurde der/dem Versicherten ausgehändigt</label>
    <div class="row" style="margin-top:10px">
      <button class="btn ${st.unterschriftVersicherte ? '' : 'primary'}" id="bp-sig1">✍ Unterschrift Versicherte/r ${st.unterschriftVersicherte ? '✔' : ''}</button>
      <button class="btn ${st.unterschriftAnbieter ? '' : 'primary'}" id="bp-sig2">✍ Unterschrift Anbieter ${st.unterschriftAnbieter ? '✔' : ''}</button>
    </div>`,
  [{ label: 'Abbrechen', cls: 'btn', onClick: closeModal },
   { label: 'Speichern', cls: 'btn primary', onClick: async () => {
     lesen();
     if (!st.unterschriftVersicherte || !st.unterschriftAnbieter) { toast('Bitte beide Unterschriften erfassen.', 'err'); return; }
     if (!st.kopie) { toast('Bitte bestätigen, dass eine Kopie ausgehändigt wurde.', 'err'); return; }
     if (!st.anbieterName.trim()) { toast('Bitte den Namen des Anbieter-Vertreters eintragen.', 'err'); return; }
     try {
       await api('PUT', `/api/verordnungen/${vid}`, { beratungsprotokoll: st });
       if (st.anbieterName) localStorage.setItem('rhea.angelegtVon', st.anbieterName);
       await reload(false); toast('Beratungsprotokoll gespeichert.', 'ok');
       closeModal(); window.oeffnePatient(v.patientId);
     } catch (e) { toast(e.message, 'err'); }
   } }], { wide: true });
  const sign = (feld, titel) => async () => {
    lesen();
    const png = await openSigPad(titel, `Beratungsprotokoll · ${name}`);
    if (png) st[feld] = png;
    window.beratungDialog(vid, st);
  };
  $('#bp-sig1').onclick = sign('unterschriftVersicherte', `Unterschrift Versicherte/r – ${name}`);
  $('#bp-sig2').onclick = sign('unterschriftAnbieter', 'Unterschrift Vertreter/in des Anbieters');
};

window.druckeListe = (vid, variante) => {
  const v = (S.verordnungen || []).find((x) => x.id === vid);
  if (!v) return;
  const p = (S.patienten || []).find((x) => x.id === v.patientId) || {};
  zeigeDruckansicht(listeHtml(v, variante || 'standard'), `Unterschriftenliste_${(p.nachname || 'Patient').replace(/\W+/g, '_')}_${variante || 'standard'}.html`);
};

function mailStatusText(m) {
  if (!m) return 'Unbekannter Status';
  if (m.status === 'gesendet') return `E-Mail gesendet an ${(m.an || []).join(', ')}`;
  if (m.status === 'mailto-bereit') return `Entwurf bereit – Senden über das E-Mail-Programm: ${(m.an || []).join(', ')}`;
  if (m.status === 'konfiguration-offen') return 'SMTP nicht konfiguriert – Entwurf liegt im Journal (Einstellungen).';
  if (m.status === 'fehler') return `Fehler: ${m.fehler}`;
  return 'wartet auf Versand';
}

/** Datei teilen (Web Share) bzw. Zwischenablage/Download – für den APK-Modus. */
async function dateiTeilen(name, inhalt, mime) {
  try {
    const file = new File([inhalt], name, { type: mime });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], title: name });
      return;
    }
  } catch (e) { if (e && e.name === 'AbortError') return; }
  try { await navigator.clipboard.writeText(String(inhalt)); toast('In die Zwischenablage kopiert – in der E-Mail-App/Dort einfügen.', 'ok'); return; } catch (_) { /* weiter */ }
  const blob = new Blob([inhalt], { type: mime });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 8000);
}

window.oeffneVerordnung = (vid) => {
  const v = (S.verordnungen || []).find((x) => x.id === vid);
  if (!v) return;
  openModal(`Verordnung ${v.id}`, `
    <div class="grid2">
      <div class="list">
        ${[['Versicherte/r', v.name], ['Geburtsdatum', fmt(v.geburtsdatum)], ['Kostenträger', `${v.kostentraeger || '–'} (${v.kostentraegerArt || 'gkv'})`],
          ['Versicherten-Nr.', v.versichertenNr], ['Zeitraum', `${fmt(v.von)} – ${fmt(v.bis)}`], ['ÜE / Frequenz', `${v.uebungseinheiten} ÜE · ${v.frequenzProWoche}×/Woche`],
          ['Art', (S.regeln.arten[v.art] || {}).label || v.art], ['ICD-10', (v.icd10 || []).join(', ')], ['Arzt/Ärztin', v.arztName],
          ['Kostenübernahme', v.kostenuebernahme && v.kostenuebernahme.liegtVor ? `${fmt(v.kostenuebernahme.datum)} ✓` : 'fehlt ✕'],
          ['Formular', v.formular], ['Status', statusChip(v.status)]].map(([a, b]) => `<div class="item"><span class="muted">${esc(a)}</span><strong>${esc(b ?? '–')}</strong></div>`).join('')}
      </div>
      <div style="text-align:center">
        <div class="muted small">QR-Code der Verordnung (Neu-Scan führt in denselben Datenabgleich):</div>
        <div id="vo-qr" style="display:inline-block;padding:6px;background:#fff;border:1px solid var(--line);border-radius:10px"></div>
        <div class="muted small">Zuletzt erbrachte ÜE: ${v.erbrachteUee ?? '–'} / ${v.uebungseinheiten}</div>
      </div>
    </div>`,
    [{ label: 'Schließen', cls: 'btn primary', onClick: closeModal }], { wide: true });
  // QR rendern: lokal im Gerät (qrcode-generator) bzw. per Server-PNG
  const qrBox = $('#vo-qr');
  if (window.LOCAL_MODE) {
    try {
      const payload = JSON.stringify({ rs: '1', n: v.name, g: v.geburtsdatum, kk: v.kostentraeger, vs: v.versichertenNr, von: v.von, bis: v.bis, art: v.art, f: v.frequenzProWoche, ue: v.uebungseinheiten, icd: (v.icd10 || []).join(','), z: v.ziele, arzt: v.arztName, ft: v.formular, id: v.id });
      const c = window.qrcode(0, 'M');
      c.addData(payload);
      c.make();
      qrBox.innerHTML = c.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
      const svg = qrBox.querySelector('svg');
      if (svg) { svg.style.width = '240px'; svg.style.height = '240px'; }
    } catch (e) { qrBox.textContent = 'QR-Erzeugung nicht verfügbar.'; }
  } else {
    qrBox.innerHTML = `<img src="/api/verordnungen/${v.id}/qrcode.png" alt="QR" style="max-width:260px">`;
  }
};

window.gruppeAendern = (vid) => {
  const v = (S.verordnungen || []).find((x) => x.id === vid);
  const aktuell = zuordnungenFuerVerordnung(vid).map((z) => z.kursId);
  const passend = (S.kurse || []).filter((k) => k.aktiv && k.art === v.art);
  openModal('Gruppe (Kurs) ändern', `
    <p class="hint">Ein Gruppenwechsel ist nur begründet zulässig und wird dokumentiert (kein willkürliches „Gruppenhopping“). Die neue Gruppe muss zur verordneten Art passen.</p>
    <div class="gruppe-list" id="ga-list">
      ${passend.map((k) => `<div class="gruppe ${aktuell.includes(k.id) ? 'selected' : ''}" data-id="${k.id}">
        <div><div class="t">${esc(k.titel)}</div><div class="muted small">${WOCHENTAGE[k.wochentag]} ${esc(k.beginn)} · ${esc(k.ort || '')} · ${tLink(k.trainerId, trainerName(k.trainerId))}</div></div>
        <div>${aktuell.includes(k.id) ? '<span class="chip green">aktuell</span>' : '<span class="chip gray">wählbar</span>'}</div></div>`).join('') || '<div class="muted">Keine passenden Kurse angelegt.</div>'}
    </div>
    <label style="margin-top:10px">Begründung des Gruppenwechsels *<textarea id="ga-grund" rows="2"></textarea></label>`,
    [
      { label: 'Abbrechen', cls: 'btn', onClick: closeModal },
      { label: 'Wechsel speichern', cls: 'btn primary', onClick: async () => {
        const gewaehlt = $$('#ga-list .gruppe.selected').map((el) => el.dataset.id);
        const grund = $('#ga-grund').value.trim();
        if (!gewaehlt.length) { toast('Bitte Gruppe(n) wählen.', 'err'); return; }
        if (gewaehlt.join() !== aktuell.join() && !grund) { toast('Für einen Gruppenwechsel ist eine Begründung erforderlich.', 'err'); return; }
        try {
          await api('PUT', `/api/verordnungen/${vid}`, { kursIds: gewaehlt, gruppenwechselGrund: grund || undefined });
          closeModal(); await reload(true); toast('Gruppe(n) aktualisiert.', 'ok');
        } catch (e) { toast(e.message, 'err'); }
      } },
    ]);
  $$('#ga-list .gruppe').forEach((el) => { el.onclick = () => el.classList.toggle('selected'); });
};

/* ============================== TRAINER ============================== */
function renderTrainer() {
  const box = $('#trainer-karten');
  setTimeout(filterTrainer, 0);
  box.innerHTML = (S.trainer || []).map((t) => {
    const kurse = (S.kurse || []).filter((k) => k.trainerId === t.id && k.aktiv);
    const rest = t.zertifikateBis ? Math.round((new Date(t.zertifikateBis) - new Date()) / 86400000) : null;
    const abgelaufen = rest !== null && rest < 0;
    const bald = rest !== null && rest >= 0 && rest < 90;
    const nf = (S.regeln.notfallqualifikationen || []).find((n) => n.id === t.notfallqualifikation);
    return `<div class="karte ${t.aktiv ? '' : 'nein'}" id="trk-${t.id}" style="border-left:6px solid ${trainerFarbe(t.id)}">
      <h3>${farbPunkt(t.id)}${esc(t.vorname)} ${esc(t.nachname)}
        ${t.aktiv ? '<span class="chip green">aktiv</span>' : '<span class="chip gray">inaktiv</span>'}
        ${t.barAnerkennung === 'anerkannt' ? '<span class="chip blue">BAR/RSD ✓</span>' : '<span class="chip red">keine Anerkennung</span>'}</h3>
      <div class="chips">${(t.qualifikationen || []).map((q) => `<span class="chip">${esc((S.regeln.qualifikationen.find((x) => x.id === q) || {}).label || q)}</span>`).join('')}</div>
      <div class="meta">🚑 Notfall: ${esc(nf ? nf.label : '–')} ${t.notfallGueltigBis ? `· gültig bis ${fmt(t.notfallGueltigBis)}` : ''}<br>
        📜 Nachweis gültig bis: <strong>${fmt(t.zertifikateBis)}</strong>${(t.qualifikationen || []).includes('herzgruppenleiter') && t.zertifikatHerzBis ? ` (Herz: ${fmt(t.zertifikatHerzBis)})` : ''}<br>
        ✉ ${esc(t.email || '–')} · ☎ ${esc(t.telefon || '–')}${t.stundenlohn ? ` · 💶 ${euroFmt(t.stundenlohn)}/Std.` : ''}<br>
        📋 Verschwiegenheitserklärung: ${t.verchwiegenheit || t.verchwiegenheitDatum ? '✓ ' + fmt(t.verchwiegenheit || t.verchwiegenheitDatum) : '<span class="chip amber">offen (§203/Art.9)</span>'}
        · Datenschutz-Belehrung: ${t.datenschutzBelehrung ? '✓ ' + fmt(t.datenschutzBelehrung) : '–'}</div>
      ${abgelaufen ? '<div class="errline">⚠ Qualifikationsnachweis abgelaufen – Einsatz unzulässig (auch für Vertretungen)!</div>' :
        bald ? `<div class="warnline">⚠ Nachweis läuft in ${rest} Tagen ab (Herzgruppen max. 2 J., sonst 4 J.).</div>` : ''}
      ${kurse.length ? `<div class="meta">Kurse: ${kurse.map((k) => esc(k.titel)).join(' · ')}</div>` : '<div class="meta muted">Keine Kurse</div>'}
      <div class="acts">
        <button class="btn small" onclick="trainerForm('${t.id}')">Bearbeiten</button>
        <button class="btn small ${t.aktiv ? 'danger' : ''}" onclick="trainerToggle('${t.id}')">${t.aktiv ? 'Deaktivieren' : 'Reaktivieren'}</button>
      </div>
    </div>`;
  }).join('') || '<div class="muted">Noch keine Trainer/innen angelegt.</div>';
}

window.trainerForm = (id) => {
  const t = id ? (S.trainer || []).find((x) => x.id === id) : null;
  const nfOpts = (S.regeln.notfallqualifikationen || []).map((n) =>
    `<option value="${n.id}" ${t && t.notfallqualifikation === n.id ? 'selected' : ''}>${esc(n.label)}</option>`).join('');
  const qBoxes = (S.regeln.qualifikationen || []).map((q) =>
    `<label class="check"><input type="checkbox" class="tf-q" value="${q.id}" ${t && (t.qualifikationen || []).includes(q.id) ? 'checked' : ''} ${!t && q.id === 'uebungsleiter' ? 'checked' : ''}> ${esc(q.label)}</label>`).join('');
  openModal(t ? `Trainer/in bearbeiten: ${t.vorname} ${t.nachname}` : 'Neue/r Trainer/in', `
    <div class="form2">
      <label>Vorname *<input id="tf-vor" value="${esc(t ? t.vorname : '')}"></label>
      <label>Nachname *<input id="tf-nach" value="${esc(t ? t.nachname : '')}"></label>
      <label>E-Mail<input id="tf-mail" value="${esc(t ? t.email : '')}"></label>
      <label>Telefon<input id="tf-tel" value="${esc(t ? t.telefon : '')}"></label>
      <label>Stundenlohn (€/Std.)<input type="number" step="0.01" min="0" id="tf-lohn" value="${esc(t && t.stundenlohn ? t.stundenlohn : '')}"></label>
      <label>Farbe (Kalender, Listen)<input type="color" id="tf-farbe" value="${esc(t ? trainerFarbe(t.id) : TRAINER_FARBEN[(S.trainer || []).length % TRAINER_FARBEN.length])}" style="height:42px;padding:2px"></label>
      <label>Nachweis gültig bis (max. 4 J.) *<input type="date" id="tf-bis" value="${esc(t ? t.zertifikateBis : '')}"></label>
      <label>Herzgruppen-Zertifikat gültig bis (max. 2 J.)<input type="date" id="tf-hzbis" value="${esc(t ? t.zertifikatHerzBis : '')}"></label>
      <label>Notfallqualifikation (Rahmenvereinbarung)<select id="tf-nf">${nfOpts}</select></label>
      <label>Notfallqualifikation gültig bis<input type="date" id="tf-nfbis" value="${esc(t ? t.notfallGueltigBis : '')}"></label>
      <label>Anerkennung<select id="tf-ane">
        <option value="anerkannt" ${!t || t.barAnerkennung === 'anerkannt' ? 'selected' : ''}>BAR/RSD anerkannt &amp; genehmigt</option>
        <option value="pruefung" ${t && t.barAnerkennung === 'pruefung' ? 'selected' : ''}>in Prüfung</option>
        <option value="nein" ${t && t.barAnerkennung === 'nein' ? 'selected' : ''}>nicht anerkannt</option></select></label>
      <label class="check"><input type="checkbox" id="tf-rsd" ${t && t.rsdMitglied ? 'checked' : ''}> Mitglied RehaSport Deutschland e.&nbsp;V.</label>
      <label class="span2">Qualifikationen / Fachbereiche (auch für Urlaubs-/Krankheitsvertretungen relevant)</label>
      <div class="span2" style="columns:2">${qBoxes}</div>
      <label>Verschwiegenheitserklärung am<input type="date" id="tf-versch" value="${esc(t ? (t.verchwiegenheit || t.verchwiegenheitDatum || '') : '')}"></label>
      <label>Datenschutz-Belehrung am<input type="date" id="tf-dsb" value="${esc(t ? t.datenschutzBelehrung : '')}"></label>
      <label class="span2">Bemerkung<textarea id="tf-bem" rows="2">${esc(t ? t.bemerkung : '')}</textarea></label>
      <label class="span2 check"><input type="checkbox" id="tf-aktiv" ${!t || t.aktiv ? 'checked' : ''}> Aktiv einsetzbar</label>
    </div>`,
    [
      { label: 'Abbrechen', cls: 'btn', onClick: closeModal },
      ...(t ? [{ label: 'Löschen', cls: 'btn danger', onClick: async () => {
        if (!confirm('Trainer/in löschen? (wird deaktiviert, falls Kurse bestehen)')) return;
        try { await api('DELETE', `/api/trainer/${t.id}`); closeModal(); await reload(true); toast('Gelöscht/deaktiviert.'); } catch (e) { toast(e.message, 'err'); }
      } }] : []),
      { label: 'Speichern', cls: 'btn primary', onClick: async () => {
        const payload = {
          vorname: $('#tf-vor').value.trim(), nachname: $('#tf-nach').value.trim(),
          email: $('#tf-mail').value.trim(), telefon: $('#tf-tel').value.trim(), stundenlohn: $('#tf-lohn').value, farbe: $('#tf-farbe').value,
          zertifikateBis: $('#tf-bis').value, zertifikatHerzBis: $('#tf-hzbis').value,
          notfallqualifikation: $('#tf-nf').value, notfallGueltigBis: $('#tf-nfbis').value,
          barAnerkennung: $('#tf-ane').value, rsdMitglied: $('#tf-rsd').checked,
          qualifikationen: $$('#modal-body input.tf-q:checked').map((c) => c.value),
          verchwiegenheit: $('#tf-versch').value, datenschutzBelehrung: $('#tf-dsb').value,
          bemerkung: $('#tf-bem').value.trim(), aktiv: $('#tf-aktiv').checked,
        };
        if (!payload.vorname || !payload.nachname) { toast('Vor- und Nachname erforderlich.', 'err'); return; }
        try {
          await api(t ? 'PUT' : 'POST', t ? `/api/trainer/${t.id}` : '/api/trainer', payload);
          closeModal(); await reload(true); toast('Gespeichert.', 'ok');
        } catch (e) { toast(e.message, 'err'); }
      } },
    ], { wide: true });
};
$('#btn-neuer-trainer').onclick = () => trainerForm(null);

window.trainerToggle = async (id) => {
  const t = (S.trainer || []).find((x) => x.id === id);
  try { await api('PUT', `/api/trainer/${id}`, { aktiv: !t.aktiv }); await reload(true); }
  catch (e) { toast(e.message, 'err'); }
};

document.addEventListener('change', (e) => {
  if (e.target && e.target.id === 'kf-titelsel' && e.target.value) { $('#kf-titel').value = e.target.value; $('#kf-titel').focus(); }
});

/* ============================== KURSE ============================== */
function renderKurse() {
  setTimeout(filterKurse, 0);
  $('#kurs-liste').innerHTML = (S.kurse || []).map((k) => {
    const pr = (S.kursPruefungen || {})[k.id] || { fehler: [], hinweise: [] };
    const tr = (S.trainer || []).find((t) => t.id === k.trainerId);
    const belegt = (S.zuordnungen || []).filter((z) => z.kursId === k.id && z.aktiv !== false).length;
    const art = S.regeln.arten[k.art] || {};
    return `<div class="karte ${k.aktiv ? '' : 'nein'}">
      <h3>${esc(k.titel)} ${k.aktiv ? '<span class="chip green">aktiv</span>' : '<span class="chip gray">inaktiv</span>'}</h3>
      <div class="chips"><span class="chip blue">${esc(art.label || k.art)}</span>
        <span class="chip">${WOCHENTAGE_LANG[k.wochentag]} ${esc(k.beginn)} Uhr</span>
        <span class="chip">${k.dauerMin} Min. (mind. ${art.minDauerMin})</span>
        <span class="chip ${belegt >= (k.maxTeilnehmer || art.maxTN) ? 'amber' : 'green'}">${belegt}/${k.maxTeilnehmer || art.maxTN} TN</span></div>
      <div class="meta">👨‍🏫 ${tr ? tLink(tr.id, `${tr.vorname} ${tr.nachname}`) : 'keine Übungsleitung!'} · 📍 ${esc(k.ort || '–')}
        ${k.raumflaecheQm ? `· 📐 ${k.raumflaecheQm} qm (max. ${Math.floor(k.raumflaecheQm / (art.qmProTN || 5))} TN)` : ''}
        <br>📅 Start ${fmt(k.startdatum)}${k.enddatum ? ` – Ende ${fmt(k.enddatum)}` : ' – laufend'}
        ${(k.art === 'herzgruppe' || k.art === 'herzinsuffizienz') ? `<br>🩺 ${esc((k.betreuungsArzt || {}).name || 'kein Betreuungsarzt!')} · AED: ${k.aed && k.aed.vorhanden ? '✓ ' + fmt(k.aed.wartungAm) : '✕'} · Notfallplan: ${k.notfallplan ? '✓' : '✕'} · Koffer: ${k.notfallkoffer ? '✓' : '✕'}` : ''}</div>
      ${pr.fehler.map((f) => `<div class="errline">✕ ${esc(f)}</div>`).join('')}
      ${pr.hinweise.map((h) => `<div class="warnline">⚠ ${esc(h)}</div>`).join('')}
      <div class="acts">
        <button class="btn small" onclick="kursForm('${k.id}')">Bearbeiten</button>
        <button class="btn small" onclick="oeffneKalenderTagKurs('${k.id}')">Termine</button>
        <button class="btn small ${k.aktiv ? 'danger' : ''}" onclick="kursToggle('${k.id}')">${k.aktiv ? 'Deaktivieren' : 'Reaktivieren'}</button>
      </div>
    </div>`;
  }).join('') || '<div class="muted">Noch keine Kurse angelegt.</div>';
}

window.kursForm = (id) => {
  const k = id ? (S.kurse || []).find((x) => x.id === id) : null;
  const artOpts = Object.entries(S.regeln.arten).map(([a, info]) =>
    `<option value="${a}" ${k && k.art === a ? 'selected' : (!k && a === 'rs' ? 'selected' : '')}>${esc(info.label)} (mind. ${info.minDauerMin} Min., max. ${info.maxTN} TN)</option>`).join('');
  const trOpts = (S.trainer || []).map((t) =>
    `<option value="${t.id}" ${k && k.trainerId === t.id ? 'selected' : ''}>${esc(t.vorname)} ${esc(t.nachname)}${t.barAnerkennung === 'anerkannt' ? '' : ' (nicht anerkannt!)'}</option>`).join('');
  const wtOpts = WOCHENTAGE_LANG.map((w, i) => `<option value="${i}" ${k && Number(k.wochentag) === i ? 'selected' : (!k && i === 3 ? 'selected' : '')}>${w}</option>`).join('');
  const ba = (k && k.betreuungsArzt) || {};
  const aed = (k && k.aed) || {};
  const isHerz = k && (k.art === 'herzgruppe' || k.art === 'herzinsuffizienz');
  openModal(k ? `Kurs bearbeiten: ${k.titel}` : 'Neuen Kurs eintragen', `
    <div class="form2">
      <label class="span2">Gruppenname – aus Liste wählen oder selbst eintragen<select id="kf-titelsel"><option value="">– Vorschlag wählen –</option>${((S.settings.gruppennamen) || []).map((n) => `<option>${esc(n)}</option>`).join('')}</select></label>
      <label class="span2">Titel der festen Gruppe *<input id="kf-titel" value="${esc(k ? k.titel : '')}" placeholder="z. B. Rehasport Wirbelsäule – Mi 17:00"></label>
      <label>Art *<select id="kf-art">${artOpts}</select></label>
      <label>Übungsleitung *<select id="kf-trainer"><option value="">– wählen –</option>${trOpts}</select></label>
      <label>Wochentag *<select id="kf-wt">${wtOpts}</select></label>
      <label>Beginn *<input type="time" id="kf-beginn" value="${esc(k ? k.beginn : '17:00')}"></label>
      <label>Dauer (Min.) *<input type="number" id="kf-dauer" value="${esc(k ? k.dauerMin : 45)}" min="30" max="180"></label>
      <label>Max. Teilnehmer<input type="number" id="kf-max" value="${esc(k ? k.maxTeilnehmer : 15)}" min="1" max="25"></label>
      <label>Ort / Raum<input id="kf-ort" value="${esc(k ? k.ort : '')}"></label>
      <label>Raumfläche nutzbar (qm)<input type="number" id="kf-qm" value="${k ? k.raumflaecheQm || '' : ''}" placeholder="5 qm × TN"></label>
      <label>Startdatum *<input type="date" id="kf-start" value="${esc(k ? k.startdatum : heutigesISO())}"></label>
      <label>Enddatum (optional)<input type="date" id="kf-ende" value="${esc(k ? k.enddatum : '')}"></label>

      <div class="span2 hint" id="kf-herz-hint" ${isHerz ? '' : 'hidden'}>
        <strong>Herzgruppen-Regeln:</strong> ständige ärztliche Anwesenheit bzw. Visitation mind. alle 6 Wochen (dokumentiert),
        Notfallplan, (A)ED, Notfallkoffer, Notfallübungen 2×/Jahr. Mindestdauer 60 Minuten, max. 20 TN (Herzinsuffizienz: 12).
        NRW-Hilfsfrist 8 Min. (ländlich 12 Min.).</div>
      <label class="span2">Betreuende/r Ärztin/Arzt (Herzgruppe)<input id="kf-arzt" value="${esc(ba.name || '')}" placeholder="Name, Fachbereich, Erreichbarkeit"></label>
      <label>Letzte Arztvisitation<input type="date" id="kf-vis" value="${esc(ba.visitationAm || '')}"></label>
      <label>Letzte Notfallübung<input type="date" id="kf-notfueb" value="${esc(k ? k.notfallUebungAm : '')}"></label>
      <label class="check"><input type="checkbox" id="kf-plan" ${k && k.notfallplan ? 'checked' : ''}> Notfallplan vorhanden</label>
      <label class="check"><input type="checkbox" id="kf-aed" ${aed.vorhanden ? 'checked' : ''}> (A)ED vorhanden</label>
      <label>AED-Wartung am<input type="date" id="kf-aedw" value="${esc(aed.wartungAm || '')}"></label>
      <label class="check"><input type="checkbox" id="kf-koffer" ${k && k.notfallkoffer ? 'checked' : ''}> Notfallkoffer (DIN)</label>
      <div class="span2" style="border-top:1px dashed var(--line);margin-top:6px;padding-top:8px">
        <label class="check"><input type="checkbox" id="kf-ger" ${k && k.technischeGeraete ? 'checked' : ''}> Technische Geräte im Einsatz (im Rehasport unzulässig! Ausnahme: Ergometer in Herzgruppen)</label>
        <label class="check"><input type="checkbox" id="kf-ergo" ${k && k.ergometer ? 'checked' : ''}> Ergometer nur in Herzgruppe</label>
        <label class="check"><input type="checkbox" id="kf-praev" ${k && k.gemischtMitPraevention ? 'checked' : ''}> Vermischung mit Präventionsangebot (§ 20 SGB V) – unzulässig!</label>
        <label class="check"><input type="checkbox" id="kf-zusatz" ${k && k.zusatzleistungGleichzeitig ? 'checked' : ''}> Zusatzleistungen innerhalb der 45 Min. – unzulässig!</label>
      </div>
      <label class="span2 check"><input type="checkbox" id="kf-aktiv" ${!k || k.aktiv ? 'checked' : ''}> Kurs aktiv</label>
    </div>`,
    [
      { label: 'Abbrechen', cls: 'btn', onClick: closeModal },
      ...(k ? [{ label: 'Löschen', cls: 'btn danger', onClick: async () => {
        if (!confirm('Kurs löschen?')) return;
        try { const r = await api('DELETE', `/api/kurse/${k.id}`); closeModal(); await reload(true); toast(r.deaktiviert ? 'Kurs hat Teilnehmer – deaktiviert.' : 'Gelöscht.'); } catch (e) { toast(e.message, 'err'); }
      } }] : []),
      { label: 'Speichern & prüfen', cls: 'btn primary', onClick: async () => {
        const payload = {
          titel: $('#kf-titel').value.trim(), art: $('#kf-art').value, trainerId: $('#kf-trainer').value,
          wochentag: Number($('#kf-wt').value), beginn: $('#kf-beginn').value,
          dauerMin: Number($('#kf-dauer').value), maxTeilnehmer: Number($('#kf-max').value),
          ort: $('#kf-ort').value.trim(), raumflaecheQm: Number($('#kf-qm').value) || 0,
          startdatum: $('#kf-start').value, enddatum: $('#kf-ende').value,
          betreuungsArzt: $('#kf-arzt').value.trim() ? { name: $('#kf-arzt').value.trim(), visitationAm: $('#kf-vis').value } : null,
          notfallplan: $('#kf-plan').checked,
          aed: { vorhanden: $('#kf-aed').checked, wartungAm: $('#kf-aedw').value },
          notfallkoffer: $('#kf-koffer').checked, notfallUebungAm: $('#kf-notfueb').value,
          technischeGeraete: $('#kf-ger').checked, ergometer: $('#kf-ergo').checked,
          gemischtMitPraevention: $('#kf-praev').checked, zusatzleistungGleichzeitig: $('#kf-zusatz').checked,
          aktiv: $('#kf-aktiv').checked,
        };
        if (!payload.titel || !payload.trainerId || !payload.startdatum) { toast('Titel, Übungsleitung und Startdatum sind Pflicht.', 'err'); return; }
        try {
          const r = await api(k ? 'PUT' : 'POST', k ? `/api/kurse/${k.id}` : '/api/kurse', payload);
          const p = r.pruefung;
          if (p.blockiert) toast(`Kurs gespeichert, aber RSD-Verstöße: ${p.fehler.join(' | ')}`, 'err');
          else if (p.hinweise.length) toast(`Gespeichert. Hinweise: ${p.hinweise.join(' | ')}`);
          else toast('Kurs gespeichert – alle RSD-Prüfungen bestanden.', 'ok');
          closeModal(); await reload(true);
        } catch (e) { toast(e.message, 'err'); }
      } },
    ], { wide: true });
  const artSel = $('#kf-art');
  const upd = () => {
    const a = S.regeln.arten[artSel.value] || {};
    $('#kf-dauer').value = k && k.art === artSel.value ? k.dauerMin : a.minDauerMin;
    $('#kf-max').value = k && k.art === artSel.value ? k.maxTeilnehmer : a.maxTN;
    $('#kf-herz-hint').hidden = !(artSel.value === 'herzgruppe' || artSel.value === 'herzinsuffizienz');
  };
  artSel.addEventListener('change', upd);
  if (!k) upd();
};
$('#btn-neuer-kurs').onclick = () => kursForm(null);

window.kursToggle = async (id) => {
  const k = (S.kurse || []).find((x) => x.id === id);
  try { await api('PUT', `/api/kurse/${id}`, { aktiv: !k.aktiv }); await reload(true); }
  catch (e) { toast(e.message, 'err'); }
};

window.oeffneKalenderTagKurs = async (kid) => {
  zeigeView('kalender');
  const k = (S.kurse || []).find((x) => x.id === kid);
  const heute = new Date();
  const ziel = new Date();
  while (ziel.getDay() !== Number(k.wochentag) || ziel < heute) ziel.setDate(ziel.getDate() + 1);
  const iso = `${ziel.getFullYear()}-${String(ziel.getMonth() + 1).padStart(2, '0')}-${String(ziel.getDate()).padStart(2, '0')}`;
  calMon = new Date(ziel); calMon.setDate(1);
  await renderKalender();
  zeigeTag(iso);
};

/* ============================== KALENDER ============================== */
let calMon = new Date(); calMon.setDate(1);
let calTermine = [];

async function ladeTermine(von, bis) {
  const r = await api('GET', `/api/termine?von=${von}&bis=${bis}`);
  termineCache = r.termine;
  return r.termine;
}

async function renderKalender() {
  const share = await api('GET', '/api/kalender/share');
  const lokal = Boolean(share.lokalModus || window.LOCAL_MODE);
  if (lokal) {
    $('#share-url').textContent = 'Kalender als .ics-Datei teilen (Google/Apple/Outlook) – ohne Patientendaten';
    $('#share-hinweis').textContent = share.datenschutzHinweis;
    $('#btn-share-copy').textContent = '📅 An Google Kalender / teilen';
    $('#btn-share-copy').onclick = teileIcsDatei;
    $('#btn-share-rotate').hidden = true;
    $('#chk-share').checked = share.geteilt !== false;
    $('#chk-share').parentElement.lastChild.textContent = ' Kalender-Export aktiv (Freigabe über Teilen-Funktion)';
  } else {
    $('#share-url').textContent = share.url;
    $('#share-hinweis').textContent = share.datenschutzHinweis;
    $('#btn-share-copy').textContent = '🔗 Link kopieren';
    $('#btn-share-copy').onclick = async () => {
      try { await navigator.clipboard.writeText($('#share-url').textContent); toast('Kalender-Link kopiert.', 'ok'); }
      catch (_) { toast('Bitte Link manuell markieren/kopieren.', 'err'); }
    };
    $('#btn-share-rotate').hidden = false;
    $('#chk-share').checked = share.geteilt;
  }

  const jahr = calMon.getFullYear(), mon = calMon.getMonth();
  $('#cal-label').textContent = calMon.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });

  const von = new Date(jahr, mon, 1).toISOString().slice(0, 10);
  const letzte = new Date(jahr, mon + 1, 0);
  const bis = letzte.toISOString().slice(0, 10);
  kalenderFilterLeiste();
  calTermine = kalenderFiltern(await ladeTermine(von, bis));

  const erstes = new Date(jahr, mon, 1);
  const startOffset = erstes.getDay(); // So=0
  const grid = $('#kalender-grid');
  let html = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map((w) => `<div class="wd">${w}</div>`).join('');
  const cells = [];
  const startMontag = new Date(erstes); startMontag.setDate(1 - startOffset);
  for (let i = 0; i < 42; i++) {
    const d = new Date(startMontag); d.setDate(startMontag.getDate() + i);
    const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const evs = calTermine.filter((t) => t.datum === iso);
    cells.push(`<div class="day ${d.getMonth() !== mon ? 'other' : ''} ${iso === heutigesISO() ? 'today' : ''}" data-d="${iso}">
      <div class="dnum">${d.getDate()}</div>
      ${evs.map((t) => `<div class="ev ${t.status}" title="${esc(t.kurs.titel)} · ${esc(t.kurs.trainerName || '')}" style="border-left:4px solid ${trainerFarbe(t.kurs.trainerId)}">${esc(t.beginn)} ${esc(t.kurs.titel)}</div>`).join('')}
    </div>`);
    if (i >= 34 && d.getMonth() !== mon && i % 7 === 6) break;
  }
  grid.innerHTML = html + cells.join('');
  $$('#kalender-grid .day').forEach((el) => { el.onclick = () => zeigeTag(el.dataset.d); });
}

async function teileIcsDatei() {
  try {
    const d = await api('GET', '/api/state');
    const token = d.settings.kalender.token;
    const r = await api('GET', `/api/calendar/${token}.ics`);
    const ics = r.ics || r;
    await dateiTeilen('rheasport-kalender.ics', ics, 'text/calendar');
  } catch (e) { toast(`Kalender-Export fehlgeschlagen: ${e.message}`, 'err'); }
}
window.teileIcsDatei = teileIcsDatei;

$('#cal-prev').onclick = () => { calMon.setMonth(calMon.getMonth() - 1); renderKalender(); };
$('#cal-next').onclick = () => { calMon.setMonth(calMon.getMonth() + 1); renderKalender(); };
$('#chk-share').onchange = async () => { await api('PUT', '/api/settings', { kalender: { geteilt: $('#chk-share').checked } }); await reload(false); };
$('#btn-share-copy').onclick = async () => {
  try { await navigator.clipboard.writeText($('#share-url').textContent); toast('Kalender-Link kopiert.', 'ok'); }
  catch (_) { toast('Bitte Link manuell markieren/kopieren.', 'err'); }
};
$('#btn-share-rotate').onclick = async () => {
  if (!confirm('Link erneuern? Bestehende Abonnements müssen aktualisiert werden.')) return;
  await api('POST', '/api/kalender/rotate'); await renderKalender(); toast('Neuer Kalender-Link erzeugt.', 'ok');
};

function zeigeTag(iso) {
  const tag = termineCache.filter((t) => t.datum === iso);
  $('#cal-day-box').hidden = false;
  $('#cal-day-title').textContent = new Date(`${iso}T12:00:00`).toLocaleDateString('de-DE', { weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric' });
  $('#cal-day-list').innerHTML = tag.length ? tag.map((t) => `
    <div class="tn-row">
      <div class="nm"><strong>${esc(t.beginn)} Uhr</strong> · ${esc(t.kurs.titel)}</div>
      <div class="st">${esc((S.regeln.arten[t.kurs.art] || {}).label || '')} · ${esc(t.kurs.ort || '')} · ${t.dauerMin} Min. · ${tLink(t.kurs.trainerId, t.kurs.trainerName || '')}</div>
      <span class="chip ${t.status === 'stattgefunden' ? 'green' : t.status === 'ausgefallen' ? 'gray' : t.status === 'verschoben' ? 'amber' : 'blue'}">${esc(t.status)}</span>
      <span class="chip ${t.leiterBestaetigung ? 'green' : 'amber'}">Leitung ${t.leiterBestaetigung ? '✓' : 'offen'}</span>
      <button class="btn small" onclick="oeffneTermin('${t.id}')">Verwalten &amp; unterschreiben</button>
    </div>`).join('') : '<div class="muted">Keine Termine an diesem Tag.</div>';
}

/** Frühere, bereits stattgefundene Einheiten des Patienten ohne Unterschrift und ohne dokumentierten Grund. */
function fehlendeUnterschriften(pid, ausser) {
  const res = [], heute = heutigesISO();
  for (const z of (S.zuordnungen || []).filter((x) => x.patientId === pid)) {
    const v = (S.verordnungen || []).find((x) => x.id === z.verordnungId);
    for (const t of (S.termine || [])) {
      if (t.kursId !== z.kursId || t.id === ausser || t.status !== 'stattgefunden' || t.datum > heute) continue;
      if (z.aktiv === false && !(z.abgebrochenAm && t.datum <= z.abgebrochenAm)) continue;
      if (v && ((v.von && t.datum < v.von) || (v.bis && t.datum > v.bis))) continue;
      const a = (t.anwesenheit || []).find((x) => x.patientId === pid);
      if (a && (a.unterschriftPng || a.unterschriftPapier || a.fehlGrund)) continue;
      res.push(t);
    }
  }
  return res.sort((a, b) => a.datum.localeCompare(b.datum));
}

/** Dialog: fehlende Unterschrift nachholen oder Grund des Fehlens festhalten. */
function fehlendeDialog(pid, name, zurueck, ausser) {
  const liste = fehlendeUnterschriften(pid, ausser);
  const gruende = ['Nicht erschienen / entschuldigt', 'Krank', 'Urlaub', 'Unterschrift vergessen (Papierliste folgt)', 'Sonstiges'];
  openModal(`Fehlende Unterschriften – ${name}`, liste.length ? liste.map((t) => `
    <div class="tn-row" data-t="${t.id}">
      <div class="nm">${fmt(t.datum)} ${esc(t.beginn || '')} Uhr<div class="muted small">${esc(kursname(t.kursId))}</div></div>
      <button class="btn small primary fd-sig">✍ Nachholen</button>
      <select class="fd-sel">${gruende.map((g) => `<option>${esc(g)}</option>`).join('')}</select>
      <input class="fd-txt" placeholder="Details (optional)" style="flex:1;min-width:120px">
      <button class="btn small fd-grund">Grund speichern</button>
    </div>`).join('') + '<p class="hint">Nachgeholte Unterschriften erhalten den aktuellen Zeitstempel und werden im Audit-Log als nachgeholt gekennzeichnet.</p>'
    : '<div class="muted">Alles erledigt – keine fehlenden Unterschriften.</div>',
  [{ label: 'Zurück', cls: 'btn primary', onClick: () => { closeModal(); if (zurueck) zurueck(); } }], { wide: true });
  $$('#modal-body .tn-row[data-t]').forEach((row) => {
    const tid = row.dataset.t;
    row.querySelector('.fd-sig').onclick = async () => {
      const png = await openSigPad(`Nachgeholte Unterschrift – ${name}`, `${fmt((S.termine.find((x) => x.id === tid) || {}).datum)} · wird mit heutigem Zeitstempel gespeichert`);
      if (!png) return;
      try { await api('POST', `/api/termine/${tid}/anwesenheit`, { patientId: pid, wahrgenommen: true, unterschriftPng: png }); await reload(false); toast('Unterschrift nachgeholt.', 'ok'); fehlendeDialog(pid, name, zurueck, ausser); }
      catch (e) { toast(e.message, 'err'); }
    };
    row.querySelector('.fd-grund').onclick = async () => {
      const txt = row.querySelector('.fd-txt').value.trim();
      const grund = row.querySelector('.fd-sel').value + (txt ? ' – ' + txt : '');
      try { await api('POST', `/api/termine/${tid}/anwesenheit`, { patientId: pid, fehlGrund: grund }); await reload(false); toast('Grund dokumentiert.', 'ok'); fehlendeDialog(pid, name, zurueck, ausser); }
      catch (e) { toast(e.message, 'err'); }
    };
  });
}

window.oeffneTermin = async (tid) => {
  let t = termineCache.find((x) => x.id === tid);
  if (!t) { // vergangene Termine (z. B. aus Dokumente/Dashboard/Patient): Zeitraum um den Termin laden, Kalender-Cache nicht überschreiben
    const st = (S.termine || []).find((x) => x.id === tid);
    if (st) {
      const tag = (n) => new Date(new Date(`${st.datum}T12:00:00Z`).getTime() + n * 86400000).toISOString().slice(0, 10);
      try { const r = await api('GET', `/api/termine?von=${tag(-1)}&bis=${tag(1)}`); t = (r.termine || []).find((x) => x.id === tid); if (t) termineCache = termineCache.concat([t]); } catch (_) { /* weiter unten */ }
    }
  }
  if (!t) { const r = await api('GET', `/api/termine?von=${heutigesISO()}&bis=${new Date(Date.now() + 400 * 86400000).toISOString().slice(0, 10)}`); termineCache = r.termine; t = termineCache.find((x) => x.id === tid); }
  if (!t) { try { await ladeTermine(heutigesISO(), new Date(Date.now() + 400 * 86400000).toISOString().slice(0, 10)); t = termineCache.find((x) => x.id === tid); } catch (_) {} }
  if (!t) { toast('Termin nicht gefunden (ggf. erst nach Erzeugen der Termine).', 'err'); return; }

  const [h, m] = String(t.beginn || '00:00').split(':').map(Number);
  const ende = new Date(`${t.datum}T${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:00`);
  ende.setMinutes(ende.getMinutes() + (t.dauerMin || 45));
  const vorbei = new Date() >= ende;
  const startZ = new Date(ende.getTime() - (t.dauerMin || 45) * 60000);
  const vorabMin = Math.max(0, Number((S.settings.unterschrift || {}).vorabMinuten ?? 20));
  const fensterOffen = () => new Date() >= new Date(startZ.getTime() - vorabMin * 60000);
  const darfUnterschreiben = () => vorbei || t.status === 'stattgefunden' || fensterOffen();

  const zeichne = () => {
    const tn = (t.teilnehmer || []).map((p) => {
      const hatSig = p.unterschrift;
      return `<div class="tn-row" data-p="${p.patientId}">
        <div class="nm">${pLink(p.patientId, p.name)}</div>
        <label class="check" style="margin:0"><input type="checkbox" class="tn-w" ${p.wahrgenommen ? 'checked' : ''}> teilgenommen</label>
        <div class="st">${p.zeitstempel ? `⏱ ${new Date(p.zeitstempel).toLocaleString('de-DE')}` : '–'}</div>
        ${hatSig ? `<img class="sig" src="${p.unterschriftBild || ''}" alt="Unterschrift">` : (p.papier ? '<span class="chip green">Papierliste</span>' : (p.wahrgenommen ? '<span class="chip amber">ohne Unterschrift</span>' : ''))}
        ${p.vorab ? '<span class="chip amber" title="Vor Kursbeginn geleistet – Teilnahme von der Leitung bestätigen, sonst stornieren">vorab</span>' : ''}
        ${p.fehlGrund ? `<span class="chip gray" title="${esc(p.fehlGrund.grund)}">Grund: ${esc(p.fehlGrund.grund.slice(0, 40))}</span>` : ''}
        <button class="btn small tn-sig" ${!darfUnterschreiben() ? `disabled title="Frühestens ${vorabMin} Min. vor Kursbeginn"` : ''}>✍ ${hatSig ? 'korrigieren' : 'unterschreiben'}</button>
        <button class="btn small tn-papier" ${p.wahrgenommen ? '' : 'disabled'}>Papierliste</button>
        ${hatSig ? '<button class="btn small danger tn-del" title="Unterschrift stornieren">✕ Storno</button>' : ''}
        ${(() => { const f = fehlendeUnterschriften(p.patientId, t.id); return f.length ? `<div style="flex-basis:100%"><span class="chip red">⚠ ${f.length} frühere Einheit(en) ohne Unterschrift: ${f.slice(-3).map((x) => fmt(x.datum).slice(0, 5)).join(', ')}${f.length > 3 ? ' …' : ''}</span> <button class="btn small tn-fehlt">Nachholen / Grund</button></div>` : ''; })()}
      </div>`;
    }).join('') || '<div class="muted">Keine Teilnehmer dieser festen Gruppe.</div>';

    const body = `
      <div class="grid2">
        <div>
          <div class="hint">${esc(t.kurs.titel)} · ${esc((S.regeln.arten[t.kurs.art] || {}).label || '')}<br>
          ${esc(t.kurs.ort || '')} · Übungsleitung: ${tLink(t.kurs.trainerId, t.kurs.trainerName || '')} · ${t.dauerMin} Min. · <strong>${esc(t.status)}</strong>
          ${!darfUnterschreiben() && t.status === 'geplant' ? `<br>⚠ Unterschriften sind ab ${vorabMin} Min. vor Kursbeginn möglich.` : ''}</div>
          <div class="row">
            <button class="btn small" id="tm-statt">✔ als durchgeführt</button>
            <button class="btn small danger" id="tm-aus">Als ausgefallen</button>
          </div>
          <div class="row" style="margin-top:8px">
            <input type="date" id="tm-neudat" value="${t.datum}">
            <input type="time" id="tm-neuzeit" value="${t.beginn}">
            <button class="btn small" id="tm-versch">Termin verschieben</button>
          </div>
          <label style="margin-top:10px">Dokumentation / besondere Vorkommnisse<textarea id="tm-doku" rows="3">${esc(t.dokumentation || '')}</textarea></label>
          <button class="btn small" id="tm-doku-sav">Dokumentation speichern</button>
          ${(t.kurs.art === 'herzgruppe' || t.kurs.art === 'herzinsuffizienz') ? `
            <label style="margin-top:10px">Arztvisitation (mind. alle 6 Wochen, Rahmenvereinbarung)<input type="date" id="tm-visdat" value="${esc((t.arztvisitation || {}).datum || '')}"></label>
            <label>Ärztin/Arzt<input id="tm-visarzt" value="${esc((t.arztvisitation || {}).arzt || (t.kurs.betreuungsArzt || {}).name || '')}"></label>
            <button class="btn small" id="tm-vis-sav">Visitation dokumentieren</button>` : ''}
        </div>
        <div>
          <h2 style="font-size:15px">Teilnahmebestätigung (Unterschriften)</h2>
          ${tn}
          <div class="hint" style="margin-top:10px">Die/der Versicherte quittiert <strong>unmittelbar vor oder nach</strong> der Übungseinheit. Unterschriften sind ab ${vorabMin} Min. vor Kursbeginn möglich und können bis zur Leitungsbestätigung storniert werden; als „vorab“ gekennzeichnete Unterschriften zählen erst nach der Bestätigung der Leitung. Zeitstempel ersetzt Datumsstempel (kein Vordatieren).</div>
          <div class="tn-row">
            <div class="nm">Bestätigung Übungsleitung</div>
            <div class="st">${t.leiterBestaetigung ? `✔ ${esc(t.leiterBestaetigung.name)} · ${new Date(t.leiterBestaetigung.ts).toLocaleString('de-DE')}` : 'offen – wird nach der Einheit benötigt (Abrechnungsvoraussetzung)'}</div>
            ${t.leiterBestaetigung && t.leiterBestaetigung.unterschriftPng ? `<img class="sig" src="${t.leiterBestaetigung.unterschriftPng}" alt="Sig">` : ''}
            <button class="btn small primary" id="tm-leiter" ${(!vorbei && t.status !== 'stattgefunden') ? 'disabled title="Erst nach der Übungseinheit"' : ''}>✍ Leitungs-Unterschrift</button>
          </div>
        </div>
      </div>`;

    openModal(`Termin ${fmt(t.datum)} – ${t.beginn} Uhr`, body, [
      { label: 'Schließen', cls: 'btn primary', onClick: async () => { closeModal(); await renderKalender(); if (aktuelleView === 'dashboard') renderDashboard(); } },
    ], { wide: true });

    const refresh = async () => { await api('GET', `/api/termine?von=${t.datum}&bis=${t.datum}`).then((r) => { const n = r.termine.find((x) => x.id === t.id); if (n) t = n; }).catch(() => {}); };

    $('#tm-statt').onclick = async () => { try { await api('PUT', `/api/termine/${t.id}`, { status: 'stattgefunden' }); await refresh(); zeichne(); toast('Als durchgeführt markiert.', 'ok'); } catch (e) { toast(e.message, 'err'); } };
    $('#tm-aus').onclick = async () => { try { await api('PUT', `/api/termine/${t.id}`, { status: 'ausgefallen' }); await refresh(); zeichne(); toast('Als ausgefallen markiert.'); } catch (e) { toast(e.message, 'err'); } };
    $('#tm-versch').onclick = async () => {
      try { await api('PUT', `/api/termine/${t.id}`, { neuesDatum: $('#tm-neudat').value, neueBeginn: $('#tm-neuzeit').value }); await refresh(); zeichne(); toast('Termin verschoben (Kalender-Feed aktualisiert).', 'ok'); } catch (e) { toast(e.message, 'err'); }
    };
    $('#tm-doku-sav').onclick = async () => { try { await api('PUT', `/api/termine/${t.id}`, { dokumentation: $('#tm-doku').value }); await refresh(); toast('Dokumentation gespeichert.', 'ok'); } catch (e) { toast(e.message, 'err'); } };
    const vsav = $('#tm-vis-sav');
    if (vsav) vsav.onclick = async () => {
      try { await api('PUT', `/api/termine/${t.id}`, { arztvisitation: { datum: $('#tm-visdat').value, arzt: $('#tm-visarzt').value } }); await refresh(); zeichne(); toast('Visitation dokumentiert.', 'ok'); } catch (e) { toast(e.message, 'err'); }
    };

    $$('#modal-body .tn-row[data-p]').forEach((row) => {
      const pid = row.dataset.p;
      const w = row.querySelector('.tn-w');
      if (w) w.onchange = async () => {
        try { await api('POST', `/api/termine/${t.id}/anwesenheit`, { patientId: pid, wahrgenommen: w.checked }); await refresh(); } catch (e) { toast(e.message, 'err'); w.checked = !w.checked; }
      };
      const sig = row.querySelector('.tn-sig');
      if (sig) sig.onclick = async () => {
        const name = (t.teilnehmer.find((p) => p.patientId === pid) || {}).name || '';
        const png = await openSigPad(`Teilnahmebestätigung – ${name}`, `${fmt(t.datum)} ${t.beginn} Uhr · ${t.kurs.titel}`);
        if (!png) return;
        try { await api('POST', `/api/termine/${t.id}/anwesenheit`, { patientId: pid, wahrgenommen: true, unterschriftPng: png }); await refresh(); zeichne(); toast('Unterschrift gespeichert (Zeitstempel).', 'ok'); } catch (e) { toast(e.message, 'err'); }
      };
      const pap = row.querySelector('.tn-papier');
      if (pap) pap.onclick = async () => {
        try { await api('POST', `/api/termine/${t.id}/anwesenheit`, { patientId: pid, wahrgenommen: true, unterschriftPapier: true }); await refresh(); zeichne(); toast('Papier-Unterschrift vermerkt.', 'ok'); } catch (e) { toast(e.message, 'err'); }
      };
      const fehlt = row.querySelector('.tn-fehlt');
      if (fehlt) fehlt.onclick = () => fehlendeDialog(pid, (t.teilnehmer.find((x) => x.patientId === pid) || {}).name || '', () => window.oeffneTermin(t.id), t.id);
      const del = row.querySelector('.tn-del');
      if (del) del.onclick = async () => {
        if (!confirm('Unterschrift stornieren? Das Storno wird im Audit-Log protokolliert.')) return;
        try { await api('POST', `/api/termine/${t.id}/anwesenheit`, { patientId: pid, unterschriftStorno: true }); await refresh(); zeichne(); } catch (e) { toast(e.message, 'err'); }
      };
    });
    $('#tm-leiter').onclick = async () => {
      const name = (t.kurs.trainerName && t.kurs.trainerName !== '–') ? t.kurs.trainerName : prompt('Name der/des Übungsleitenden:') || '';
      const png = await openSigPad('Bestätigung der/des Übungsleitenden', `${name} · ${fmt(t.datum)} – Bestätigung der Teilnahme`);
      if (!png) return;
      try { await api('PUT', `/api/termine/${t.id}`, { leiterBestaetigung: { name, unterschriftPng: png } }); await refresh(); zeichne(); toast('Leitungs-Bestätigung gespeichert – Einheit gilt als durchgeführt.', 'ok'); } catch (e) { toast(e.message, 'err'); }
    };
  };
  zeichne();
};

/* ============================== DOKUMENTE (Scans, Doku, Teilnehmerlisten, Vorlagen) ============================== */
let DOK_TAB = 'akte';
const DOK_KATEGORIEN = ['Verordnung', 'Kostenübernahme / Genehmigung', 'Einwilligung / Datenschutz', 'Arztbericht', 'Teilnehmerliste (Papier)', 'Sonstiges'];
const MONATE = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
const monatTitel = (m) => `${MONATE[Number(m.slice(5, 7)) - 1]} ${m.slice(0, 4)}`;
const patientName = (p) => `${p.nachname}, ${p.vorname}`;

async function blobTeilen(name, blob) {
  try {
    const file = new File([blob], name, { type: blob.type });
    if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: name }); return; }
  } catch (e) { if (e && e.name === 'AbortError') return; }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 8000);
}

/** Foto verkleinern, optional als Scan (Graustufen + Kontrast) aufbereiten. */
async function bildAufbereiten(file, scanModus) {
  if (file.type === 'application/pdf') return file;
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Bild konnte nicht gelesen werden.')); i.src = url; });
    const r = Math.min(1, 1800 / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement('canvas');
    c.width = Math.round(img.naturalWidth * r); c.height = Math.round(img.naturalHeight * r);
    const ctx = c.getContext('2d');
    if (scanModus) ctx.filter = 'grayscale(1) contrast(1.7) brightness(1.08)';
    ctx.drawImage(img, 0, 0, c.width, c.height);
    return await new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error('Bild konnte nicht gespeichert werden.'))), 'image/jpeg', 0.82));
  } finally { URL.revokeObjectURL(url); }
}

/** Scan-Bedienelemente + Dateiliste. pid fest (Patienten-Reiter) oder null (Gesamtansicht mit Auswahl). */
async function dokScansInto(el, pid) {
  if (!window.RheaStore) { el.innerHTML = '<div class="muted">Dateiablage nicht verfügbar.</div>'; return; }
  const pats = (S.patienten || []).slice().sort((a, b) => patientName(a).localeCompare(patientName(b), 'de'));
  const sel = pid ? '' : `<label>Patient/in *<select id="dk-pat"><option value="">– wählen –</option>${pats.map((p) => `<option value="${p.id}">${esc(patientName(p))}</option>`).join('')}</select></label>`;
  el.innerHTML = `
    <div class="card" style="margin-bottom:10px"><div class="form2">${sel}
      <label>Art<select id="dk-kat">${DOK_KATEGORIEN.map((k) => `<option>${esc(k)}</option>`).join('')}</select></label></div>
      <label class="check"><input type="checkbox" id="dk-scan" checked> Scan-Optimierung (Graustufen, mehr Kontrast, verkleinert)</label>
      <div class="row" style="margin-top:8px">
        <label class="btn primary" for="dk-cam">📷 Mit Kamera scannen</label><input type="file" id="dk-cam" accept="image/*" capture="environment" hidden>
        <label class="btn" for="dk-gal">🖼 Aus Galerie/Dateien</label><input type="file" id="dk-gal" accept="image/*,application/pdf" multiple hidden>
      </div>
      <p class="hint">Ablage automatisch im Ordner <code>Patienten/Nachname_Vorname/</code> (lokal auf dem Gerät). Mehrseitige Dokumente: einfach mehrere Seiten nacheinander scannen.</p></div>
    <div id="dk-liste"></div>`;
  const liste = $('#dk-liste', el) || el.querySelector('#dk-liste');
  const zeige = async () => {
    const docs = await RheaStore.listDocs(pid || undefined);
    const gruppen = new Map();
    for (const d of docs) { if (!gruppen.has(d.patientId)) gruppen.set(d.patientId, []); gruppen.get(d.patientId).push(d); }
    if (!docs.length) { liste.innerHTML = '<div class="muted">Noch keine Dokumente gescannt.</div>'; return; }
    liste.innerHTML = [...gruppen.entries()].map(([id, ds]) => {
      const p = (S.patienten || []).find((x) => x.id === id);
      return `<h2 style="font-size:15px;margin:12px 0 6px">📁 ${esc(p ? patientName(p) : ds[0].ordner)} <span class="muted small">(${ds.length})</span></h2>
        <div class="dok-grid">${ds.map((d) => `<button class="dok-card" data-d="${d.id}"><span hidden>${esc(p ? patientName(p) : ds[0].ordner)}</span><div class="dok-th" data-th="${d.id}">${d.mime === 'application/pdf' ? '📄' : ''}</div><div class="small"><strong>${esc(d.kategorie)}</strong><br>${fmt(d.ts.slice(0, 10))} · ${Math.round(d.size / 1024)} KB</div></button>`).join('')}</div>`;
    }).join('');
    for (const d of docs.filter((x) => x.mime !== 'application/pdf')) {
      RheaStore.getBlob(d.id).then((b) => { const th = liste.querySelector(`[data-th="${d.id}"]`); if (b && th) th.innerHTML = `<img alt="" src="${URL.createObjectURL(b)}">`; });
    }
    $$('.dok-card', liste).forEach((b) => { b.onclick = () => dokOeffnen(docs.find((x) => x.id === b.dataset.d), zeige); });
    installFilter('#dk-liste', '.dok-card', { placeholder: 'Patient, Dokumentart …',
      selects: [{ id: 'kat', label: 'Art', options: DOK_KATEGORIEN.map((k) => [k, k]), match: (el, v) => el.textContent.includes(v) }],
      after: (host) => host.querySelectorAll('.dok-grid').forEach((g) => { const leer = !g.querySelector('.dok-card:not([hidden])'); g.hidden = leer; if (g.previousElementSibling) g.previousElementSibling.hidden = leer; }) });
  };
  const aufnehmen = async (files) => {
    const patientId = pid || ($('#dk-pat', el) || el.querySelector('#dk-pat')).value;
    const p = (S.patienten || []).find((x) => x.id === patientId);
    if (!p) { toast('Bitte zuerst eine Patientin/einen Patienten wählen.', 'err'); return; }
    let n = 0;
    try {
      for (const f of files) {
        const blob = await bildAufbereiten(f, el.querySelector('#dk-scan').checked);
        await RheaStore.addDoc({ patientId, patientName: `${p.nachname}_${p.vorname}`, kategorie: el.querySelector('#dk-kat').value }, blob);
        n++;
      }
      toast(`${n} Dokument(e) gespeichert.`, 'ok');
    } catch (e) { toast(`Speichern fehlgeschlagen: ${e.message}`, 'err'); }
    await zeige();
  };
  el.querySelector('#dk-cam').onchange = (e) => { const f = [...e.target.files]; e.target.value = ''; if (f.length) aufnehmen(f); };
  el.querySelector('#dk-gal').onchange = (e) => { const f = [...e.target.files]; e.target.value = ''; if (f.length) aufnehmen(f); };
  await zeige();
}

async function dokOeffnen(d, nachher) {
  const blob = await RheaStore.getBlob(d.id);
  if (!blob) { toast('Datei nicht gefunden.', 'err'); return; }
  const url = URL.createObjectURL(blob);
  openModal(`${d.kategorie} – ${fmt(d.ts.slice(0, 10))}`,
    d.mime === 'application/pdf' ? `<iframe src="${url}" style="width:100%;height:70vh;border:0"></iframe>` : `<img src="${url}" alt="" style="max-width:100%;display:block;margin:0 auto">`,
    [
      { label: 'Löschen', cls: 'btn danger', onClick: async () => { if (!confirm('Dokument endgültig löschen?')) return; await RheaStore.delDoc(d.id); closeModal(); if (nachher) nachher(); } },
      { label: 'Teilen/Speichern', cls: 'btn', onClick: () => blobTeilen(d.datei, blob) },
      { label: 'Schließen', cls: 'btn primary', onClick: closeModal },
    ], { wide: true, onClose: () => URL.revokeObjectURL(url) });
}

/* ---- Trainingsdokumentation & Teilnehmerlisten (Ansicht + Druck) ---- */
function kursTermine(kid, monat) {
  return (S.termine || []).filter((t) => t.kursId === kid && t.datum.startsWith(monat) && t.status !== 'ausgefallen' && t.status !== 'verschoben')
    .sort((a, b) => (a.datum + a.beginn).localeCompare(b.datum + b.beginn));
}
function kursKopfHtml(k, monat) {
  const an = S.settings.anbieter || {};
  const t = (S.trainer || []).find((x) => x.id === k.trainerId);
  return `<div class="sub">${esc(an.name || '')}${an.ik ? ' · IK ' + esc(an.ik) : ''}</div>
    <table class="kopf"><tr><td>Gruppe:</td><td><strong>${esc(k.titel)}</strong> (${esc((S.regeln.arten[k.art] || {}).label || '')})</td></tr>
    <tr><td>Ort / Zeit:</td><td>${esc(k.ort || '')} · ${esc(k.beginn || '')} Uhr · ${k.dauerMin || 45} Min.</td></tr>
    <tr><td>Übungsleitung:</td><td>${esc(t ? `${t.vorname} ${t.nachname}` : '')}</td></tr>
    <tr><td>Monat:</td><td>${monat ? esc(monatTitel(monat)) : '____________________'}</td></tr></table>`;
}
function teilnehmerlisteHtml(k, monat, leer) {
  const termine = leer ? [] : kursTermine(k.id, monat);
  const spalten = Math.max(termine.length, leer ? 12 : 0);
  const von = `${monat}-01`;
  const zu = (S.zuordnungen || []).filter((z) => z.kursId === k.id && (z.aktiv !== false || (z.abgebrochenAm && z.abgebrochenAm >= von)));
  const pats = zu.map((z) => (S.patienten || []).find((p) => p.id === z.patientId)).filter(Boolean)
    .sort((a, b) => patientName(a).localeCompare(patientName(b), 'de'));
  const zeilenAnz = leer ? Math.max(pats.length, 15) : pats.length;
  let kopf = '<th style="width:4%">Nr.</th><th style="min-width:130px">Name</th>';
  for (let i = 0; i < spalten; i++) kopf += `<th style="text-align:center;font-size:10.5px">${termine[i] ? fmt(termine[i].datum).slice(0, 5) : ''}</th>`;
  let body = '';
  for (let r = 0; r < zeilenAnz; r++) {
    const p = leer ? null : pats[r];
    body += `<tr><td>${r + 1}</td><td>${p ? esc(patientName(p)) : ''}</td>`;
    for (let i = 0; i < spalten; i++) {
      const a = termine[i] && p ? (termine[i].anwesenheit || []).find((x) => x.patientId === p.id) : null;
      body += `<td style="text-align:center;height:26px">${a ? (a.unterschriftPng ? '✔' : a.unterschriftPapier ? 'P' : a.wahrgenommen ? '○' : '–') : ''}</td>`;
    }
    body += '</tr>';
  }
  body += `<tr><td></td><td><strong>Bestätigung Übungsleitung</strong></td>${Array.from({ length: spalten }, (_, i) => `<td style="text-align:center">${termine[i] && termine[i].leiterBestaetigung ? '✔' : ''}</td>`).join('')}</tr>`;
  return `<style>${PRINT_CSS}</style><div class="pr-page" style="max-width:1100px"><h1>Teilnehmerliste${leer ? ' (Vorlage)' : ''}</h1>${kursKopfHtml(k, leer ? '' : monat)}
    <table><thead><tr>${kopf}</tr></thead><tbody>${body}</tbody></table>
    <div class="fine">✔ = digital unterschrieben · P = Papierliste · ○ = teilgenommen ohne Unterschrift · – = nicht teilgenommen. Teilnahme wird je Übungseinheit von der/dem Versicherten unmittelbar vor/nach der Einheit bestätigt.</div>
    <div class="foot"><div>Ort, Datum</div><div>Unterschrift Übungsleitung</div></div></div>`;
}
function trainingsdokuHtml(k, monat, leer) {
  const termine = leer ? [] : kursTermine(k.id, monat);
  const n = leer ? 12 : Math.max(termine.length, 1);
  let zeilen = '';
  for (let i = 0; i < n; i++) {
    const t = termine[i];
    const anz = t ? (t.anwesenheit || []).filter((a) => a.wahrgenommen).length : '';
    zeilen += `<tr><td style="width:11%">${t ? fmt(t.datum) : ''}</td><td style="width:8%">${t ? esc(t.beginn || '') : ''}</td><td style="width:7%;text-align:center">${anz}</td><td style="height:44px">${t ? esc(t.dokumentation || '') : ''}</td><td style="width:20%"></td><td style="width:8%;text-align:center">${t && t.leiterBestaetigung ? '✔' : ''}</td></tr>`;
  }
  return `<style>${PRINT_CSS}</style><div class="pr-page" style="max-width:1100px"><h1>Trainingsdokumentation${leer ? ' (Vorlage)' : ''}</h1>${kursKopfHtml(k, leer ? '' : monat)}
    <table><thead><tr><th>Datum</th><th>Beginn</th><th>TN</th><th>Inhalt / Schwerpunkt der Übungseinheit (Übungen, Belastung)</th><th>Besonderheiten / Vorkommnisse</th><th>Leitung</th></tr></thead><tbody>${zeilen}</tbody></table>
    <div class="fine">Dokumentation je Übungseinheit durch die Übungsleitung (Rahmenvereinbarung Rehabilitationssport/Funktionstraining): Datum, Dauer, Teilnehmerzahl, Inhalte, besondere Vorkommnisse. Aufbewahrung gemäß Vorgaben des Kostenträgers/DSGVO.</div>
    <div class="foot"><div>Ort, Datum</div><div>Unterschrift Übungsleitung</div></div></div>`;
}
function vorkommnisHtml() {
  const an = S.settings.anbieter || {};
  const zeile = (l) => `<tr><td style="width:30%">${l}</td><td style="height:30px"></td></tr>`;
  return `<style>${PRINT_CSS}</style><div class="pr-page"><h1>Vorkommnis- / Notfallprotokoll</h1><div class="sub">${esc(an.name || '')}</div>
    <table>${['Datum, Uhrzeit', 'Gruppe / Ort', 'Betroffene Person', 'Übungsleitung', 'Was ist passiert?', 'Erste Hilfe / Maßnahmen', 'Rettungsdienst gerufen (Uhrzeit)', 'Ärztliche Weiterbehandlung', 'Zeugen'].map(zeile).join('')}</table>
    <div class="foot"><div>Ort, Datum</div><div>Unterschrift Übungsleitung</div></div>
    <div class="fine">Vorlage zur Dokumentation besonderer Vorkommnisse; Herzgruppen: zusätzlich Notfallmeldung gemäß Notfallplan.</div></div>`;
}

function dokKursOptionen(sel) { return (S.kurse || []).map((k) => `<option value="${k.id}" ${k.id === sel ? 'selected' : ''}>${esc(k.titel)}</option>`).join(''); }

function renderDokumente() {
  $$('#view-dokumente .ptab').forEach((b) => {
    b.classList.toggle('active', b.dataset.dt === DOK_TAB);
    b.onclick = () => { DOK_TAB = b.dataset.dt; renderDokumente(); };
  });
  const el = $('#dok-body');
  const heute = heutigesISO();
  if (DOK_TAB === 'akte') { renderAkte(el); return; }
  if (DOK_TAB === 'scans') { dokScansInto(el, null); return; }
  const kurse = S.kurse || [];
  if (!kurse.length) { el.innerHTML = '<div class="muted">Noch keine Kurse angelegt.</div>'; return; }
  if (DOK_TAB === 'doku' || DOK_TAB === 'tl') {
    const st = renderDokumente[DOK_TAB] || (renderDokumente[DOK_TAB] = { kurs: kurse[0].id, monat: heute.slice(0, 7) });
    if (!kurse.some((k) => k.id === st.kurs)) st.kurs = kurse[0].id;
    el.innerHTML = `<div class="filterbar"><label class="small">Gruppe <select id="dd-kurs">${dokKursOptionen(st.kurs)}</select></label>
      <label class="small">Monat <input type="month" id="dd-monat" value="${st.monat}"></label>
      <button class="btn" id="dd-print">🖨 Drucken / Teilen</button></div><div id="dd-inhalt"></div>`;
    const zeichne = () => {
      const k = kurse.find((x) => x.id === st.kurs);
      if (DOK_TAB === 'tl') {
        $('#dd-inhalt').innerHTML = `<div class="table-wrap">${teilnehmerlisteHtml(k, st.monat, false).replace(/<style>[\s\S]*?<\/style>/, '')}</div>`;
      } else {
        const ts = kursTermine(k.id, st.monat);
        $('#dd-inhalt').innerHTML = ts.map((t) => {
          const anz = (t.anwesenheit || []).filter((a) => a.wahrgenommen).length;
          const vorbei = t.datum <= heute;
          return `<div class="item"><div><strong>${fmt(t.datum)}</strong> ${esc(t.beginn || '')} Uhr · <span class="muted">${anz} Teilnehmende · ${t.leiterBestaetigung ? 'Leitung bestätigt' : 'Leitung offen'}</span>
            <div class="small">${t.dokumentation ? esc(t.dokumentation) : (vorbei && t.status === 'stattgefunden' ? '<span class="chip amber">Dokumentation fehlt</span>' : '<span class="muted">–</span>')}</div></div>
            <button class="btn small" onclick="oeffneTermin('${t.id}')">Öffnen</button></div>`;
        }).join('') || '<div class="muted">Keine Termine in diesem Monat.</div>';
      }
    };
    $('#dd-kurs').onchange = (e) => { st.kurs = e.target.value; zeichne(); };
    $('#dd-monat').onchange = (e) => { if (e.target.value) { st.monat = e.target.value; zeichne(); } };
    $('#dd-print').onclick = () => {
      const k = kurse.find((x) => x.id === st.kurs);
      const html = DOK_TAB === 'tl' ? teilnehmerlisteHtml(k, st.monat, false) : trainingsdokuHtml(k, st.monat, false);
      zeigeDruckansicht(html, `${DOK_TAB === 'tl' ? 'Teilnehmerliste' : 'Trainingsdokumentation'}_${RheaStore.sanit(k.titel)}_${st.monat}.html`);
    };
    zeichne();
    return;
  }
  // Vorlagen
  const st = renderDokumente.vorl || (renderDokumente.vorl = { kurs: kurse[0].id });
  el.innerHTML = `<p class="hint">Leere Vorlagen zum Ausdrucken (Papierdokumentation / Ausfall der Technik). Orientiert an den Anforderungen der Rahmenvereinbarung – im Zweifel mit dem Kostenträger bzw. RSD abgleichen.</p>
    <div class="filterbar"><label class="small">Gruppe vorausfüllen <select id="dv-kurs">${dokKursOptionen(st.kurs)}</select></label></div>
    <div class="row"><button class="btn" data-v="doku">🖨 Trainingsdokumentation</button><button class="btn" data-v="tl">🖨 Teilnehmerliste</button><button class="btn" data-v="vork">🖨 Vorkommnis-/Notfallprotokoll</button><button class="btn" data-v="bp">🖨 Beratungsprotokoll (leer)</button></div>`;
  $('#dv-kurs').onchange = (e) => { st.kurs = e.target.value; };
  $$('#dok-body [data-v]').forEach((b) => { b.onclick = () => {
    const k = kurse.find((x) => x.id === st.kurs);
    const v = b.dataset.v;
    if (v === 'bp') { window.druckeBeratung(null); return; }
    zeigeDruckansicht(v === 'doku' ? trainingsdokuHtml(k, '', true) : v === 'tl' ? teilnehmerlisteHtml(k, '', true) : vorkommnisHtml(), `Vorlage_${v}.html`);
  }; });
}

/* ------------------- Backups & Speicherort (Einstellungen) ------------------- */
async function renderBackupCard() {
  const el = $('#cfg-backup');
  if (!el) return;
  const lokal = Boolean(S.lokalModus || window.LOCAL_MODE);
  if (!lokal || !window.RheaStore) { el.innerHTML = '<p class="hint">Automatische Backups mit Wiederherstellung stehen im Lokalmodus (APK) zur Verfügung. Im Servermodus: <code>data/db.json</code> sichern.</p>'; return; }
  let bks = [], os = { moeglich: false };
  try { [bks, os] = await Promise.all([RheaStore.listBackups(), RheaStore.ordnerStatus()]); } catch (_) { /* leer */ }
  const ordnerHtml = os.moeglich
    ? `<div class="row"><span>${os.name ? `📁 Ordner: <strong>${esc(os.name)}</strong> ${os.zugriff ? '<span class="chip green">Zugriff ok</span>' : '<span class="chip amber">Zugriff erneuern</span>'}` : 'Kein Ordner gewählt – Daten bleiben nur im Gerätespeicher der App.'}</span></div>
       <div class="row" style="margin-top:6px"><button class="btn small" id="bk-ordner">Ordner wählen</button>
       ${os.name && !os.zugriff ? '<button class="btn small" id="bk-zugriff">Zugriff erneuern</button>' : ''}
       ${os.name ? '<button class="btn small" id="bk-dok">Alle Dokumente in Ordner sichern</button><button class="btn small danger" id="bk-ordner-weg">Ordner entfernen</button>' : ''}</div>`
    : `<p class="hint">Eine freie Ordnerwahl (z. B. Netzwerkordner) bietet dieses Gerät/diese App nicht. Nutzen Sie stattdessen <strong>Backup teilen/speichern</strong> und wählen Sie im Teilen-Dialog Ihren Netzwerkordner (Dateien-App/NAS). Dokumente lassen sich einzeln über „Teilen/Speichern“ ablegen.</p>`;
  el.innerHTML = `${ordnerHtml}
    <div class="row" style="margin-top:10px"><button class="btn primary" id="bk-jetzt">Backup jetzt anlegen</button><button class="btn" id="bk-teilen">Aktuellen Stand teilen/speichern</button></div>
    <p class="hint">Nach jeder Änderung wird automatisch ein Backup im Gerätespeicher angelegt (die letzten 40 plus ein Stand pro Tag der letzten 60 Tage). Vor jeder Wiederherstellung wird der aktuelle Stand zusätzlich gesichert. Scans (Dokumente) sind nicht Teil der Backup-Dateien.</p>
    <div class="list">${bks.slice(0, 15).map((b) => `<div class="item"><div><strong>${new Date(b.ts).toLocaleString('de-DE')}</strong> <span class="chip ${b.grund === 'automatisch' ? 'gray' : 'blue'}">${esc(b.grund)}</span><div class="muted small">${Math.round(b.size / 1024)} KB</div></div>
      <div class="row"><button class="btn small" data-bk-r="${b.id}">Wiederherstellen</button><button class="btn small" data-bk-t="${b.id}">Teilen</button></div></div>`).join('') || '<div class="muted">Noch keine Backups.</div>'}</div>`;
  const neu = () => renderBackupCard();
  const on = (id, fn) => { const b = el.querySelector(id); if (b) b.onclick = fn; };
  on('#bk-ordner', async () => { try { const n = await RheaStore.waehleOrdner(); toast(`Ordner „${n}“ gewählt.`, 'ok'); neu(); } catch (e) { if (e.name !== 'AbortError') toast(e.message, 'err'); } });
  on('#bk-zugriff', async () => { try { await RheaStore.zugriffErneuern(); } catch (e) { toast(e.message, 'err'); } neu(); });
  on('#bk-ordner-weg', async () => { await RheaStore.ordnerVergessen(); neu(); });
  on('#bk-dok', async () => { const n = await RheaStore.alleDokumenteInOrdner(); toast(`${n} Dokument(e) in den Ordner geschrieben.`, n ? 'ok' : ''); });
  on('#bk-jetzt', async () => { try { const r = await api('GET', '/api/export'); await RheaStore.snapshot(r.json, 'manuell', true); toast('Backup angelegt.', 'ok'); neu(); } catch (e) { toast(e.message, 'err'); } });
  on('#bk-teilen', async () => { try { const r = await api('GET', '/api/export'); await dateiTeilen(r.dateiname || 'rheasport-backup.json', r.json, 'application/json'); } catch (e) { toast(e.message, 'err'); } });
  el.querySelectorAll('[data-bk-t]').forEach((b) => { b.onclick = async () => { const rec = await RheaStore.getBackup(Number(b.dataset.bkT)); if (rec) await dateiTeilen(`rheasport-backup-${rec.ts.slice(0, 19).replace(/[:T]/g, '-')}.json`, rec.json, 'application/json'); }; });
  el.querySelectorAll('[data-bk-r]').forEach((b) => { b.onclick = async () => {
    const rec = await RheaStore.getBackup(Number(b.dataset.bkR));
    if (!rec) return;
    if (!confirm(`Stand vom ${new Date(rec.ts).toLocaleString('de-DE')} wiederherstellen?\nDer aktuelle Stand wird vorher automatisch gesichert.`)) return;
    try {
      const cur = await api('GET', '/api/export');
      const ok = await RheaStore.snapshot(cur.json, 'vor Wiederherstellung', true);
      if (!ok) throw new Error('Sicherung des aktuellen Stands fehlgeschlagen – Wiederherstellung abgebrochen.');
      await api('POST', '/api/import', JSON.parse(rec.json));
      await reload(true); toast('Backup wiederhergestellt.', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  }; });
}

/* ============================== PATIENTENAKTE (alle fertigen Dokumente) ============================== */
const abbruchHtml = (v) => `<style>${PRINT_CSS}</style><div class="pr-page"><h1>Abbruchprotokoll</h1>
  <table class="kopf"><tr><td>Versicherte/r:</td><td><strong>${esc(v.name || '')}</strong></td></tr><tr><td>Maßnahme:</td><td>${esc((S.regeln.arten[v.art] || {}).label || v.art)} · ${fmt(v.von)} – ${fmt(v.bis)}</td></tr>
  <tr><td>Abbruch am:</td><td>${fmt(v.abbruch.datum)}</td></tr><tr><td>Grund:</td><td>${esc(v.abbruch.grund)}</td></tr><tr><td>Erbrachte ÜE:</td><td>${v.erbrachteUee ?? (v.abrechnung && v.abrechnung.uee) ?? '–'} von ${v.uebungseinheiten}</td></tr></table>
  <div class="foot"><div>Ort, Datum</div><div>Unterschrift Anbieter</div></div></div>`;
window.druckeAbbruch = (vid) => { const v = (S.verordnungen || []).find((x) => x.id === vid); if (v && v.abbruch) zeigeDruckansicht(abbruchHtml(v), `Abbruchprotokoll_${RheaStore.sanit(v.name || 'Patient')}.html`); };

/** Alle fertigen Dokumente zu einer Verordnung. */
function fertigeDokumente(v) {
  const liste = [];
  const fertig = ['vollstaendig', 'aktiv', 'abgebrochen', 'abgeschlossen', 'abgerechnet'].includes(v.status);
  if (fertig) liste.push({ art: 'Verordnung', titel: 'Verordnung mit Unterschriften', datum: v.annahmeDatum || v.anmeldungDatum || v.ausstellungsdatum, ok: true, oeffnen: `druckeVerordnung('${v.id}')` });
  if (bpBraucht(v)) liste.push({ art: 'Beratungsprotokoll', titel: 'Beratungsprotokoll', datum: v.beratungsprotokoll && v.beratungsprotokoll.datum, ok: Boolean(v.beratungsprotokoll), oeffnen: `druckeBeratung('${v.id}')`, fehlt: !v.beratungsprotokoll && fertig ? `beratungDialog('${v.id}')` : '' });
  if (v.kostenuebernahme && v.kostenuebernahme.liegtVor) liste.push({ art: 'Genehmigung', titel: `Kostenübernahme${v.kostenuebernahme.kennzeichen ? ' · ' + v.kostenuebernahme.kennzeichen : ''}`, datum: v.kostenuebernahme.datum, ok: true, info: true });
  if (fertig) liste.push({ art: 'Unterschriftenliste', titel: 'Unterschriftenliste', datum: v.von, ok: true, oeffnen: `druckeListe('${v.id}', '${v.kostentraegerArt === 'rv' ? 'drv' : v.kostentraegerArt === 'uv' ? 'dguv' : 'standard'}')` });
  if (v.abrechnung && (v.abrechnung.rechnungsNr || v.status === 'abgerechnet')) liste.push({ art: 'Rechnung', titel: `Rechnung${v.abrechnung.rechnungsNr ? ' ' + v.abrechnung.rechnungsNr : ''}`, datum: v.abrechnung.berechnetAm, ok: true, oeffnen: `druckeRechnung('${v.id}')` });
  if (v.abbruch) liste.push({ art: 'Abbruchprotokoll', titel: 'Abbruchprotokoll', datum: v.abbruch.datum, ok: true, oeffnen: `druckeAbbruch('${v.id}')` });
  return liste;
}
const AKTE = { q: '', art: '', pid: '' };
async function renderAkte(el) {
  const pats = (S.patienten || []).slice().sort((a, b) => patientName(a).localeCompare(patientName(b), 'de'));
  const docs = window.RheaStore ? await RheaStore.listDocs().catch(() => []) : [];
  const arten = ['Verordnung', 'Beratungsprotokoll', 'Genehmigung', 'Unterschriftenliste', 'Rechnung', 'Abbruchprotokoll', 'Scan'];
  el.innerHTML = `<div class="filterbar"><label class="small">Suche<input type="search" id="ak-q" value="${esc(AKTE.q)}" placeholder="Name, Dokument …"></label>
    <label class="small">Dokumentart<select id="ak-art"><option value="">alle</option>${arten.map((a) => `<option ${AKTE.art === a ? 'selected' : ''}>${a}</option>`).join('')}</select></label>
    <label class="small">Status<select id="ak-st"><option value="">alle</option><option value="fehlt" ${AKTE.st === 'fehlt' ? 'selected' : ''}>nur Fehlendes</option></select></label></div><div id="ak-liste"></div>`;
  const zeige = () => {
    const q = AKTE.q.trim().toLowerCase();
    const html = pats.map((p) => {
      const vs = (S.verordnungen || []).filter((v) => v.patientId === p.id);
      const items = [];
      for (const v of vs) for (const d of fertigeDokumente(v)) items.push(Object.assign({ v }, d));
      for (const d of docs.filter((x) => x.patientId === p.id)) items.push({ art: 'Scan', titel: `${d.kategorie} (Scan)`, datum: d.ts.slice(0, 10), ok: true, scan: d, v: null });
      const sicht = items.filter((i) => (!AKTE.art || i.art === AKTE.art) && (AKTE.st !== 'fehlt' || !i.ok) && (!q || `${patientName(p)} ${i.titel} ${i.art}`.toLowerCase().includes(q)));
      if (!sicht.length) return '';
      return `<h2 style="font-size:15px;margin:14px 0 6px">📁 ${pLink(p.id, patientName(p))} <span class="muted small">(${sicht.length})</span></h2><div class="list">${sicht.map((i, n) => `<div class="item"><div><strong>${esc(i.titel)}</strong>
        <div class="muted small">${i.v ? esc((S.regeln.arten[i.v.art] || {}).label || i.v.art) + ' · ' : ''}${i.datum ? fmt(i.datum) : ''}</div></div>
        <div class="row">${i.ok ? '<span class="chip green">fertig</span>' : '<span class="chip amber">fehlt</span>'}
        ${i.oeffnen ? `<button class="btn small" onclick="${i.oeffnen}">${i.ok ? 'Ansehen / Drucken' : 'Leer drucken'}</button>` : ''}
        ${i.fehlt ? `<button class="btn small primary" onclick="${i.fehlt}">✍ Erfassen</button>` : ''}
        ${i.scan ? `<button class="btn small" data-scan="${i.scan.id}">Ansehen</button>` : ''}</div></div>`).join('')}</div>`;
    }).join('');
    $('#ak-liste').innerHTML = html || '<div class="muted">Keine Dokumente gefunden.</div>';
    $$('#ak-liste [data-scan]').forEach((b) => { b.onclick = () => dokOeffnen(docs.find((x) => x.id === b.dataset.scan), () => renderAkte(el)); });
  };
  $('#ak-q').oninput = (e) => { AKTE.q = e.target.value; zeige(); };
  $('#ak-art').onchange = (e) => { AKTE.art = e.target.value; zeige(); };
  $('#ak-st').onchange = (e) => { AKTE.st = e.target.value; zeige(); };
  zeige();
}

/* ============================== GERÄTE & ABGLEICH (Einstellungen) ============================== */
async function renderSyncCard() {
  const el = $('#cfg-sync'); if (!el) return;
  if (!(S.lokalModus || window.LOCAL_MODE)) { el.innerHTML = '<p class="hint">Im Servermodus arbeiten alle Geräte direkt auf derselben Datenbank – ein Abgleich ist nicht nötig.</p>'; return; }
  let info; try { info = await api('GET', '/api/sync/info'); } catch (e) { el.innerHTML = `<div class="errline">${esc(e.message)}</div>`; return; }
  const os = window.RheaStore ? await RheaStore.ordnerStatus().catch(() => ({})) : {};
  el.innerHTML = `<p class="hint"><strong>Mehrere Geräte:</strong> Jedes Gerät speichert seine Daten lokal. Mit einer Abgleichsdatei führen Sie die Änderungen zusammen: Je Datensatz gilt die neuere Änderung; Unterschriften verschiedener Personen im selben Termin bleiben beide erhalten; echte Konflikte werden protokolliert. Empfehlung: ein Hauptgerät (Rezeption), Tablets nach jedem Kurs abgleichen. Einstellungen (z. B. Vergütungssätze, Admin-PIN) gleicht die App mit ab – dort gilt ebenfalls die neuere Änderung. Scans/Fotos werden nicht abgeglichen und bleiben auf dem jeweiligen Gerät.</p>
    <div class="form2"><label>Name dieses Geräts<input id="sy-name" value="${esc(info.geraet.name)}"></label><div style="align-self:end"><button class="btn small" id="sy-name-save">Speichern</button></div></div>
    <div class="row" style="margin-top:8px"><button class="btn primary" id="sy-out">⬇ Abgleichsdatei erzeugen</button>
      <label class="btn" for="sy-in">⬆ Abgleichsdatei einlesen</label><input type="file" id="sy-in" accept=".json,application/json" hidden></div>
    ${os.name && os.zugriff ? `<div class="row" style="margin-top:8px"><button class="btn small" id="sy-ord-out">In Ordner „${esc(os.name)}“ ablegen</button><button class="btn small" id="sy-ord-in">Aus Ordner abgleichen</button></div>` : ''}
    <h3 style="margin:14px 0 4px;font-size:14px">Letzte Abgleiche</h3>
    <div class="list">${(info.log || []).slice(0, 5).map((l) => `<div class="item"><div>${new Date(l.ts).toLocaleString('de-DE')} · von <strong>${esc(l.von)}</strong><div class="muted small">${l.neu} neu · ${l.geaendert} geändert · ${l.geloescht} gelöscht · ${l.konflikte} Konflikt(e)</div></div></div>`).join('') || '<div class="muted small">Noch kein Abgleich durchgeführt.</div>'}</div>
    ${info.konflikte.length ? `<div class="errline" style="margin-top:6px">⚠ ${info.konflikte.length} protokollierte Konflikte – siehe Admin-Bereich → Protokolle.</div>` : ''}`;
  $('#sy-name-save').onclick = async () => { await api('PUT', '/api/sync/geraet', { name: $('#sy-name').value }); toast('Gerätename gespeichert.', 'ok'); renderSyncCard(); };
  $('#sy-out').onclick = async () => { const r = await api('GET', '/api/sync/paket'); await dateiTeilen(r.dateiname, JSON.stringify(r.paket), 'application/json'); };
  $('#sy-in').onchange = async (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) syncVorschau(JSON.parse(await f.text())); };
  const oo = $('#sy-ord-out'); if (oo) oo.onclick = async () => { const r = await api('GET', '/api/sync/paket'); const ok = await RheaStore.schreibeDatei(['Abgleich'], r.dateiname, JSON.stringify(r.paket)); toast(ok ? 'Abgleichsdatei im Ordner abgelegt.' : 'Schreiben in den Ordner fehlgeschlagen.', ok ? 'ok' : 'err'); };
  const oi = $('#sy-ord-in'); if (oi) oi.onclick = async () => { const dateien = await RheaStore.leseDateien(['Abgleich']); const eigene = info.geraet.name.replace(/\W+/g, '_'); const fremd = dateien.filter((d) => !d.name.includes(`-${eigene}-`)).sort((a, b) => a.name.localeCompare(b.name)); if (!fremd.length) { toast('Keine Abgleichsdateien anderer Geräte im Ordner.', ''); return; } const neueste = new Map(); for (const d of fremd) { try { const p = JSON.parse(d.text); neueste.set((p.geraet || {}).id, p); } catch (_) { /* ignorieren */ } } for (const p of neueste.values()) await syncVorschau(p); };
}
async function syncVorschau(paket) {
  try {
    const r = await api('POST', '/api/sync/einlesen', { paket, anwenden: false });
    const e = r.ergebnis;
    await new Promise((fertig) => openModal(`Abgleich mit „${(paket.geraet || {}).name || '?'}“`, `
      <p>Stand vom ${new Date(paket.erzeugt).toLocaleString('de-DE')}.</p><div class="list">
      <div class="item"><div>Neue Datensätze</div><strong>${e.neu}</strong></div><div class="item"><div>Geänderte Datensätze</div><strong>${e.geaendert}</strong></div>
      <div class="item"><div>Gelöscht (dort gelöscht)</div><strong>${e.geloescht}</strong></div><div class="item"><div>Unverändert</div><strong>${e.gleich}</strong></div></div>
      ${e.konflikte.length ? `<h3 style="font-size:14px;margin-top:10px">Konflikte (${e.konflikte.length})</h3>${e.konflikte.slice(0, 8).map((k) => `<div class="errline">⚠ ${esc(k.titel)} – ${esc(k.info)} (${esc(k.gewonnen)})</div>`).join('')}` : ''}
      <p class="hint">Vor dem Übernehmen wird automatisch ein Backup angelegt.</p>`,
    [{ label: 'Abbrechen', cls: 'btn', onClick: () => { closeModal(); fertig(); } },
     { label: 'Übernehmen', cls: 'btn primary', onClick: async () => {
        try {
          if (window.RheaStore) { const cur = await api('GET', '/api/export'); await RheaStore.snapshot(cur.json, 'vor Abgleich', true); }
          await api('POST', '/api/sync/einlesen', { paket, anwenden: true });
          await reload(true); closeModal(); toast('Abgleich durchgeführt.', 'ok'); renderEinstellungen(); fertig();
        } catch (err) { toast(err.message, 'err'); }
     } }]));
  } catch (e) { toast(e.message, 'err'); }
}

/* ============================== ADMIN (Logo 5× antippen) ============================== */
let ADMIN_PIN = null, ADMIN_TAB = 'ueber', ADMIN_ZEIT = 0, LOGO_KLICKS = [];
const adminApi = (m, pfad, body) => (m === 'GET' ? api('GET', `${pfad}${pfad.includes('?') ? '&' : '?'}pin=${encodeURIComponent(ADMIN_PIN)}`) : api(m, pfad, Object.assign({ pin: ADMIN_PIN }, body || {})));
(() => {
  const logo = document.querySelector('.brand .logo');
  if (logo) logo.addEventListener('click', () => { const t = Date.now(); LOGO_KLICKS = LOGO_KLICKS.filter((x) => t - x < 2500).concat(t); if (LOGO_KLICKS.length >= 5) { LOGO_KLICKS = []; adminOeffnen(); } });
})();
async function adminOeffnen() {
  if (ADMIN_PIN && Date.now() - ADMIN_ZEIT < 10 * 60000) { ADMIN_ZEIT = Date.now(); zeigeView('admin'); return; }
  ADMIN_PIN = null;
  let st; try { st = await api('GET', '/api/admin/status'); } catch (e) { toast(e.message, 'err'); return; }
  if (!st.pinGesetzt) {
    openModal('Admin-Bereich einrichten', `<p class="hint">Der versteckte Admin-Bereich ist durch eine PIN geschützt. Bitte jetzt eine PIN (4–12 Ziffern) festlegen und sicher aufbewahren.</p>
      <div class="form2"><label>Neue PIN<input type="password" inputmode="numeric" id="ad-p1" autocomplete="off"></label><label>PIN wiederholen<input type="password" inputmode="numeric" id="ad-p2" autocomplete="off"></label></div>`,
    [{ label: 'Abbrechen', cls: 'btn', onClick: closeModal },
     { label: 'PIN festlegen', cls: 'btn primary', onClick: async () => {
        if ($('#ad-p1').value !== $('#ad-p2').value) { toast('Die PINs stimmen nicht überein.', 'err'); return; }
        try { await api('POST', '/api/admin/pin', { pin: $('#ad-p1').value }); ADMIN_PIN = $('#ad-p1').value; ADMIN_ZEIT = Date.now(); closeModal(); zeigeView('admin'); } catch (e) { toast(e.message, 'err'); }
     } }]);
    return;
  }
  openModal('Admin-Bereich', '<label>Admin-PIN<input type="password" inputmode="numeric" id="ad-pin" autocomplete="off" autofocus></label>',
    [{ label: 'Abbrechen', cls: 'btn', onClick: closeModal },
     { label: 'Öffnen', cls: 'btn primary', onClick: async () => {
        try { await api('POST', '/api/admin/login', { pin: $('#ad-pin').value }); ADMIN_PIN = $('#ad-pin').value; ADMIN_ZEIT = Date.now(); closeModal(); zeigeView('admin'); } catch (e) { toast(e.message, 'err'); }
     } }]);
  setTimeout(() => { const i = $('#ad-pin'); if (i) { i.focus(); i.onkeydown = (ev) => { if (ev.key === 'Enter') $('#modal-foot button.primary').click(); }; } }, 50);
}
const ADMIN_TABS = [['ueber', 'Übersicht'], ['verord', 'Verordnungen ändern'], ['sammel', 'Sammeländerung'], ['prot', 'Protokolle'], ['sicher', 'Sicherheit']];
async function renderAdmin() {
  const root = $('#view-admin');
  if (!ADMIN_PIN) { zeigeView('dashboard'); return; }
  root.innerHTML = `<div class="row" style="justify-content:space-between"><h1>🔧 Admin</h1><button class="btn" id="ad-zu">Admin verlassen</button></div>
    <div class="ptabs">${ADMIN_TABS.map(([k, l]) => `<button class="ptab ${ADMIN_TAB === k ? 'active' : ''}" data-at="${k}">${l}</button>`).join('')}</div><div id="ad-body"></div>`;
  $('#ad-zu').onclick = () => { ADMIN_PIN = null; zeigeView('dashboard'); };
  $$('#view-admin .ptab').forEach((b) => { b.onclick = () => { ADMIN_TAB = b.dataset.at; renderAdmin(); }; });
  const body = $('#ad-body');
  try {
    if (ADMIN_TAB === 'ueber') await adminUeber(body);
    else if (ADMIN_TAB === 'verord') adminVerordnungen(body);
    else if (ADMIN_TAB === 'sammel') adminSammel(body);
    else if (ADMIN_TAB === 'prot') await adminProtokolle(body);
    else adminSicherheit(body);
  } catch (e) { body.innerHTML = `<div class="errline">${esc(e.message)}</div>`; if (/PIN/.test(e.message)) ADMIN_PIN = null; }
}
async function adminUeber(el) {
  const i = await adminApi('GET', '/api/admin/info');
  const kb = (n) => (n == null ? '–' : `${Math.round(n / 1024).toLocaleString('de-DE')} KB`);
  el.innerHTML = `<div class="statgrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px">${Object.entries(i.zahlen).map(([k, v]) => `<div class="card" style="padding:10px"><div class="muted small">${esc({ trainer: 'Trainer', patienten: 'Patienten', verordnungen: 'Verordnungen', kurse: 'Gruppen', termine: 'Termine', zuordnungen: 'Zuordnungen', outbox: 'E-Mails', audit: 'Audit-Einträge', aenderungen: 'Admin-Änderungen', syncKonflikte: 'Abgleich-Konflikte' }[k] || k)}</div><div style="font-size:22px;font-weight:700">${v}</div></div>`).join('')}
    <div class="card" style="padding:10px"><div class="muted small">Digitale Unterschriften</div><div style="font-size:22px;font-weight:700">${i.unterschriften}</div></div></div>
    <div class="card" style="margin-top:10px"><h2 style="font-size:15px">System</h2><div class="muted small">Gerät: <strong>${esc(i.geraet.name)}</strong> (${esc(i.geraet.id)}) · Version ${esc(i.version)}<br>Datenbank: ${kb(i.dbBytes)} · lokaler Speicher gesamt: ${kb(i.speicher)} (Grenze der App ca. 5.000 KB)<br>Letzte Abgleiche: ${(i.syncLog || []).slice(0, 3).map((l) => `${new Date(l.ts).toLocaleDateString('de-DE')} ${esc(l.von)}`).join(' · ') || 'keine'}</div></div>
    <div class="card" style="margin-top:10px"><h2 style="font-size:15px">Integritätsprüfung (${i.integritaet.length} Hinweise)</h2>
      ${i.integritaet.map((p) => `<div class="${p.schwere === 'hoch' ? 'errline' : 'muted small'}">${p.schwere === 'hoch' ? '⛔' : '⚠'} ${esc(p.text)}</div>`).join('') || '<div class="muted">✔ Keine Auffälligkeiten.</div>'}</div>`;
}
const AD_FELDER = [
  ['annahmeDatum', 'Annahme der Verordnung (Eingang)', 'date'], ['ausstellungsdatum', 'Ausstellungsdatum', 'date'], ['von', 'Beginn der Maßnahme', 'date'], ['bis', 'Ende der Maßnahme', 'date'],
  ['uebungseinheiten', 'Übungseinheiten (Anzahl)', 'text'], ['frequenzProWoche', 'Frequenz pro Woche', 'text'], ['status', 'Status', 'status'], ['art', 'Maßnahme', 'art'],
  ['kostentraeger', 'Kostenträger', 'text'], ['kostentraegerArt', 'Kostenträger-Art', 'kt'], ['ik', 'IK des Kostenträgers', 'text'], ['versichertenNr', 'Versichertennummer', 'text'],
  ['arztName', 'Verordnende/r Ärztin/Arzt', 'text'], ['angelegtVon', 'Angelegt von', 'text'],
  ['kostenuebernahme.datum', 'Genehmigungsdatum', 'date'], ['kostenuebernahme.kennzeichen', 'Genehmigungskennzeichen', 'text'], ['kostenuebernahme.gueltigBis', 'Genehmigung gültig bis', 'date'],
];
const AD_STATUS = ['abgleich', 'vollstaendig', 'aktiv', 'abgebrochen', 'abgeschlossen', 'abgerechnet'];
const adLesen = (o, p) => p.split('.').reduce((x, k) => (x == null ? x : x[k]), o);
function adminVerordnungen(el) {
  const pats = (S.patienten || []).slice().sort((a, b) => patientName(a).localeCompare(patientName(b), 'de'));
  el.innerHTML = `<div class="filterbar"><label class="small">Suche<input id="av-q" type="search" placeholder="Name, Versichertennr. …"></label></div><div id="av-liste"></div>`;
  const zeige = () => {
    const q = ($('#av-q').value || '').toLowerCase();
    $('#av-liste').innerHTML = pats.map((p) => {
      const vs = (S.verordnungen || []).filter((v) => v.patientId === p.id);
      if (q && !`${patientName(p)} ${vs.map((v) => v.versichertenNr).join(' ')}`.toLowerCase().includes(q)) return '';
      return `<div class="card" style="margin-bottom:8px"><div class="row" style="justify-content:space-between"><strong>${esc(patientName(p))}</strong><button class="btn small" data-p="${p.id}">Stammdaten ändern</button></div>
        ${vs.map((v) => `<div class="item"><div>${esc((S.regeln.arten[v.art] || {}).label || v.art)} ${statusChip(v.status)}<div class="muted small">Angenommen ${fmt(v.annahmeDatum || v.anmeldungDatum)} · Beginn ${fmt(v.von)} · Ende ${fmt(v.bis)}</div></div><button class="btn small primary" data-v="${v.id}">Ändern</button></div>`).join('')}</div>`;
    }).join('') || '<div class="muted">Keine Treffer.</div>';
    $$('#av-liste [data-v]').forEach((b) => { b.onclick = () => adminVerordnungForm(S.verordnungen.find((x) => x.id === b.dataset.v)); });
    $$('#av-liste [data-p]').forEach((b) => { b.onclick = () => adminPatientForm(S.patienten.find((x) => x.id === b.dataset.p)); });
  };
  $('#av-q').oninput = zeige; zeige();
}
function adminVerordnungForm(v) {
  const feld = ([k, l, t]) => {
    const w = adLesen(v, k) ?? (k === 'annahmeDatum' ? (v.anmeldungDatum || '') : '');
    const input = t === 'status' ? `<select data-k="${k}">${AD_STATUS.map((s) => `<option ${s === w ? 'selected' : ''}>${s}</option>`).join('')}</select>`
      : t === 'art' ? `<select data-k="${k}">${artOptionen(w)}</select>` : t === 'kt' ? `<select data-k="${k}">${['gkv', 'rv', 'uv', 'sonstige'].map((s) => `<option ${s === (w || 'gkv') ? 'selected' : ''}>${s}</option>`).join('')}</select>`
      : `<input data-k="${k}" type="${t}" value="${esc(String(w))}">`;
    return `<label>${l}${input}</label>`;
  };
  openModal(`Verordnung ändern – ${v.name || ''}`, `<p class="hint">Änderungen werden mit altem/neuem Wert, Grund, Zeit und Gerät im Änderungsprotokoll festgehalten. Regelprüfungen der App werden hier bewusst nicht erzwungen.</p>
    <div class="form2">${AD_FELDER.map(feld).join('')}</div><label>Grund der Änderung (Pflicht)<input id="ad-grund" placeholder="z. B. Datum bei Erfassung vertauscht"></label>`,
  [{ label: 'Abbrechen', cls: 'btn', onClick: closeModal },
   { label: 'Speichern', cls: 'btn primary', onClick: async () => {
      const aend = {};
      $$('#modal-body [data-k]').forEach((el) => { const alt = String(adLesen(v, el.dataset.k) ?? (el.dataset.k === 'annahmeDatum' ? (v.anmeldungDatum || '') : '')); const sollte = el.dataset.k === 'kostentraegerArt' && !alt ? 'gkv' : alt; if (el.value !== sollte) aend[el.dataset.k] = el.value; });
      if (!Object.keys(aend).length) { toast('Keine Änderung.', ''); return; }
      try { const r = await adminApi('PUT', `/api/admin/verordnung/${v.id}`, { aenderungen: aend, grund: $('#ad-grund').value }); await reload(false); closeModal(); toast(`${r.geaendert} Feld(er) geändert und protokolliert.`, 'ok'); renderAdmin(); } catch (e) { toast(e.message, 'err'); }
   } }], { wide: true });
}
function adminPatientForm(p) {
  openModal(`Stammdaten ändern – ${patientName(p)}`, `<div class="form2">${[['vorname', 'Vorname', 'text'], ['nachname', 'Nachname', 'text'], ['geburtsdatum', 'Geburtsdatum', 'date'], ['email', 'E-Mail', 'text'], ['telefon', 'Telefon', 'text']].map(([k, l, t]) => `<label>${l}<input data-k="${k}" type="${t}" value="${esc(p[k] || '')}"></label>`).join('')}</div>
    <label>Grund der Änderung (Pflicht)<input id="ad-grund"></label>`,
  [{ label: 'Abbrechen', cls: 'btn', onClick: closeModal },
   { label: 'Speichern', cls: 'btn primary', onClick: async () => {
      const aend = {}; $$('#modal-body [data-k]').forEach((el) => { if (el.value !== String(p[el.dataset.k] || '')) aend[el.dataset.k] = el.value; });
      if (!Object.keys(aend).length) { toast('Keine Änderung.', ''); return; }
      try { await adminApi('PUT', `/api/admin/patient/${p.id}`, { aenderungen: aend, grund: $('#ad-grund').value }); await reload(false); closeModal(); toast('Geändert und protokolliert.', 'ok'); renderAdmin(); } catch (e) { toast(e.message, 'err'); }
   } }]);
}
function adminSammel(el) {
  const vs = (S.verordnungen || []).filter((v) => v.status !== 'abgleich');
  const sel = new Set();
  el.innerHTML = `<p class="hint">Mehrere Verordnungen auswählen und ein Feld gemeinsam setzen oder ein Datum um Tage verschieben. Jede Änderung wird einzeln protokolliert.</p>
    <div class="filterbar"><label class="small">Suche<input id="as-q" type="search"></label>
      <label class="small">Feld<select id="as-feld">${AD_FELDER.map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select></label>
      <label class="small">Neuer Wert<input id="as-wert"></label><label class="small">oder um … Tage verschieben<input id="as-tage" inputmode="numeric" placeholder="z. B. 7 oder -3"></label>
      <label class="small">Grund (Pflicht)<input id="as-grund"></label></div>
    <div class="row"><button class="btn small" id="as-alle">Alle sichtbaren</button><button class="btn small primary" id="as-go">Auf Auswahl anwenden</button><span class="muted small" id="as-z"></span></div><div id="as-liste" class="list" style="margin-top:8px"></div>`;
  const zeige = () => {
    const q = $('#as-q').value.toLowerCase();
    const sicht = vs.filter((v) => !q || `${v.name} ${v.kostentraeger} ${v.status}`.toLowerCase().includes(q));
    $('#as-liste').innerHTML = sicht.map((v) => `<label class="item check"><input type="checkbox" data-id="${v.id}" ${sel.has(v.id) ? 'checked' : ''}> <span><strong>${esc(v.name || '')}</strong> ${statusChip(v.status)}<span class="muted small"> · ${esc((S.regeln.arten[v.art] || {}).label || v.art)} · Beginn ${fmt(v.von)} · Ende ${fmt(v.bis)}</span></span></label>`).join('') || '<div class="muted">Keine Treffer.</div>';
    $$('#as-liste [data-id]').forEach((c) => { c.onchange = () => { if (c.checked) sel.add(c.dataset.id); else sel.delete(c.dataset.id); $('#as-z').textContent = `${sel.size} ausgewählt`; }; });
    $('#as-alle').onclick = () => { sicht.forEach((v) => sel.add(v.id)); zeige(); $('#as-z').textContent = `${sel.size} ausgewählt`; };
  };
  $('#as-q').oninput = zeige; zeige();
  $('#as-go').onclick = async () => {
    if (!sel.size) { toast('Bitte Verordnungen auswählen.', 'err'); return; }
    const body = { ids: [...sel], feld: $('#as-feld').value, grund: $('#as-grund').value };
    if ($('#as-tage').value.trim()) body.verschiebeTage = Number($('#as-tage').value); else body.wert = $('#as-wert').value;
    if (!confirm(`${sel.size} Verordnung(en) ändern?`)) return;
    try { const r = await adminApi('POST', '/api/admin/bulk', body); await reload(false); toast(`${r.geaendert} Änderung(en) durchgeführt und protokolliert.`, 'ok'); renderAdmin(); } catch (e) { toast(e.message, 'err'); }
  };
}
async function adminProtokolle(el) {
  const pr = await adminApi('GET', '/api/admin/protokoll');
  const T = renderAdmin.t = renderAdmin.t || 'aend';
  const tabs = [['aend', `Änderungen (${pr.aenderungen.length})`], ['audit', `Audit (${pr.audit.length})`], ['konf', `Abgleich-Konflikte (${pr.konflikte.length})`]];
  el.innerHTML = `<div class="ptabs">${tabs.map(([k, l]) => `<button class="ptab ${T === k ? 'active' : ''}" data-pt2="${k}">${l}</button>`).join('')}</div>
    <div class="filterbar"><label class="small">Suche<input id="ap-q" type="search"></label><button class="btn small" id="ap-csv">⬇ CSV</button><span class="muted small" id="ap-z"></span></div><div id="ap-liste" class="list"></div>`;
  $$('[data-pt2]', el).forEach((b) => { b.onclick = () => { renderAdmin.t = b.dataset.pt2; adminProtokolle(el); }; });
  const zeilen = () => (T === 'aend' ? pr.aenderungen.map((a) => ({ ts: a.ts, text: `${a.typ === 'patient' ? 'Patient' : 'Verordnung'} ${a.bezug}`, detail: `${a.felder.map((f) => `${f.feld}: „${f.alt}“ → „${f.neu}“`).join('; ')} · Grund: ${a.grund} · ${a.geraet}` }))
    : T === 'audit' ? pr.audit.map((a) => ({ ts: a.ts, text: a.ereignis, detail: `${a.aktor || ''}${a.geraet ? ' · ' + a.geraet : ''} · ${JSON.stringify(a.details || {}).slice(0, 220)}` }))
    : pr.konflikte.map((k) => ({ ts: k.ts, text: `${k.titel} (${k.coll})`, detail: `${k.info} · gewonnen: ${k.gewonnen} · von ${k.von || '?'}` })));
  const zeige = () => {
    const q = $('#ap-q').value.toLowerCase();
    const z = zeilen().filter((r) => !q || `${r.text} ${r.detail}`.toLowerCase().includes(q));
    $('#ap-z').textContent = `${z.length} Einträge`;
    $('#ap-liste').innerHTML = z.slice(0, 300).map((r) => `<div class="item"><div><strong>${esc(r.text)}</strong><div class="muted small">${esc(r.detail)}</div></div><span class="muted small">${new Date(r.ts).toLocaleString('de-DE')}</span></div>`).join('') || '<div class="muted">Keine Einträge.</div>';
  };
  $('#ap-q').oninput = zeige;
  $('#ap-csv').onclick = () => { const q = (x) => `"${String(x).replace(/"/g, '""')}"`; dateiTeilen(`protokoll_${T}.csv`, '\ufeff' + ['Zeit;Eintrag;Details', ...zeilen().map((r) => [r.ts, r.text, r.detail].map(q).join(';'))].join('\r\n'), 'text/csv'); };
  zeige();
}
function adminSicherheit(el) {
  el.innerHTML = `<div class="card"><h2 style="font-size:15px">Admin-PIN ändern</h2><div class="form2"><label>Aktuelle PIN<input type="password" inputmode="numeric" id="as-alt"></label><label>Neue PIN<input type="password" inputmode="numeric" id="as-neu"></label></div><button class="btn primary" id="as-save">PIN ändern</button></div>
    <p class="hint">Der Admin-Bereich öffnet sich durch 5× schnelles Antippen des Logos. Nach 10 Minuten ohne Aktivität ist die PIN erneut nötig. Anmeldungen und Änderungen stehen im Audit-/Änderungsprotokoll.</p>`;
  $('#as-save').onclick = async () => { try { await api('POST', '/api/admin/pin', { alt: $('#as-alt').value, pin: $('#as-neu').value }); ADMIN_PIN = $('#as-neu').value; toast('PIN geändert.', 'ok'); } catch (e) { toast(e.message, 'err'); } };
}

/* ============================== ABRECHNUNG ============================== */
let ABR_MONAT = heutigesISO().slice(0, 7);
function verschiebeMonat(m, delta) {
  const [j, mo] = m.split('-').map(Number);
  const d = new Date(j, mo - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}
async function renderStatistik() {
  const st = await api('GET', `/api/statistik?monat=${ABR_MONAT}`);
  const g = st.gesamt;
  const [j, mo] = st.monat.split('-').map(Number);
  const titel = new Date(j, mo - 1, 1).toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });
  $('#abr-stat').innerHTML = `<div class="card">
    <div class="row between"><h2 style="margin:0">Statistik ${esc(titel)}</h2>
      <div class="row"><button class="btn small" id="st-prev">‹</button><button class="btn small" id="st-heute">Heute</button><button class="btn small" id="st-next">›</button></div></div>
    <div class="stats" style="margin-top:8px">
      <div class="stat"><div class="n">${g.termine}</div><div class="t">Einheiten durchgeführt</div></div>
      <div class="stat"><div class="n">${g.geplantTermine}</div><div class="t">noch geplant</div></div>
      <div class="stat"><div class="n">${g.teilnahmen}</div><div class="t">Teilnahmen</div></div>
      <div class="stat"><div class="n">${g.ausgefallen}</div><div class="t">ausgefallen</div></div>
      <div class="stat"><div class="n">${g.abbrueche}</div><div class="t">Abbrüche</div></div>
    </div>
    <div class="table-wrap"><table><thead><tr><th>Trainer/in</th><th>Stundenlohn €/Std.</th><th>Std. bisher</th><th>Verdienst bisher</th><th>Std. geplant</th><th>Voraussichtlich</th></tr></thead><tbody>
      ${st.trainer.map((t) => `<tr><td><strong>${tLink(t.id, t.name)}</strong>${t.unbestaetigt ? `<div class="muted small">${t.unbestaetigt} vergangene Termine noch unbestätigt</div>` : ''}</td>
        <td><input type="number" step="0.01" min="0" class="tr-lohn" data-tid="${t.id}" value="${t.stundenlohn || ''}" style="width:90px"></td>
        <td>${t.stunden.toString().replace('.', ',')} <span class="muted small">(${t.termine} Termine)</span></td><td>${euroFmt(t.verdienst)}</td>
        <td>${t.geplantStunden.toString().replace('.', ',')}</td><td><strong>${euroFmt(t.prognose)}</strong></td></tr>`).join('') || '<tr><td colspan="6" class="muted">Keine Trainer/innen.</td></tr>'}
    </tbody></table></div>
    <div class="grid2" style="margin-top:8px">
      <div class="item"><span class="muted">Trainerkosten bisher / voraussichtlich</span><strong>${euroFmt(g.trainerkosten)} / ${euroFmt(g.trainerkostenPrognose)}</strong></div>
      <div class="item"><span class="muted">Einnahmen bisher / voraussichtlich*</span><strong>${euroFmt(g.einnahmen)} / ${euroFmt(g.einnahmenPrognose)}</strong></div>
    </div>
    <div class="item"><span class="muted">Voraussichtliches Ergebnis (Einnahmen − Trainerkosten)</span><strong>${euroFmt(g.ergebnisPrognose)}</strong></div>
    <p class="muted small">*Einnahmen = Vergütungssatz × Teilnahmen (Satz je Verordnung bzw. aus den Einstellungen). Voraussichtlich enthält alle noch geplanten Termine mit zugeordneten Teilnehmern.</p>
  </div>`;
  $('#st-prev').onclick = () => { ABR_MONAT = verschiebeMonat(ABR_MONAT, -1); renderStatistik(); };
  $('#st-next').onclick = () => { ABR_MONAT = verschiebeMonat(ABR_MONAT, 1); renderStatistik(); };
  $('#st-heute').onclick = () => { ABR_MONAT = heutigesISO().slice(0, 7); renderStatistik(); };
  $$('.tr-lohn').forEach((inp) => {
    inp.onchange = async () => {
      try { await api('PUT', `/api/trainer/${inp.dataset.tid}`, { stundenlohn: inp.value }); await reload(false); await renderStatistik(); toast('Stundenlohn gespeichert.', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
    };
  });
}

/* ------------------------------ Abrechnung / Rechnungen / Offene Posten ------------------------------ */
let ABR_ZEILEN = [];
const abrStatusChip = (z) => {
  if (z.status === 'abgerechnet') return z.offen ? (z.ueberfaellig ? '<span class="chip red">überfällig</span>' : '<span class="chip amber">offen</span>') : '<span class="chip green">bezahlt</span>';
  if (z.status === 'abgebrochen') return '<span class="chip red">abgebrochen</span>';
  return z.fertig ? '<span class="chip blue">bereit</span>' : '<span class="chip gray">läuft</span>';
};
function abrGefiltert() {
  const filter = $('#abr-filter').value, sort = $('#abr-sort').value, art = $('#abr-art').value, such = ($('#abr-suche').value || '').toLowerCase();
  return ABR_ZEILEN.filter((z) => {
    if (art && z.kostentraegerArt !== art) return false;
    if (such && !`${z.patient} ${z.abrechnung ? z.abrechnung.rechnungsNr : ''} ${z.kostentraeger}`.toLowerCase().includes(such)) return false;
    if (!filter) return true;
    if (filter === 'offen') return z.offen;
    if (filter === 'ueberfaellig') return z.ueberfaellig;
    if (filter === 'bezahlt') return z.status === 'abgerechnet' && !z.offen;
    if (filter === 'bereit') return z.fertig && z.status !== 'abgerechnet' && z.erbrachteUee > 0;
    if (filter === 'laeuft') return !z.fertig;
    return z.status === filter;
  }).sort({
    name: (x, y) => x.patient.localeCompare(y.patient, 'de'),
    betrag: (x, y) => (y.betrag || 0) - (x.betrag || 0),
    status: (x, y) => x.status.localeCompare(y.status),
    ende: (x, y) => String(x.bis || '').localeCompare(String(y.bis || '')),
    faellig: (x, y) => String(x.faelligAm || '9999').localeCompare(String(y.faelligAm || '9999')),
  }[sort] || (() => 0));
}
async function renderAbrechnung() {
  renderStatistik().catch((e) => toast(e.message, 'err'));
  const r = await api('GET', '/api/abrechnung');
  ABR_ZEILEN = r.zeilen;
  const summe = (arr, f) => arr.reduce((a, z) => a + (f(z) || 0), 0);
  const offen = ABR_ZEILEN.filter((z) => z.offen), ueber = ABR_ZEILEN.filter((z) => z.ueberfaellig);
  const bezahlt = ABR_ZEILEN.filter((z) => z.status === 'abgerechnet' && !z.offen);
  const bereit = ABR_ZEILEN.filter((z) => z.fertig && z.status !== 'abgerechnet' && z.erbrachteUee > 0);
  const kachel = (n, t, sub, cls, f) => `<div class="stat" data-f="${f}" style="cursor:pointer"><div class="n ${cls}">${n}</div><div class="t">${t}</div><div class="muted small">${sub}</div></div>`;
  $('#abr-summary').innerHTML =
    kachel(euroFmt(summe(offen, (z) => z.betrag)), 'Offene Posten', `${offen.length} Rechnung(en)`, offen.length ? 'amber' : '', 'offen') +
    kachel(euroFmt(summe(ueber, (z) => z.betrag)), 'davon überfällig', `${ueber.length} Rechnung(en)`, ueber.length ? 'red' : '', 'ueberfaellig') +
    kachel(euroFmt(summe(bezahlt, (z) => z.bezahltBetrag || z.betrag)), 'Bezahlt', `${bezahlt.length} Rechnung(en)`, '', 'bezahlt') +
    kachel(euroFmt(summe(bereit, (z) => z.betrag)), 'Bereit zur Abrechnung', `${bereit.length} Verordnung(en)`, bereit.length ? 'amber' : '', 'bereit');
  $$('#abr-summary .stat').forEach((el) => { el.onclick = () => { $('#abr-filter').value = el.dataset.f; renderAbrechnungTabelle(); }; });
  renderAbrechnungTabelle();
}
function renderAbrechnungTabelle() {
  const zeilen = abrGefiltert();
  const rows = zeilen.map((z) => {
    const ab = z.abrechnung || {};
    const rechnung = ab.rechnungsNr
      ? `<div><strong>${esc(ab.rechnungsNr)}</strong>${z.status !== 'abgerechnet' ? ' <span class="chip gray">Entwurf</span>' : ''}</div>
         ${z.status === 'abgerechnet' ? `<div class="muted small">${fmt(z.rechnungsdatum)} · fällig ${z.ueberfaellig ? `<span style="color:var(--red)"><strong>${fmt(z.faelligAm)}</strong></span>` : fmt(z.faelligAm)}</div>` : ''}
         ${z.bezahltAm ? `<div class="muted small">bezahlt ${fmt(z.bezahltAm)}: ${euroFmt(z.bezahltBetrag)}</div>` : ''}` : '<span class="muted">–</span>';
    return `<tr class="${z.fertig ? '' : 'muted'}">
    <td><strong>${pLink(z.patientId, z.patient)}</strong>${z.letzterTermin ? `<div class="muted small">letzter Termin ${fmt(z.letzterTermin)}</div>` : ''}</td>
    <td>${esc(z.kostentraeger || '–')} <span class="chip gray">${esc(z.kostentraegerArt)}</span>${z.trainerId ? `<div class="small">${tLink(z.trainerId, trainerName(z.trainerId))}</div>` : ''}</td>
    <td>${esc(z.artLabel)}<div class="muted small">${fmt(z.von)} – ${fmt(z.bis)}</div>${z.abbruch ? `<div class="errline">Abbruch ${fmt(z.abbruch.datum)}: ${esc(z.abbruch.grund)}</div>` : ''}${z.hinweis ? `<div class="muted small">${esc(z.hinweis)}</div>` : ''}</td>
    <td><strong>${z.erbrachteUee}</strong> / ${z.geplanteUee}</td>
    <td><input type="number" step="0.01" min="0" value="${z.satz || ''}" data-vid="${z.id}" class="abr-satz" style="width:80px" ${z.status === 'abgerechnet' ? 'disabled' : ''}></td>
    <td>${z.betrag != null ? `<strong>${euroFmt(z.betrag)}</strong>` : '–'}</td>
    <td>${abrStatusChip(z)}${rechnung}</td>
    <td class="acts-col"><div class="row" style="flex-wrap:wrap;gap:4px">
      <button class="btn small" ${z.erbrachteUee > 0 ? '' : 'disabled'} onclick="druckeRechnung('${z.id}')">🖨 Rechnung</button>
      ${z.status === 'abgerechnet' ? '' : `<button class="btn small ${z.fertig ? 'primary' : ''}" ${z.erbrachteUee > 0 ? '' : 'disabled'} onclick="setzeAbrechnung('${z.id}', true)">Als abgerechnet</button>`}
      ${z.offen ? `<button class="btn small primary" onclick="bezahltMarkieren('${z.id}')">💶 Bezahlt</button>` : ''}
      ${z.status === 'abgerechnet' && !z.offen ? `<button class="btn small" onclick="zahlungZurueck('${z.id}')">↩ Zahlung zurücknehmen</button>` : ''}
    </div></td>
  </tr>`;
  }).join('');
  $('#abr-tabelle tbody').innerHTML = rows || '<tr><td colspan="8" class="muted">Keine Verordnungen für diesen Filter.</td></tr>';
  const sum = zeilen.reduce((a, z) => a + (z.betrag || 0), 0);
  $('#abr-summe').textContent = `${zeilen.length} Einträge · Summe ${euroFmt(sum)}`;
  $$('.abr-satz').forEach((inp) => {
    inp.onchange = async () => {
      try { await api('POST', `/api/verordnungen/${inp.dataset.vid}/abrechnung`, { satz: inp.value, satzQuelle: 'manuell (RSD-Vergütungssätze)' }); await renderAbrechnung(); toast('Vergütungssatz gespeichert.', 'ok'); } catch (e) { toast(e.message, 'err'); }
    };
  });
}
['#abr-filter', '#abr-sort', '#abr-art'].forEach((id) => $(id).addEventListener('change', renderAbrechnungTabelle));
$('#abr-suche').addEventListener('input', renderAbrechnungTabelle);

window.setzeAbrechnung = async (vid) => {
  const v = (S.verordnungen || []).find((x) => x.id === vid);
  const satz = ($(`.abr-satz[data-vid="${vid}"]`) || {}).value || (v && v.abrechnung && v.abrechnung.satz) || '';
  const nr = prompt('Rechnungsnummer (leer = automatisch vergeben):', (v && v.abrechnung && v.abrechnung.rechnungsNr) || '');
  if (nr === null) return;
  try {
    await api('POST', `/api/verordnungen/${vid}/abrechnung`, { satz, satzQuelle: 'manuell (RSD-Vergütungssätze)', rechnungsNr: nr, abrechnen: true });
    await reload(true); renderAbrechnung();
    toast('Als abgerechnet markiert – jetzt als offener Posten geführt.', 'ok');
  } catch (e) { toast(e.message, 'err'); }
};
window.bezahltMarkieren = (vid) => {
  const z = ABR_ZEILEN.find((x) => x.id === vid);
  if (!z) return;
  openModal(`Zahlungseingang – ${z.patient}`, `<div class="form2">
      <label>Eingegangen am<input type="date" id="bz-datum" value="${heutigesISO()}"></label>
      <label>Betrag (€)<input type="number" step="0.01" id="bz-betrag" value="${z.betrag != null ? z.betrag : ''}"></label></div>
      <p class="hint">Rechnung ${esc((z.abrechnung || {}).rechnungsNr || '')} · Soll ${z.betrag != null ? euroFmt(z.betrag) : '–'}. Bei Teilzahlung/Kürzung den tatsächlichen Betrag eintragen.</p>`,
    [{ label: 'Abbrechen', cls: 'btn', onClick: closeModal },
     { label: 'Als bezahlt markieren', cls: 'btn primary', onClick: async () => {
       try { await api('POST', `/api/verordnungen/${vid}/bezahlt`, { datum: $('#bz-datum').value, betrag: $('#bz-betrag').value }); closeModal(); await reload(true); await renderAbrechnung(); toast('Zahlungseingang erfasst.', 'ok'); }
       catch (e) { toast(e.message, 'err'); } } }]);
};
window.zahlungZurueck = async (vid) => {
  if (!confirm('Zahlungseingang zurücknehmen? Die Rechnung gilt wieder als offener Posten.')) return;
  try { await api('POST', `/api/verordnungen/${vid}/bezahlt`, { rueckgaengig: true }); await reload(true); await renderAbrechnung(); }
  catch (e) { toast(e.message, 'err'); }
};

/* ---- Rechnungsvorlagen je Kostenträger ---- */
const RECHNUNG_VORLAGEN = {
  gkv: { label: 'Krankenkasse (GKV, Muster 56)', betreff: 'Rechnung Rehabilitationssport / Funktionstraining (§ 43 SGB V i. V. m. § 64 SGB IX)', ref: [['Versichertennummer', (v) => v.versichertenNr], ['Verordnung', () => 'Muster 56 (Rehabilitationssport/Funktionstraining)']], hinweis: 'Abrechnung nach Rahmenvereinbarung und Vergütungsvereinbarung. Verordnung und Kostenübernahme liegen vor.' },
  rv: { label: 'Rentenversicherung (DRV, G0850)', betreff: 'Rechnung Rehabilitationssport (Deutsche Rentenversicherung)', ref: [['Versicherungsnummer', (v) => v.versichertenNr], ['Aktenzeichen / Bewilligung', () => '____________________'], ['Verordnung', () => 'G0850 / G0851']], hinweis: 'Leistung im Rahmen der Bewilligung des Rentenversicherungsträgers; Teilnahmenachweis siehe Anlage.' },
  uv: { label: 'Unfallversicherung (DGUV)', betreff: 'Rechnung Rehabilitationssport (gesetzliche Unfallversicherung, DGUV)', ref: [['Aktenzeichen / Schadensnummer', () => '____________________'], ['Unfalltag', () => '____________________'], ['Verordnung', () => 'DGUV-Verordnung']], hinweis: 'Leistung auf Grundlage der Verordnung des Unfallversicherungsträgers; Teilnahmenachweis siehe Anlage.' },
  sonst: { label: 'Selbstzahler / sonstiger Kostenträger', betreff: 'Rechnung Rehabilitationssport / Funktionstraining', ref: [['Versichertennummer', (v) => v.versichertenNr]], hinweis: '' },
};
function rechnungHtml(v, data, vorlage, mitTermine) {
  const p = (S.patienten || []).find((x) => x.id === v.patientId) || {};
  const an = S.settings.anbieter || {};
  const vl = RECHNUNG_VORLAGEN[vorlage] || RECHNUNG_VORLAGEN.gkv;
  const r = data.rechnung;
  const art = (S.regeln.arten[v.art] || {}).label || v.art;
  const ref = vl.ref.map(([l, f]) => `<tr><td style="width:34%">${esc(l)}:</td><td>${esc(f(v) || '–')}</td></tr>`).join('');
  const bank = [an.iban && `IBAN ${an.iban}`, an.bic && `BIC ${an.bic}`, an.bank, an.kontoinhaber && `Kontoinhaber: ${an.kontoinhaber}`].filter(Boolean).join(' · ');
  const termine = mitTermine ? `<div style="page-break-before:always"></div><div class="pr-page"><h1>Anlage zur Rechnung ${esc(r.nr || '')} – Terminübersicht</h1>
    <div class="sub">${esc(p.nachname || v.name || '')}, ${esc(p.vorname || '')} · ${esc(art)} · Übungsleitung: ${esc(data.trainer.join(', ') || '–')}</div>
    <table><thead><tr><th>Nr.</th><th>Datum</th><th>Uhrzeit</th><th>Gruppe / Ort</th><th>Dauer</th><th>Teilnahmebestätigung</th><th>Leitung</th></tr></thead><tbody>
    ${data.termine.map((t, i) => `<tr><td>${i + 1}</td><td>${fmt(t.datum)}</td><td>${esc(t.beginn || '')}</td><td>${esc(t.kurs)}${t.ort ? ' · ' + esc(t.ort) : ''}</td><td>${t.dauerMin} Min.</td><td>${t.unterschrift === 'digital' ? `${t.unterschriftBild ? `<img src="${t.unterschriftBild}" alt="Unterschrift" style="height:30px;vertical-align:middle"> ` : ''}<span style="font-size:10px">${t.zeitstempel ? new Date(t.zeitstempel).toLocaleString('de-DE') : 'digital'}</span>` : 'Papierliste'}</td><td>${esc(t.leitung || '✔')}</td></tr>`).join('')}
    </tbody></table>
    <p><strong>${data.termine.length} Übungseinheiten</strong> mit Teilnahmebestätigung und Leitungsbestätigung.</p></div>` : '';
  return `<style>${PRINT_CSS}</style><div class="pr-page">
    <div style="display:flex;justify-content:space-between;gap:20px">
      <div><strong style="font-size:15px">${esc(an.name || '')}</strong><br>${esc(an.strasse || '')}<br>${esc([an.plz, an.ort].filter(Boolean).join(' '))}<br>${an.telefon ? 'Tel. ' + esc(an.telefon) + '<br>' : ''}${esc(an.email || '')}${an.ik ? '<br>IK ' + esc(an.ik) : ''}${an.steuernummer ? '<br>Steuer-Nr./USt-IdNr.: ' + esc(an.steuernummer) : ''}</div>
      <table class="kopf" style="width:auto"><tr><td>Rechnungs-Nr.:</td><td><strong>${esc(r.nr || '(Entwurf)')}</strong></td></tr><tr><td>Rechnungsdatum:</td><td>${fmt(r.datum)}</td></tr><tr><td>Zahlbar bis:</td><td>${fmt(r.faelligAm)}</td></tr></table>
    </div>
    <div style="margin:22px 0 14px"><strong>${esc(v.kostentraeger || 'Kostenträger')}</strong>${v.ik ? '<br>IK ' + esc(v.ik) : ''}</div>
    <h1>${esc(vl.betreff)}</h1>
    <table class="kopf"><tr><td style="width:34%">Versicherte/r:</td><td><strong>${esc(p.nachname || v.name || '')}, ${esc(p.vorname || '')}</strong> (geb. ${fmt(p.geburtsdatum || v.geburtsdatum)})</td></tr>${ref}
      <tr><td>Verordnung vom:</td><td>${fmt(v.ausstellungsdatum)} (${esc(v.arztName || '')})</td></tr><tr><td>Verordnungszeitraum:</td><td>${fmt(v.von)} – ${fmt(v.bis)}</td></tr></table>
    <table style="margin-top:12px"><thead><tr><th>Leistung</th><th style="text-align:right">Anzahl ÜE</th><th style="text-align:right">Einzelpreis</th><th style="text-align:right">Gesamt</th></tr></thead>
      <tbody><tr><td>${esc(art)}<br><span class="muted">${fmt(v.von)} – ${fmt(v.bis)}${r.abbruch ? ` · Maßnahme vorzeitig beendet am ${fmt(r.abbruch.datum)}` : ''}</span></td><td style="text-align:right">${r.uee}</td><td style="text-align:right">${euroFmt(r.satz)}</td><td style="text-align:right"><strong>${euroFmt(r.betrag)}</strong></td></tr>
      <tr><td colspan="3" style="text-align:right"><strong>Rechnungsbetrag</strong></td><td style="text-align:right"><strong>${euroFmt(r.betrag)}</strong></td></tr></tbody></table>
    ${r.bezahltAm ? `<p><strong>Bezahlt am ${fmt(r.bezahltAm)}: ${euroFmt(r.bezahltBetrag)}</strong></p>` : ''}
    <p>${an.steuerHinweis ? esc(an.steuerHinweis) + '<br>' : ''}${vl.hinweis ? esc(vl.hinweis) + '<br>' : ''}Die Terminübersicht mit den Teilnahmebestätigungen ${mitTermine ? 'liegt als Anlage bei' : 'kann auf Anforderung vorgelegt werden'}.</p>
    <p>Bitte überweisen Sie den Betrag bis ${fmt(r.faelligAm)} unter Angabe der Rechnungsnummer${bank ? ':<br><strong>' + esc(bank) + '</strong>' : '.'}</p>
    <div class="foot"><div>Ort, Datum</div><div>Unterschrift / Stempel</div></div></div>${termine}`;
}
window.druckeRechnung = (vid) => {
  const v = (S.verordnungen || []).find((x) => x.id === vid);
  if (!v) return;
  const vorg = v.kostentraegerArt === 'rv' ? 'rv' : v.kostentraegerArt === 'uv' ? 'uv' : (v.kostentraegerArt && v.kostentraegerArt !== 'gkv' ? 'sonst' : 'gkv');
  openModal('Rechnung drucken', `<div class="form2">
      <label>Rechnungsvorlage<select id="rv-vorlage">${Object.entries(RECHNUNG_VORLAGEN).map(([k, x]) => `<option value="${k}" ${k === vorg ? 'selected' : ''}>${esc(x.label)}</option>`).join('')}</select></label>
      <label class="check"><input type="checkbox" id="rv-termine" checked> Terminübersicht (Teilnahmebestätigungen) als Anlage</label></div>
      <p class="hint">Vorlagen sind Nachbildungen – bitte mit den Vorgaben des Kostenträgers abgleichen. Bankdaten und Steuerhinweis pflegen Sie unter Einstellungen → Anbieter.</p>`,
    [{ label: 'Abbrechen', cls: 'btn', onClick: closeModal },
     { label: '🖨 Anzeigen / Drucken', cls: 'btn primary', onClick: async () => {
       const vorlage = $('#rv-vorlage').value, mit = $('#rv-termine').checked;
       try { const data = await api('GET', `/api/verordnungen/${vid}/rechnung`); closeModal(); zeigeDruckansicht(rechnungHtml(v, data, vorlage, mit), `Rechnung_${RheaStore.sanit(data.rechnung.nr || v.name || 'Entwurf')}.html`); }
       catch (e) { toast(e.message, 'err'); } } }]);
};
/* ------------------- Abrechnungspaket für Abrechnungszentrum (azh / NOVENTI) ------------------- */
/* Hinweis: Die DTA-Datei nach § 302 SGB V erzeugt das Abrechnungszentrum aus den eingereichten Unterlagen. */
const AZH_POS_STANDARD = { rs: '604503', herzgruppe: '604504' };
const abrCfg = () => S.settings.abrechnung || {};
const azhPos = (v) => (abrCfg().positionsnummern || {})[v.art] || AZH_POS_STANDARD[v.art] || '';
const azhNr = () => `AZH-${heutigesISO().replace(/-/g, '')}`;

/** Prüfliste je Verordnung: [{ok, text, fix}] – fix = 'genehmigung' bietet Direktkorrektur. */
function azhPruefung(v, z, data) {
  const an = S.settings.anbieter || {};
  const ku = v.kostenuebernahme || {};
  const erster = (data.termine || []).map((t) => t.datum).sort()[0] || '';
  const mangel = [];
  const chk = (ok, text, fix) => { if (!ok) mangel.push({ text, fix }); };
  chk(Boolean(an.ik), 'IK des Anbieters fehlt (Einstellungen → Anbieter)');
  chk(Boolean(v.ik), 'IK des Kostenträgers fehlt (Verordnung)');
  chk(ku.liegtVor === true, 'Kostenübernahme/Genehmigung liegt nicht vor', 'genehmigung');
  chk(Boolean(ku.datum), 'Genehmigungsdatum fehlt', 'genehmigung');
  chk(Boolean(ku.kennzeichen), 'Genehmigungskennzeichen fehlt', 'genehmigung');
  chk(!ku.datum || !erster || ku.datum <= erster, `Genehmigung (${fmt(ku.datum)}) liegt nach der ersten Übungseinheit (${fmt(erster)}) – nur vor Leistungsbeginn genehmigte Verordnungen werden vergütet`, 'genehmigung');
  chk(Boolean(azhPos(v)), 'Positionsnummer für diese Maßnahme fehlt (Einstellungen → Abrechnung)');
  chk(Number(z.satz) > 0, 'Vergütungssatz fehlt');
  chk(v.art === 'funktionstraining' || Boolean(v.beratungsprotokoll), 'Beratungsprotokoll fehlt (Patient → Unterschriften)');
  chk(v.kostentraegerArt === 'gkv' || !v.kostentraegerArt, 'Kein Krankenkassenfall (§ 302 gilt nicht für Rentenversicherung/Unfallversicherung) – eigenes Verfahren des Trägers beachten');
  chk(!(v.kostentraegerArt === 'rv' && !z.fertig), 'Rentenversicherung: keine Zwischenabrechnung möglich, erst nach Ablauf/Abschluss');
  return mangel;
}

/* Abrechnungspaket als eigene Seite (Suche, Sortierung, Seiten, Auswahl, Summenfeld) */
const AZH = { zeilen: [], q: '', sort: { key: 'name', dir: 1 }, seite: 1, pro: 25, sel: new Set() };

async function azhPaketDialog() {
  const kand = ABR_ZEILEN.filter((z) => z.erbrachteUee > 0 && z.status !== 'abgerechnet');
  if (!kand.length) { toast('Keine abrechenbaren Verordnungen mit erbrachten Übungseinheiten.', ''); return; }
  let daten;
  try { daten = await Promise.all(kand.map((z) => api('GET', `/api/verordnungen/${z.id}/rechnung`))); } catch (e) { toast(e.message, 'err'); return; }
  const vorher = new Set(AZH.sel), hatteAuswahl = AZH.zeilen.length > 0;
  AZH.zeilen = kand.map((z, i) => {
    const v = (S.verordnungen || []).find((x) => x.id === z.id) || {};
    const p = (S.patienten || []).find((x) => x.id === v.patientId) || {};
    const r = { z, v, data: daten[i], p };
    r.mangel = azhPruefung(v, z, r.data);
    return r;
  });
  AZH.sel = new Set(hatteAuswahl ? AZH.zeilen.filter((r) => vorher.has(r.z.id)).map((r) => r.z.id) : AZH.zeilen.filter((r) => !r.mangel.length).map((r) => r.z.id));
  AZH.seite = 1;
  zeigeView('azh');
  $$('#nav button').forEach((b) => b.classList.toggle('active', b.dataset.view === 'abrechnung'));
}

function renderAzh() {
  const root = $('#view-azh');
  if (!root) return;
  const stelle = abrCfg().stelle || 'azh NOVENTI HealthCare GmbH';
  const q = AZH.q.trim().toLowerCase();
  const wert = { name: (r) => `${r.p.nachname || r.v.name || ''} ${r.p.vorname || ''}`.toLowerCase(), datum: (r) => r.v.ausstellungsdatum || '', art: (r) => r.z.artLabel || '', betrag: (r) => r.z.betrag || 0 }[AZH.sort.key];
  let liste = AZH.zeilen.filter((r) => !q || [r.p.nachname, r.p.vorname, r.v.name, r.z.artLabel, r.v.kostentraeger, r.v.versichertenNr].join(' ').toLowerCase().includes(q));
  liste = liste.sort((a, b) => (wert(a) > wert(b) ? 1 : wert(a) < wert(b) ? -1 : 0) * AZH.sort.dir);
  const seiten = Math.max(1, Math.ceil(liste.length / AZH.pro));
  AZH.seite = Math.min(AZH.seite, seiten);
  const sicht = liste.slice((AZH.seite - 1) * AZH.pro, AZH.seite * AZH.pro);
  const gewaehlt = AZH.zeilen.filter((r) => AZH.sel.has(r.z.id));
  const summe = gewaehlt.reduce((a, r) => a + (r.z.betrag || 0), 0);
  const pfeil = (k) => (AZH.sort.key === k ? (AZH.sort.dir > 0 ? ' ↑' : ' ↓') : '');
  root.innerHTML = `
    <div class="azh-card">
      <div class="azh-top"><button class="btn azh-grey" id="azh-back">Zurück zur Abrechnungsübersicht</button>
        <button class="btn azh-teal" id="azh-sbs">⬇ Sendungsbegleitschein herunterladen</button></div>
      <p class="hint">An: ${esc(stelle)} · Reichen Sie die <strong>Originalunterlagen</strong> ein (genehmigte Verordnung + Teilnahmebestätigung, nicht heften). Das Zentrum erzeugt daraus die DTA-Datei nach § 302 SGB V.</p>
      <div class="azh-search"><span>🔍</span><input id="azh-q" placeholder="Suchbegriff eingeben…" value="${esc(AZH.q)}"></div>
      <div class="table-wrap"><table class="azh-table"><thead><tr>
        <th style="width:34px"><input type="checkbox" id="azh-all" ${liste.length && liste.every((r) => AZH.sel.has(r.z.id)) ? 'checked' : ''}></th>
        <th data-s="name">Versicherte/r${pfeil('name')}</th><th data-s="datum">Ausstell.-Datum${pfeil('datum')}</th><th data-s="art">Maßnahme${pfeil('art')}</th>
        <th>Kostenträger</th><th>Abrechnung</th><th>ÜE</th><th data-s="betrag" style="text-align:right">Betrag${pfeil('betrag')}</th><th>Prüfung</th><th>Aktionen</th></tr></thead><tbody>
      ${sicht.map((r) => `<tr class="${AZH.sel.has(r.z.id) ? 'azh-sel' : ''}" data-id="${r.z.id}">
        <td><input type="checkbox" class="azh-chk" ${AZH.sel.has(r.z.id) ? 'checked' : ''}></td>
        <td><strong>${esc(r.p.nachname ? `${r.p.nachname}, ${r.p.vorname}` : r.v.name || '')}</strong><div class="muted small">${fmt(r.p.geburtsdatum || r.v.geburtsdatum)}</div></td>
        <td>${fmt(r.v.ausstellungsdatum)}</td><td>${esc(r.z.artLabel)}</td><td>${esc(r.v.kostentraeger || '')}</td>
        <td>${r.z.fertig ? 'Endabrechnung' : 'Zwischenabrechnung'}</td><td>${r.z.erbrachteUee}</td><td style="text-align:right">${euroFmt(r.z.betrag)}</td>
        <td>${r.mangel.length ? `<span class="chip amber" title="${esc(r.mangel.map((m) => m.text).join('\n'))}">⚠ ${r.mangel.length}</span>` : '<span class="chip green">✔</span>'}</td>
        <td class="azh-akt"><button class="ikon azh-open" title="Teilnahmebestätigung ansehen">↗</button><button class="ikon azh-menu" title="Weitere Aktionen">⋮</button></td></tr>`).join('') || '<tr><td colspan="10" class="muted">Keine Treffer.</td></tr>'}
      </tbody></table></div>
      <div class="azh-pager"><div><button class="ikon" id="azh-prev" ${AZH.seite <= 1 ? 'disabled' : ''}>‹</button> <strong>${AZH.seite}</strong> / ${seiten} <button class="ikon" id="azh-next" ${AZH.seite >= seiten ? 'disabled' : ''}>›</button></div>
        <label class="small">Ergebnisse pro Seite: <select id="azh-pro">${[10, 25, 50, 100].map((n) => `<option ${n === AZH.pro ? 'selected' : ''}>${n}</option>`).join('')}</select></label></div>
      <div class="azh-sum"><span class="muted">Verordnungen: ${gewaehlt.length} von ${AZH.zeilen.length} ausgewählt</span><span class="azh-sum-box"><strong>Verordnungswertsumme</strong> <span class="azh-wert">${euroFmt(summe)}</span></span></div>
      <div class="row" style="margin-top:12px"><button class="btn" id="azh-csv">CSV (Datenliste)</button><button class="btn primary" id="azh-print">🖨 Paket drucken</button><button class="btn" id="azh-submit">Als eingereicht markieren</button></div>
    </div>`;
  const aus = () => { if (!gewaehlt.length) { toast('Bitte mindestens eine Verordnung auswählen.', 'err'); return null; } return gewaehlt; };
  $('#azh-back', root).onclick = () => zeigeView('abrechnung');
  $('#azh-q', root).oninput = (e) => { AZH.q = e.target.value; AZH.seite = 1; renderAzh(); const i = $('#azh-q'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); };
  $$('th[data-s]', root).forEach((th) => { th.onclick = () => { const k = th.dataset.s; AZH.sort = { key: k, dir: AZH.sort.key === k ? -AZH.sort.dir : 1 }; renderAzh(); }; });
  $('#azh-all', root).onchange = (e) => { for (const r of liste) { if (e.target.checked) AZH.sel.add(r.z.id); else AZH.sel.delete(r.z.id); } renderAzh(); };
  $$('tbody tr[data-id]', root).forEach((tr) => {
    const r = AZH.zeilen.find((x) => x.z.id === tr.dataset.id);
    tr.querySelector('.azh-chk').onchange = (e) => { if (e.target.checked) AZH.sel.add(r.z.id); else AZH.sel.delete(r.z.id); renderAzh(); };
    tr.querySelector('.azh-open').onclick = () => zeigeDruckansicht(`<style>${PRINT_CSS}</style>${azhTeilnahmeHtml(r)}`, `Teilnahmebestaetigung_${RheaStore.sanit(r.p.nachname || 'Patient')}.html`);
    tr.querySelector('.azh-menu').onclick = () => azhAktionen(r);
  });
  $('#azh-prev', root).onclick = () => { AZH.seite--; renderAzh(); };
  $('#azh-next', root).onclick = () => { AZH.seite++; renderAzh(); };
  $('#azh-pro', root).onchange = (e) => { AZH.pro = Number(e.target.value); AZH.seite = 1; renderAzh(); };
  $('#azh-sbs', root).onclick = () => { const s = aus(); if (s) zeigeDruckansicht(azhDeckHtml(s), `Sendungsbegleitschein_${azhNr()}.html`); };
  $('#azh-csv', root).onclick = () => { const s = aus(); if (s) azhCsv(s); };
  $('#azh-print', root).onclick = () => { const s = aus(); if (s) zeigeDruckansicht(azhPaketHtml(s), `Abrechnungspaket_${azhNr()}.html`); };
  $('#azh-submit', root).onclick = async () => {
    const s = aus(); if (!s) return;
    const offen = s.filter((r) => r.mangel.length).length;
    if (!confirm(`${s.length} Verordnung(en) als an ${stelle} eingereicht markieren (Sendung ${azhNr()})?${offen ? `\\n\\nAchtung: ${offen} davon haben noch offene Prüfpunkte.` : ''}\\nSie erscheinen danach unter Offene Posten, bis Sie den Zahlungseingang erfassen.`)) return;
    try {
      for (const r of s) await api('POST', `/api/verordnungen/${r.z.id}/abrechnung`, { satz: r.z.satz, satzQuelle: 'Abrechnungspaket', rechnungsNr: azhNr(), abrechnen: true });
      AZH.zeilen = []; AZH.sel = new Set();
      await reload(true); zeigeView('abrechnung'); toast('Als eingereicht markiert.', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  };
}

function azhAktionen(r) {
  openModal(`${r.p.nachname ? `${r.p.nachname}, ${r.p.vorname}` : r.v.name || ''} – ${r.z.artLabel}`,
    r.mangel.length ? `<div class="list">${r.mangel.map((m) => `<div class="errline">⚠ ${esc(m.text)}</div>`).join('')}</div>` : '<div class="muted">✔ Alle Prüfpunkte erfüllt.</div>',
    [{ label: 'Schließen', cls: 'btn', onClick: closeModal },
     { label: 'Patient öffnen', cls: 'btn', onClick: () => { closeModal(); window.gotoPatient ? window.gotoPatient(r.v.patientId) : window.oeffnePatient(r.v.patientId); } },
     { label: 'Rechnung drucken', cls: 'btn', onClick: () => { closeModal(); window.druckeRechnung(r.z.id); } },
     { label: 'Genehmigung eintragen', cls: 'btn primary', onClick: () => azhGenehmigung(r.v) }]);
}
function azhGenehmigung(v) {
  const ku = v.kostenuebernahme || {};
  openModal(`Genehmigung – ${v.name || ''}`, `<div class="form2">
    <label>Genehmigungskennzeichen<input id="ag-kz" value="${esc(ku.kennzeichen || '')}"></label>
    <label>Genehmigungsdatum<input type="date" id="ag-dat" value="${esc(ku.datum || '')}"></label>
    <label>Gültig bis<input type="date" id="ag-bis" value="${esc(ku.gueltigBis || '')}"></label></div>
    <p class="hint">Diese Angaben stehen im Abschnitt „Kostenübernahmeerklärung“ der Verordnung (Muster 56) bzw. im Genehmigungsschreiben.</p>`,
  [{ label: 'Abbrechen', cls: 'btn', onClick: closeModal },
   { label: 'Speichern', cls: 'btn primary', onClick: async () => {
       try {
         await api('PUT', `/api/verordnungen/${v.id}`, { kostenuebernahme: Object.assign({}, ku, { liegtVor: true, kennzeichen: $('#ag-kz').value.trim(), datum: $('#ag-dat').value, gueltigBis: $('#ag-bis').value }) });
         closeModal(); await reload(false); await azhPaketDialog();
       } catch (e) { toast(e.message, 'err'); }
   } }]);
}

function azhTeilnahmeHtml(r) {
  const { z, v, data } = r;
  const an = S.settings.anbieter || {};
  const p = (S.patienten || []).find((x) => x.id === v.patientId) || {};
  const ku = v.kostenuebernahme || {};
  const hersteller = abrCfg().hersteller || 'RheaSport Physio und fit (Eigenentwicklung)';
  const digital = (data.termine || []).some((t) => t.unterschrift === 'digital');
  const rows = (data.termine || []).map((t, i) => `<tr><td>${i + 1}</td><td>${fmt(t.datum)}</td><td>${esc(t.beginn || '')}</td><td style="width:34%">${t.unterschrift === 'digital' ? (t.unterschriftBild ? `<img src="${t.unterschriftBild}" alt="" style="height:28px">` : 'digital') : 'Papierliste'}</td><td>${esc((data.trainer || []).join(', '))}</td></tr>`).join('');
  return `<div style="page-break-before:always"></div><div class="pr-page"><h1>Teilnahmebestätigung – ${esc(z.artLabel)}</h1>
    <div class="sub">${esc(an.name || '')} · IK ${esc(an.ik || '______')}</div>
    <table class="kopf">
      <tr><td>Versicherte/r:</td><td><strong>${esc(p.nachname || v.name || '')}, ${esc(p.vorname || '')}</strong> (geb. ${fmt(p.geburtsdatum || v.geburtsdatum)})</td></tr>
      <tr><td>Versichertennummer:</td><td>${esc(v.versichertenNr || '')}</td></tr>
      <tr><td>Kostenträger:</td><td>${esc(v.kostentraeger || '')} · IK ${esc(v.ik || '______')}</td></tr>
      <tr><td>Verordnung vom:</td><td>${fmt(v.ausstellungsdatum)} · ${esc(v.arztName || '')} · ${v.uebungseinheiten || '–'} ÜE · ${fmt(v.von)} – ${fmt(v.bis)}</td></tr>
      <tr><td>Genehmigung:</td><td>Kennzeichen ${esc(ku.kennzeichen || '______')} · vom ${fmt(ku.datum)} · gültig bis ${fmt(ku.gueltigBis || v.bis)}</td></tr>
      <tr><td>Positionsnummer:</td><td>${esc(azhPos(v))}</td></tr></table>
    <table><thead><tr><th>Nr.</th><th>Datum</th><th>Uhrzeit</th><th>Unterschrift Versicherte/r</th><th>Übungsleitung</th></tr></thead><tbody>${rows}</tbody></table>
    <table class="kopf" style="margin-top:12px"><tr><td>Abrechnung:</td><td>${z.fertig ? '☐' : '☒'} Zwischenabrechnung &nbsp; ${z.fertig ? '☒' : '☐'} Endabrechnung${z.abbruch ? ` (Abbruch ${fmt(z.abbruch.datum)}: ${esc(z.abbruch.grund)})` : ''}</td></tr>
      <tr><td>Übungseinheiten:</td><td>${z.erbrachteUee} × ${euroFmt(z.satz)} = <strong>${euroFmt(z.betrag)}</strong> (Gesamtsumme dieses Verordnungsblatts)</td></tr></table>
    ${digital ? `<div class="fine">Teilnahmen mit digitaler Unterschrift erfasst (Signatur-App auf Tablet/Smartphone, Hersteller: ${esc(hersteller)}).</div>` : ''}
    <div class="foot"><div>Datum, Stempel des Anbieters</div><div>Unterschrift Übungsleitung / Anbieter</div></div></div>`;
}
function azhDeckHtml(sel) {
  const an = S.settings.anbieter || {};
  const stelle = abrCfg().stelle || 'azh NOVENTI HealthCare GmbH';
  const summe = sel.reduce((a, r) => a + (r.z.betrag || 0), 0);
  const deck = `<style>${PRINT_CSS}</style><div class="pr-page"><h1>Sendungsbegleitschein – Einlieferung zur Abrechnung nach § 302 SGB V</h1>
    <div class="sub">An: ${esc(stelle)}${abrCfg().kundennr ? ' · Kunden-Nr. ' + esc(abrCfg().kundennr) : ''}</div>
    <table class="kopf"><tr><td>Leistungserbringer:</td><td>${esc(an.name || '')}, ${esc([an.strasse, an.plz, an.ort].filter(Boolean).join(' '))}</td></tr>
      <tr><td>IK:</td><td>${esc(an.ik || '')}</td></tr><tr><td>Einlieferung:</td><td>${esc(azhNr())} vom ${fmt(heutigesISO())}</td></tr>
      <tr><td>Bankverbindung:</td><td>${esc([an.iban, an.bic].filter(Boolean).join(' · '))}</td></tr></table>
    <table><thead><tr><th>Nr.</th><th>Versicherte/r</th><th>Kostenträger (IK)</th><th>Pos.-Nr.</th><th>Art</th><th style="text-align:right">ÜE</th><th style="text-align:right">Betrag</th></tr></thead><tbody>
    ${sel.map((r, i) => `<tr><td>${i + 1}</td><td>${esc(r.z.patient)}</td><td>${esc(r.v.kostentraeger || '')} (${esc(r.v.ik || '')})</td><td>${esc(azhPos(r.v))}</td><td>${r.z.fertig ? 'End' : 'Zwischen'}</td><td style="text-align:right">${r.z.erbrachteUee}</td><td style="text-align:right">${euroFmt(r.z.betrag)}</td></tr>`).join('')}
    <tr><td colspan="6"><strong>Summe (${sel.length} Verordnungen)</strong></td><td style="text-align:right"><strong>${euroFmt(summe)}</strong></td></tr></tbody></table>
    <div class="fine">Beigefügt: je Verordnung die genehmigte Originalverordnung (Muster 56) und die Teilnahmebestätigung. Bitte nicht heften/klammern. Die in diesem Paket gedruckten Teilnahmebestätigungen sind Nachbildungen – ob Ihr Abrechnungszentrum bzw. Ihre Kassen sie anstelle des Original-Vordrucks akzeptieren, vorher klären.</div></div>`;
  return deck;
}
function azhPaketHtml(sel) {
  return azhDeckHtml(sel) + sel.map(azhTeilnahmeHtml).join('');
}
function azhCsv(sel) {
  const q = (x) => `"${String(x ?? '').replace(/"/g, '""')}"`;
  const kopf = ['Nr', 'Name', 'Vorname', 'Geburtsdatum', 'Versichertennummer', 'Kostenträger', 'Kostenträger-IK', 'Maßnahme', 'Positionsnummer', 'Verordnung vom', 'Genehmigungskennzeichen', 'Genehmigungsdatum', 'Gültig bis', 'Zeitraum von', 'Zeitraum bis', 'Anzahl ÜE', 'Einzelpreis', 'Summe', 'Abrechnungsart', 'Beratungsprotokoll'];
  const zeilen = sel.map((r, i) => {
    const p = (S.patienten || []).find((x) => x.id === r.v.patientId) || {}; const ku = r.v.kostenuebernahme || {};
    return [i + 1, p.nachname || '', p.vorname || '', p.geburtsdatum || r.v.geburtsdatum || '', r.v.versichertenNr || '', r.v.kostentraeger || '', r.v.ik || '', r.z.artLabel, azhPos(r.v), r.v.ausstellungsdatum || '', ku.kennzeichen || '', ku.datum || '', ku.gueltigBis || '', r.v.von || '', r.v.bis || '', r.z.erbrachteUee, String(r.z.satz).replace('.', ','), String(r.z.betrag).replace('.', ','), r.z.fertig ? 'Endabrechnung' : 'Zwischenabrechnung', r.v.beratungsprotokoll ? 'ja' : 'nein'].map(q).join(';');
  });
  dateiTeilen(`Abrechnung_${azhNr()}.csv`, '\ufeff' + [kopf.map(q).join(';'), ...zeilen].join('\r\n'), 'text/csv');
}
const btnAzh = $('#btn-abr-azh');
if (btnAzh) btnAzh.onclick = azhPaketDialog;

function listeDruckHtml(titel, zeilen) {
  const an = S.settings.anbieter || {};
  const sum = zeilen.reduce((a, z) => a + (z.betrag || 0), 0);
  return `<style>${PRINT_CSS}</style><div class="pr-page" style="max-width:1100px"><h1>${esc(titel)}</h1><div class="sub">${esc(an.name || '')} · Stand ${fmt(heutigesISO())}</div>
    <table><thead><tr><th>Patient/in</th><th>Kostenträger</th><th>Rechnung</th><th>Datum</th><th>Fällig</th><th style="text-align:right">Betrag</th><th>Status</th></tr></thead><tbody>
    ${zeilen.map((z) => `<tr><td>${esc(z.patient)}</td><td>${esc(z.kostentraeger || '')}</td><td>${esc((z.abrechnung || {}).rechnungsNr || '')}</td><td>${fmt(z.rechnungsdatum)}</td><td>${fmt(z.faelligAm)}</td><td style="text-align:right">${z.betrag != null ? euroFmt(z.betrag) : '–'}</td><td>${z.status === 'abgerechnet' ? (z.offen ? (z.ueberfaellig ? 'überfällig' : 'offen') : 'bezahlt ' + fmt(z.bezahltAm)) : esc(z.status)}</td></tr>`).join('')}
    <tr><td colspan="5"><strong>Summe (${zeilen.length} Einträge)</strong></td><td style="text-align:right"><strong>${euroFmt(sum)}</strong></td><td></td></tr></tbody></table></div>`;
}
$('#btn-abr-druck').onclick = () => zeigeDruckansicht(listeDruckHtml('Abrechnungsliste', abrGefiltert()), 'Abrechnungsliste.html');
$('#btn-abr-offen').onclick = () => zeigeDruckansicht(listeDruckHtml('Offene Posten', ABR_ZEILEN.filter((z) => z.offen).sort((x, y) => String(x.faelligAm).localeCompare(String(y.faelligAm)))), 'Offene_Posten.html');
$('#btn-abr-stat-druck').onclick = async () => {
  try {
    const st = await api('GET', `/api/statistik?monat=${ABR_MONAT}`);
    const g = st.gesamt, an = S.settings.anbieter || {};
    const [j, mo] = st.monat.split('-').map(Number);
    const titel = new Date(j, mo - 1, 1).toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });
    const offen = ABR_ZEILEN.filter((z) => z.offen);
    zeigeDruckansicht(`<style>${PRINT_CSS}</style><div class="pr-page"><h1>Statistik ${esc(titel)}</h1><div class="sub">${esc(an.name || '')} · Stand ${fmt(heutigesISO())}</div>
      <table class="kopf"><tr><td>Einheiten durchgeführt / geplant:</td><td>${g.termine} / ${g.geplantTermine}</td></tr><tr><td>Teilnahmen:</td><td>${g.teilnahmen}</td></tr><tr><td>Ausgefallen / Abbrüche:</td><td>${g.ausgefallen} / ${g.abbrueche}</td></tr>
      <tr><td>Einnahmen bisher / voraussichtlich:</td><td>${euroFmt(g.einnahmen)} / ${euroFmt(g.einnahmenPrognose)}</td></tr><tr><td>Trainerkosten bisher / voraussichtlich:</td><td>${euroFmt(g.trainerkosten)} / ${euroFmt(g.trainerkostenPrognose)}</td></tr>
      <tr><td><strong>Voraussichtliches Ergebnis:</strong></td><td><strong>${euroFmt(g.ergebnisPrognose)}</strong></td></tr><tr><td>Offene Posten:</td><td>${offen.length} · ${euroFmt(offen.reduce((a, z) => a + (z.betrag || 0), 0))}</td></tr></table>
      <table style="margin-top:12px"><thead><tr><th>Trainer/in</th><th style="text-align:right">€/Std.</th><th style="text-align:right">Std. bisher</th><th style="text-align:right">Verdienst</th><th style="text-align:right">Std. geplant</th><th style="text-align:right">Voraussichtlich</th></tr></thead><tbody>
      ${st.trainer.map((t) => `<tr><td>${esc(t.name)}</td><td style="text-align:right">${euroFmt(t.stundenlohn)}</td><td style="text-align:right">${t.stunden}</td><td style="text-align:right">${euroFmt(t.verdienst)}</td><td style="text-align:right">${t.geplantStunden}</td><td style="text-align:right">${euroFmt(t.prognose)}</td></tr>`).join('')}</tbody></table></div>`, `Statistik_${st.monat}.html`);
  } catch (e) { toast(e.message, 'err'); }
};
/** E-Mail mit Anhang: Teilen-Dialog (Gmail-App wählbar) – Fallback: Datei speichern + mailto. */
async function mailMitAnhang({ an, betreff, text, dateien }) {
  const files = dateien.map((d) => new File([d.inhalt], d.name, { type: d.mime }));
  try {
    if (navigator.canShare && navigator.canShare({ files })) {
      if (an) { try { await navigator.clipboard.writeText(an); toast(`Empfänger ${an} in die Zwischenablage kopiert – in Gmail einfügen.`, 'ok'); } catch (_) { /* egal */ } }
      await navigator.share({ files, title: betreff, text });
      return;
    }
  } catch (e) { if (e && e.name === 'AbortError') return; }
  for (const f of files) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(f); a.download = f.name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 8000);
  }
  toast('Anhang wurde gespeichert – bitte in der Mail manuell anhängen.', '');
  window.location.href = `mailto:${an || ''}?subject=${encodeURIComponent(betreff)}&body=${encodeURIComponent(text)}`;
}

$('#btn-abr-mail').onclick = async () => {
  if (!confirm('Die Abrechnungsliste enthält personenbezogene Daten (Namen, Kostenträger). Nur an berechtigte Empfänger senden. Fortfahren?')) return;
  try {
    const r = await api('GET', '/api/abrechnung/export.csv');
    const l = await api('GET', '/api/abrechnung');
    const summe = (l.zeilen || []).reduce((a, z) => a + (z.betrag || 0), 0);
    const an = (S.settings.google || {}).abrechnungEmpfaenger || '';
    const an0 = S.settings.anbieter || {};
    await mailMitAnhang({
      an, betreff: `Abrechnung ${an0.name || 'RheaSport'} – Stand ${fmt(heutigesISO())}`,
      text: ['Guten Tag,', '', `anbei die Abrechnungsliste (Stand ${fmt(heutigesISO())}): ${(l.zeilen || []).length} Verordnungen, Summe ${euroFmt(summe)}.`, '', 'Mit freundlichen Grüßen', an0.name || ''].join('\n'),
      dateien: [{ name: r.dateiname || 'rehasport-abrechnung.csv', inhalt: r.csv, mime: 'text/csv' }],
    });
  } catch (e) { toast(`E-Mail fehlgeschlagen: ${e.message}`, 'err'); }
};

$('#btn-csv').onclick = async () => {
  if (window.LOCAL_MODE) {
    try {
      const r = await api('GET', '/api/abrechnung/export.csv');
      await dateiTeilen(r.dateiname || 'rehasport-abrechnung.csv', r.csv, 'text/csv');
    } catch (e) { toast(`CSV-Export fehlgeschlagen: ${e.message}`, 'err'); }
    return;
  }
  window.location.href = '/api/abrechnung/export.csv';
};

/* ============================== POSTFACH ============================== */
function renderPostfach() {
  setTimeout(filterPostfach, 0);
  $('#smtp-hinweis').innerHTML = (S.lokalModus || window.LOCAL_MODE)
    ? `<span class="chip blue">APK-Lokalmodus</span> Nachrichten werden als Entwurf angelegt und über das <strong>E-Mail-Programm des Geräts</strong> versendet (Öffnen-Button → Mail-App mit Empfänger, Betreff und Text). Automatischer SMTP-Versand ist nur in der Server-Version möglich.`
    : S.mailKonfiguriert
      ? `<span class="chip green">SMTP konfiguriert</span> Nachrichten werden automatisch versendet. <button class="link" onclick="zeigeView('einstellungen')">Einstellungen</button>`
      : `<strong>SMTP noch nicht konfiguriert.</strong> Patienten-Termine- und Vollständigkeits-E-Mails werden als Entwurf vorgehalten und können per Mail-Programm geöffnet werden. <button class="link" onclick="zeigeView('einstellungen')">Jetzt konfigurieren</button>`;
  if (googleAktiv() && RheaGoogle.status().angemeldet) $('#smtp-hinweis').innerHTML += ` <span class="chip green">Gmail verbunden</span> Nachrichten können direkt über Gmail gesendet werden. <button class="btn small primary" onclick="mailGmailAlle()">Alle offenen senden</button>`;
  const statusChipFn = (m) => {
    if (m.status === 'mailto-bereit') return '<span class="chip amber">Entwurf (Gerät)</span>';
    return `<span class="chip ${m.status === 'gesendet' ? 'green' : m.status === 'fehler' ? 'red' : 'amber'}">${m.status === 'konfiguration-offen' ? 'Entwurf (SMTP offen)' : esc(m.status)}</span>`;
  };
  const rows = (S.outbox || []).map((m) => `<tr>
    <td>${new Date(m.ts).toLocaleString('de-DE')}</td>
    <td><span class="chip ${m.typ === 'patient-termine' ? 'blue' : 'purple'}">${m.typ === 'patient-termine' ? 'Patient: Termine' : m.typ === 'verordnung-vollstaendig' ? 'Führungspersonal: vollständig' : m.typ}</span></td>
    <td>${esc((m.an || []).join(', '))}</td>
    <td>${esc(m.betreff)}</td>
    <td>${statusChipFn(m)}${m.fehler ? `<div class="muted small">${esc(m.fehler)}</div>` : ''}</td>
    <td class="row">
      <button class="btn small" onclick="mailVorschau('${m.id}')">Vorschau</button>
      ${googleAktiv() && RheaGoogle.status().angemeldet && m.status !== 'gesendet' ? `<button class="btn small primary" onclick="mailGmail('${m.id}')">Per Gmail senden</button>` : ''}
      <button class="btn small" onclick="mailMailto('${m.id}')">Öffnen</button>
      <button class="btn small" onclick="mailErneut('${m.id}')">Erneut</button>
    </td></tr>`).join('');
  $('#outbox-tabelle tbody').innerHTML = rows || '<tr><td colspan="6" class="muted">Noch keine Nachrichten erzeugt.</td></tr>';
}
window.mailVorschau = (id) => {
  const m = (S.outbox || []).find((x) => x.id === id);
  if (!m) return;
  openModal(`Vorschau: ${m.betreff}`, `<div class="outbox-preview">${m.html ? `<iframe srcdoc="${esc(m.html)}"></iframe>` : `<pre>${esc(m.text)}</pre>`}</div>`,
    [{ label: 'Schließen', cls: 'btn primary', onClick: closeModal }], { wide: true });
};
window.mailMailto = async (id) => {
  const r = await api('GET', `/api/outbox/${id}/mailto`);
  window.location.href = r.mailto;
};
window.mailErneut = async (id) => {
  try { const r = await api('POST', `/api/outbox/${id}/erneut`); await reload(true); toast(mailStatusText(r.outbox), r.outbox.status === 'gesendet' ? 'ok' : 'err'); }
  catch (e) { toast(e.message, 'err'); }
};

/* ============================== GOOGLE (Gmail & Kalender) ============================== */
const googleAktiv = () => Boolean(window.RheaGoogle) && Boolean(S.lokalModus || window.LOCAL_MODE);
let googleSendet = false;

async function gmailSendeEintrag(m) {
  try {
    await RheaGoogle.gmailSenden({ an: m.an, betreff: m.betreff, text: m.text, html: m.html });
    await api('POST', `/api/outbox/${m.id}/status`, { status: 'gesendet', via: 'gmail' });
    return true;
  } catch (e) {
    await api('POST', `/api/outbox/${m.id}/status`, { status: 'fehler', fehler: String(e.message || e).slice(0, 200), via: 'gmail' }).catch(() => {});
    throw e;
  }
}
/** Sendet alle noch offenen Entwürfe über Gmail (nur wenn angemeldet). */
async function gmailOffeneSenden(still) {
  if (googleSendet || !googleAktiv() || !RheaGoogle.status().angemeldet) return 0;
  const offen = (S.outbox || []).filter((m) => m.status === 'mailto-bereit' || m.status === 'konfiguration-offen');
  if (!offen.length) { if (!still) toast('Keine offenen Nachrichten.', ''); return 0; }
  googleSendet = true;
  let ok = 0, fehler = '';
  try {
    for (const m of offen.slice().reverse()) {
      try { if (await gmailSendeEintrag(m)) ok++; } catch (e) { fehler = e.message; }
    }
  } finally { googleSendet = false; }
  await reload(true);
  if (!still || fehler) toast(fehler ? `${ok} gesendet, Fehler: ${fehler}` : `${ok} Nachricht(en) über Gmail gesendet.`, fehler ? 'err' : 'ok');
  return ok;
}
window.mailGmail = async (id) => {
  const m = (S.outbox || []).find((x) => x.id === id);
  if (!m) return;
  try { await gmailSendeEintrag(m); await reload(true); toast('Über Gmail gesendet.', 'ok'); }
  catch (e) { await reload(true); toast(e.message, 'err'); }
};
window.mailGmailAlle = () => gmailOffeneSenden(false);

async function renderGoogleCard() {
  const el = $('#cfg-google');
  if (!el) return;
  if (!googleAktiv()) { el.innerHTML = '<p class="hint">Die Google-Anbindung steht im Lokalmodus (APK) zur Verfügung.</p>'; return; }
  const c = await RheaGoogle.config();
  const st = RheaGoogle.status(), op = RheaGoogle.optionen();
  if (!c.clientId) {
    el.innerHTML = `<p class="hint"><strong>Noch nicht eingerichtet.</strong> Trage deine Google-Client-ID in <code>public/google-config.json</code> ein und baue die App neu (die ID wird auch für den Rücksprung in die App benötigt). Anleitung: README, Abschnitt „Google einrichten“.</p>`;
    return;
  }
  el.innerHTML = `<div class="row">${st.angemeldet ? `<span class="chip green">angemeldet</span> <strong>${esc(st.email || 'Google-Konto')}</strong>` : '<span class="chip gray">nicht angemeldet</span>'}</div>
    <div class="row" style="margin-top:8px">
      ${st.angemeldet
        ? '<button class="btn small" id="g-abmelden">Abmelden</button><button class="btn small primary" id="g-kal">Kalender abgleichen &amp; teilen</button><button class="btn small" id="g-test">Testmail an mich</button>'
        : '<button class="btn primary" id="g-anmelden">Mit Google anmelden</button>'}
    </div>
    ${st.angemeldet ? `<label class="check" style="margin-top:8px"><input type="checkbox" id="g-auto" ${op.autoMail ? 'checked' : ''}> Neue Nachrichten (Termine, Abrechnungen, Vollständigkeit) automatisch über Gmail senden</label>` : ''}
    <p class="hint">Die Anmeldung öffnet den Browser des Geräts (Google erlaubt sie nicht innerhalb der App). Der Kalender „${esc((S.settings.kalender || {}).titel || 'RheaSport Kurse')}“ enthält die kommenden 60 Tage (nur Gruppe, Ort, Zeit, Übungsleitung – keine Patientendaten) und wird für Trainer mit E-Mail-Adresse zum Lesen freigegeben.</p>
    <div id="g-ergebnis" class="muted small"></div>`;
  const on = (id, fn) => { const b = el.querySelector(id); if (b) b.onclick = fn; };
  on('#g-anmelden', async (ev) => {
    ev.target.disabled = true;
    try { toast('Browser öffnet sich – bitte bei Google anmelden …', ''); const r = await RheaGoogle.anmelden(); toast(`Angemeldet als ${r.email || 'Google-Konto'}.`, 'ok'); }
    catch (e) { toast(e.message, 'err'); }
    renderGoogleCard();
  });
  on('#g-abmelden', () => { RheaGoogle.abmelden(); renderGoogleCard(); });
  on('#g-test', async () => {
    try { await RheaGoogle.gmailSenden({ an: st.email, betreff: 'RheaSport Test-E-Mail', text: 'Gmail-Versand funktioniert ✔' }); toast('Testmail gesendet.', 'ok'); }
    catch (e) { toast(e.message, 'err'); }
  });
  on('#g-kal', async (ev) => {
    ev.target.disabled = true;
    try {
      const r = await RheaGoogle.kalenderAbgleichen({ termine: S.termine || [], kurse: S.kurse || [], trainer: S.trainer || [], titel: (S.settings.kalender || {}).titel, heute: heutigesISO(), tage: 60 });
      $('#g-ergebnis').textContent = `Kalender abgeglichen: ${r.neu} neu, ${r.aktualisiert} aktualisiert, ${r.entfernt} entfernt, ${r.geteilt} Trainer freigegeben.`;
      toast('Google-Kalender abgeglichen.', 'ok');
    } catch (e) { toast(e.message, 'err'); }
    ev.target.disabled = false;
  });
  const auto = el.querySelector('#g-auto');
  if (auto) auto.onchange = () => { RheaGoogle.setzeOptionen({ autoMail: auto.checked }); if (auto.checked) gmailOffeneSenden(true); };
}
window.addEventListener('rhea-google', () => { if (aktuelleView === 'einstellungen') renderGoogleCard(); });

$('#btn-csv-gmail').onclick = async () => {
  if (!googleAktiv() || !RheaGoogle.status().angemeldet) { toast('Bitte zuerst unter Einstellungen → Google anmelden.', 'err'); return; }
  const ziel = prompt('Abrechnung (CSV) per Gmail senden an:', (S.settings.google || {}).abrechnungEmpfaenger || '');
  if (!ziel) return;
  try {
    const r = await api('GET', '/api/abrechnung/export.csv');
    const base64 = btoa(unescape(encodeURIComponent('\ufeff' + r.csv)));
    await RheaGoogle.gmailSenden({ an: ziel.trim(), betreff: `Abrechnung RheaSport ${fmt(heutigesISO())}`, text: 'Im Anhang die aktuelle Abrechnung (CSV).', anhaenge: [{ name: r.dateiname || 'rehasport-abrechnung.csv', mime: 'text/csv', base64 }] });
    toast('Abrechnung per Gmail gesendet.', 'ok');
  } catch (e) { toast(e.message, 'err'); }
};

/* ============================== EINSTELLUNGEN ============================== */
function renderEinstellungen() {
  const lokal = Boolean(S.lokalModus || window.LOCAL_MODE);
  const smtpHint = $('#smtp-hint-text');
  if (smtpHint) {
    smtpHint.innerHTML = lokal
      ? '<strong>APK-Lokalmodus:</strong> Auf dem Gerät wird kein SMTP-Versand verwendet – jede Nachricht wird als Entwurf angelegt und über die <strong>Mail-App des Geräts</strong> versendet (E-Mail-Journal → „Öffnen“). SMTP-Felder gelten für die Server-Version.'
      : 'Ohne SMTP-Konfiguration werden alle Nachrichten im Journal vorgehalten und können als Entwurf (mailto:) geöffnet werden. Beispiel GMX: <code>mail.gmx.net</code> (Port 587, TLS).';
  }
  const exp = $('#btn-export');
  if (exp && lokal) {
    exp.removeAttribute('href');
    exp.onclick = async (ev) => {
      ev.preventDefault();
      try { const r = await api('GET', '/api/export'); await dateiTeilen(r.dateiname || 'rheasport-backup.json', r.json, 'application/json'); }
      catch (e) { toast(`Export fehlgeschlagen: ${e.message}`, 'err'); }
    };
  } else if (exp) { exp.setAttribute('href', '/api/export'); exp.onclick = null; }
  const a = S.settings.anbieter || {};
  $$('#cfg-anbieter [data-a]').forEach((el) => { el.value = a[el.dataset.a] ?? ''; });
  const s = S.settings.smtp || {};
  $$('#cfg-smtp [data-s]').forEach((el) => {
    if (el.type === 'checkbox') el.checked = Boolean(s[el.dataset.s]);
    else el.value = s[el.dataset.s] ?? '';
  });
  const ds = S.settings.datenschutz || {};
  $$('#cfg-ds [data-d]').forEach((el) => { el.value = ds[el.dataset.d] ?? ''; });

  $('#cfg-bundesland').innerHTML = (S.regeln.bundeslaender || []).map(([id, name]) =>
    `<option value="${id}" ${S.settings.bundesland === id ? 'selected' : ''}>${name}</option>`).join('');
  $('#cfg-laendlich').checked = Boolean(S.settings.ortLändlich);
  zeichneHilfsfrist();

  const fp = S.settings.fuehrungspersonal || [];
  $('#cfg-fuehrung').innerHTML = fp.map((f, i) => `
    <div class="row" data-i="${i}" style="margin-bottom:6px">
      <input value="${esc(f.name)}" data-fp="name" placeholder="Name" style="flex:1">
      <input value="${esc(f.email)}" data-fp="email" type="email" placeholder="E-Mail" style="flex:1.4">
      <button class="btn small danger" data-fp-del="${i}">✕</button>
    </div>`).join('') || '<div class="muted small">Noch keine Empfänger – ohne Eintrag erfolgt kein Versand der Vollständigkeits-Bestätigung.</div>';
  $$('#cfg-fuehrung [data-fp-del]').forEach((b) => {
    b.onclick = () => { S.settings.fuehrungspersonal.splice(Number(b.dataset.fpDel), 1); renderEinstellungen(); };
  });

  $('#cfg-kal-titel').value = (S.settings.kalender || {}).titel || '';
  $('#cfg-gruppen').value = (S.settings.gruppennamen || []).join('\n');
  $('#cfg-gmail').value = (S.settings.google || {}).adresse || '';
  $('#cfg-abr-mail').value = (S.settings.google || {}).abrechnungEmpfaenger || '';
  $('#cfg-scan-punkte').checked = (S.settings.scan || {}).punkteAbhaken !== false;
  $('#cfg-zahlungsziel').value = Number((S.settings.abrechnung || {}).zahlungszielTage ?? 30);
  $('#cfg-vorab').value = Number((S.settings.unterschrift || {}).vorabMinuten ?? 20);
  $('#cfg-autoabr').checked = (S.settings.abrechnung || {}).automatisch !== false;
  { const ab = S.settings.abrechnung || {}; $('#cfg-abr-stelle').value = ab.stelle || 'azh NOVENTI HealthCare GmbH'; $('#cfg-abr-kundennr').value = ab.kundennr || ''; $('#cfg-abr-hersteller').value = ab.hersteller || 'RheaSport Physio und fit (Eigenentwicklung)';
    $('#cfg-abr-pos').value = Object.entries(Object.assign({}, AZH_POS_STANDARD, ab.positionsnummern || {})).map(([k, v]) => `${k}=${v}`).join('\n'); }
  $('#smtp-status').textContent = S.mailKonfiguriert ? '✔ konfiguriert' : '○ nicht konfiguriert';

  ladeSaetze();
  renderBackupCard();
  renderSyncCard();
  renderGoogleCard();
}

function zeichneHilfsfrist() {
  const bl = $('#cfg-bundesland').value || 'NW';
  const hf = (S.regeln.hilfsfristen || {})[bl] || {};
  const name = ((S.regeln.bundeslaender || []).find(([id]) => id === bl) || [])[1] || bl;
  $('#cfg-hilfsfrist').innerHTML = `<strong>${esc(name)}:</strong> Hilfsfrist ${esc(hf.text || '–')} ${$('#cfg-laendlich').checked && bl === 'NW' ? '– Einsatzgebiet als <em>ländlich</em> markiert (12 Min.)' : ''}<br>
    <span class="muted small">Empfehlung BAR: Eintreffen „unverzüglich“, Orientierung 8 Minuten.</span>`;
}
$('#cfg-bundesland').addEventListener('change', zeichneHilfsfrist);
$('#cfg-laendlich').addEventListener('change', zeichneHilfsfrist);

/* ------------------- Vergütungssätze: Datensätze, Abfrage, Import ------------------- */
const BUNDESLAENDER = { BW: 'Baden-Württemberg', BY: 'Bayern', BE: 'Berlin', BB: 'Brandenburg', HB: 'Bremen', HH: 'Hamburg', HE: 'Hessen', MV: 'Mecklenburg-Vorpommern', NI: 'Niedersachsen', NW: 'Nordrhein-Westfalen', RP: 'Rheinland-Pfalz', SL: 'Saarland', SN: 'Sachsen', ST: 'Sachsen-Anhalt', SH: 'Schleswig-Holstein', TH: 'Thüringen' };
const KT_ARTEN = { gkv: 'Krankenkassen (GKV)', rv: 'Rentenversicherung', uv: 'Unfallversicherung (DGUV)', sonstige: 'sonstige' };
let SATZ_EDIT = [], SATZ_FILTER = { q: '', art: '', bl: '' }, SATZ_DIRTY = false;

/** Spiegel der Backend-Logik: spezifischste, jüngste passende Zeile. */
function satzSuche(liste, k) {
  const name = String(k.kostentraeger || '').toLowerCase();
  const t = liste.filter((r) => r.art === k.art && (!r.kostentraegerArt || r.kostentraegerArt === (k.kt || 'gkv')) && (!r.bundesland || r.bundesland === (k.bl || ''))
    && (!r.kostentraeger || !name || name.includes(r.kostentraeger.toLowerCase())) && (!r.gueltigAb || r.gueltigAb <= (k.datum || '9999-12-31')));
  const score = (r) => (r.kostentraeger ? 4 : 0) + (r.bundesland ? 2 : 0) + (r.kostentraegerArt ? 1 : 0);
  t.sort((a, b) => score(b) - score(a) || (b.gueltigAb || '').localeCompare(a.gueltigAb || ''));
  return t[0] || null;
}
const artLabel = (a) => ((S.regeln.arten[a] || {}).label || a);
const artOptionen = (sel, leer) => (leer ? `<option value="">${leer}</option>` : '') + Object.entries(S.regeln.arten).map(([k, x]) => `<option value="${k}" ${sel === k ? 'selected' : ''}>${esc(x.label)}</option>`).join('');
const blOptionen = (sel, leer) => `<option value="">${leer}</option>` + Object.entries(BUNDESLAENDER).map(([k, n]) => `<option value="${k}" ${sel === k ? 'selected' : ''}>${esc(n)}</option>`).join('');
const ktOptionen = (sel, leer) => `<option value="">${leer}</option>` + Object.entries(KT_ARTEN).map(([k, n]) => `<option value="${k}" ${sel === k ? 'selected' : ''}>${esc(n)}</option>`).join('');

function ladeSaetze() {
  SATZ_EDIT = JSON.parse(JSON.stringify((S.settings.abrechnung || {}).saetze || []));
  SATZ_DIRTY = false;
  const sq = $('#sq-bl');
  if (sq && !sq.dataset.init) {
    sq.dataset.init = '1';
    sq.innerHTML = blOptionen(S.settings.bundesland || '', 'bundesweit / alle');
    $('#sq-art').innerHTML = artOptionen('rs');
    $('#sq-kt').innerHTML = ktOptionen('gkv', '– egal –');
    $('#sq-datum').value = heutigesISO();
    $('#sf-art').innerHTML = artOptionen('', 'alle Maßnahmen');
    $('#sf-bl').innerHTML = blOptionen('', 'alle Länder');
    ['sq-bl', 'sq-art', 'sq-kt', 'sq-name', 'sq-datum'].forEach((id) => { $('#' + id).addEventListener('input', zeichneSatzAbfrage); $('#' + id).addEventListener('change', zeichneSatzAbfrage); });
    $('#sf-q').oninput = (e) => { SATZ_FILTER.q = e.target.value; zeichneSaetze(); };
    $('#sf-art').onchange = (e) => { SATZ_FILTER.art = e.target.value; zeichneSaetze(); };
    $('#sf-bl').onchange = (e) => { SATZ_FILTER.bl = e.target.value; zeichneSaetze(); };
    $('#btn-satz-plus').onclick = () => { SATZ_EDIT.unshift({ id: `s_${Date.now().toString(36)}`, bundesland: S.settings.bundesland || '', kostentraegerArt: 'gkv', kostentraeger: '', art: 'rs', gueltigAb: heutigesISO().slice(0, 4) + '-01-01', satz: '', quelle: '' }); SATZ_DIRTY = true; SATZ_FILTER = { q: '', art: '', bl: '' }; $('#sf-q').value = ''; $('#sf-art').value = ''; $('#sf-bl').value = ''; zeichneSaetze(); };
    $('#btn-satz-import').onclick = satzImportDialog;
    $('#btn-satz-export').onclick = () => dateiTeilen('verguetungssaetze.csv', satzCsv(), 'text/csv');
    $('#btn-satz-save').onclick = satzSpeichern;
  }
  zeichneSatzAbfrage(); zeichneSaetze();
}
function zeichneSatzAbfrage() {
  const k = { bl: $('#sq-bl').value, art: $('#sq-art').value, kt: $('#sq-kt').value, kostentraeger: $('#sq-name').value, datum: $('#sq-datum').value };
  const r = satzSuche(SATZ_EDIT, k);
  $('#sq-erg').innerHTML = r
    ? `<div class="satz-wert">${euroFmt(r.satz)} <span class="muted small">je Übungseinheit</span></div><div class="muted small">${esc(artLabel(r.art))} · ${esc(r.bundesland ? BUNDESLAENDER[r.bundesland] : 'bundesweit')} · ${esc(r.kostentraeger || KT_ARTEN[r.kostentraegerArt] || 'alle Kostenträger')} · gültig ab ${fmt(r.gueltigAb)}${r.quelle ? ' · ' + esc(r.quelle) : ''}</div>`
    : '<div class="errline">Für diese Auswahl ist kein Satz hinterlegt – unten einen Datensatz anlegen oder per „Datensätze einsetzen“ importieren.</div>';
}
function zeichneSaetze() {
  const q = SATZ_FILTER.q.trim().toLowerCase();
  const liste = SATZ_EDIT.filter((r) => (!SATZ_FILTER.art || r.art === SATZ_FILTER.art) && (!SATZ_FILTER.bl || r.bundesland === SATZ_FILTER.bl)
    && (!q || [r.kostentraeger, r.quelle, artLabel(r.art), BUNDESLAENDER[r.bundesland]].join(' ').toLowerCase().includes(q)))
    .sort((a, b) => artLabel(a.art).localeCompare(artLabel(b.art), 'de') || (a.bundesland || '').localeCompare(b.bundesland || '') || (b.gueltigAb || '').localeCompare(a.gueltigAb || ''));
  $('#sf-zaehler').textContent = `${liste.length} von ${SATZ_EDIT.length} Datensätzen${SATZ_DIRTY ? ' · ungespeicherte Änderungen' : ''}`;
  $('#cfg-saetze').innerHTML = liste.slice(0, 200).map((r) => `<div class="satz-card" data-id="${r.id}">
      <label>Maßnahme<select data-f="art">${artOptionen(r.art)}</select></label>
      <label>Bundesland<select data-f="bundesland">${blOptionen(r.bundesland, 'bundesweit')}</select></label>
      <label>Kostenträger-Art<select data-f="kostentraegerArt">${ktOptionen(r.kostentraegerArt, 'alle')}</select></label>
      <label>Kostenträger (Name enthält)<input data-f="kostentraeger" value="${esc(r.kostentraeger)}" placeholder="leer = alle"></label>
      <label>Gültig ab<input type="date" data-f="gueltigAb" value="${esc(r.gueltigAb)}"></label>
      <label>Satz € je ÜE<input data-f="satz" inputmode="decimal" value="${esc(String(r.satz).replace('.', ','))}"></label>
      <label class="span2">Quelle<input data-f="quelle" value="${esc(r.quelle)}" placeholder="z. B. RSD, Vertrag, Datum"></label>
      <button class="btn small danger" data-del="1">Löschen</button></div>`).join('') || '<div class="muted small">Keine Datensätze für diesen Filter.</div>'
    + (liste.length > 200 ? `<div class="muted small">… ${liste.length - 200} weitere – Filter nutzen.</div>` : '');
  $$('#cfg-saetze .satz-card').forEach((card) => {
    const r = SATZ_EDIT.find((x) => x.id === card.dataset.id);
    card.querySelectorAll('[data-f]').forEach((el) => { el.onchange = () => { r[el.dataset.f] = el.value; SATZ_DIRTY = true; zeichneSatzAbfrage(); $('#sf-zaehler').textContent = `${SATZ_EDIT.length} Datensätze · ungespeicherte Änderungen`; }; });
    card.querySelector('[data-del]').onclick = () => { SATZ_EDIT = SATZ_EDIT.filter((x) => x.id !== r.id); SATZ_DIRTY = true; zeichneSatzAbfrage(); zeichneSaetze(); };
  });
}
async function satzSpeichern() {
  try {
    await api('PUT', '/api/settings', { abrechnung: { saetze: SATZ_EDIT.map((r) => ({ ...r, satz: Number(String(r.satz).replace(',', '.')) })) } });
    await reload(false); ladeSaetze(); toast('Vergütungssätze gespeichert.', 'ok');
  } catch (e) { toast(e.message, 'err'); }
}
function satzCsv() {
  const q = (x) => `"${String(x ?? '').replace(/"/g, '""')}"`;
  return '\ufeff' + [['Bundesland', 'Kostenträgerart', 'Kostenträger', 'Maßnahme', 'Gültig ab', 'Satz', 'Quelle'].map(q).join(';'),
    ...SATZ_EDIT.map((r) => [r.bundesland, r.kostentraegerArt, r.kostentraeger, artLabel(r.art), r.gueltigAb ? fmt(r.gueltigAb) : '', String(r.satz).replace('.', ','), r.quelle].map(q).join(';'))].join('\r\n');
}
/** Text (CSV/Tabelle aus Excel oder RSD-Seite) in Datensätze umwandeln. */
function satzParse(text) {
  const zeilen = String(text || '').replace(/\r/g, '').split('\n').map((z) => z.trim()).filter(Boolean);
  const fehler = [], ok = [];
  if (!zeilen.length) return { ok, fehler };
  const trenn = zeilen[0].includes('\t') ? '\t' : ';';
  const teile = (z) => z.split(trenn).map((x) => x.trim().replace(/^"|"$/g, '').replace(/""/g, '"'));
  let spalten = ['bundesland', 'kostentraegerArt', 'kostentraeger', 'art', 'gueltigAb', 'satz', 'quelle'];
  let start = 0;
  const kopf = teile(zeilen[0]).map((x) => x.toLowerCase());
  if (kopf.some((x) => x.includes('satz') || x.includes('gültig') || x.includes('maßnahme') || x.includes('position'))) {
    start = 1;
    spalten = kopf.map((x) => (x.includes('bundesland') ? 'bundesland' : x.includes('träger') && x.includes('art') ? 'kostentraegerArt' : x.includes('träger') ? 'kostentraeger' : x.includes('maßnahme') || x.includes('position') || x.includes('leistung') ? 'art'
      : x.includes('gültig') || x.includes('ab') && x.includes('datum') ? 'gueltigAb' : x.includes('satz') || x.includes('vergütung') || x.includes('preis') ? 'satz' : x.includes('quelle') ? 'quelle' : ''));
  }
  const pos = Object.assign({}, AZH_POS_STANDARD, (S.settings.abrechnung || {}).positionsnummern || {});
  const arten = Object.entries(S.regeln.arten).map(([k, x]) => [k, x.label.toLowerCase()]);
  const alsArt = (t) => {
    const s = t.toLowerCase().replace(/\s+/g, ' ').trim();
    if (!s) return '';
    if (S.regeln.arten[t]) return t;
    const nr = s.replace(/\D/g, '');
    const byNr = Object.entries(pos).find(([, n]) => String(n).replace(/\D/g, '') === nr && nr.length >= 6);
    if (byNr) return byNr[0];
    const exakt = arten.find(([, l]) => l === s); if (exakt) return exakt[0];
    const kand = arten.filter(([, l]) => l.includes(s) || s.includes(l.replace(/\s*\(.*\)/, ''))).sort((a, b) => b[1].length - a[1].length);
    return kand[0] ? kand[0][0] : '';
  };
  const alsDatum = (t) => { const m = String(t).match(/(\d{1,2})\.(\d{1,2})\.(\d{4})/); if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`; return /^\d{4}-\d{2}-\d{2}$/.test(t) ? t : ''; };
  const alsBl = (t) => { const u = t.toUpperCase(); if (BUNDESLAENDER[u]) return u; const e = Object.entries(BUNDESLAENDER).find(([, n]) => n.toLowerCase() === t.toLowerCase()); return e ? e[0] : ''; };
  const alsKt = (t) => { const s = t.toLowerCase(); if (!s) return ''; if (['gkv', 'rv', 'uv', 'sonstige'].includes(s)) return s; if (/kranken|gkv|ersatz|aok|ikk|barmer|tk|dak/.test(s)) return 'gkv'; if (/renten|drv/.test(s)) return 'rv'; if (/unfall|dguv|bg\b/.test(s)) return 'uv'; return ''; };
  zeilen.slice(start).forEach((z, i) => {
    const w = teile(z), o = {};
    spalten.forEach((s, j) => { if (s) o[s] = w[j] || ''; });
    const nr = i + 1 + start;
    const art = alsArt(o.art || ''), satz = Number(String(o.satz || '').replace(/[^\d,.-]/g, '').replace(',', '.'));
    if (!art) { fehler.push(`Zeile ${nr}: Maßnahme/Positionsnummer „${o.art || ''}“ nicht erkannt`); return; }
    if (!(satz > 0)) { fehler.push(`Zeile ${nr}: Satz fehlt oder ungültig`); return; }
    ok.push({ id: `s_${Date.now().toString(36)}${i}`, bundesland: alsBl(o.bundesland || ''), kostentraegerArt: alsKt(o.kostentraegerArt || o.kostentraeger || ''), kostentraeger: o.kostentraeger && !['gkv', 'rv', 'uv'].includes(o.kostentraeger.toLowerCase()) ? o.kostentraeger : '', art, gueltigAb: alsDatum(o.gueltigAb || ''), satz, quelle: o.quelle || 'Import' });
  });
  return { ok, fehler };
}
function satzImportDialog() {
  openModal('Datensätze einsetzen', `
    <p class="hint">Einfügen aus Excel/Tabelle oder CSV-Datei. Spalten (mit Kopfzeile oder in dieser Reihenfolge): <strong>Bundesland; Kostenträgerart; Kostenträger; Maßnahme (oder Positionsnummer); Gültig ab; Satz; Quelle</strong>. Datum <code>01.01.2026</code>, Satz <code>7,24</code>. Gleiche Datensätze werden ersetzt.</p>
    <textarea id="si-text" rows="9" style="width:100%" placeholder="Nordrhein-Westfalen;gkv;AOK;604503;01.01.2026;7,24;RSD"></textarea>
    <div class="row" style="margin-top:8px"><label class="btn small" for="si-file">CSV-Datei wählen</label><input type="file" id="si-file" accept=".csv,.txt,text/csv,text/plain" hidden>
      <button class="btn small" id="si-vorlage">Vorlage</button></div>
    <div id="si-vorschau" class="muted small" style="margin-top:8px"></div>`,
  [{ label: 'Abbrechen', cls: 'btn', onClick: closeModal },
   { label: 'Übernehmen', cls: 'btn primary', onClick: () => {
       const { ok, fehler } = satzParse($('#si-text').value);
       if (!ok.length) { toast(fehler[0] || 'Keine Datensätze erkannt.', 'err'); return; }
       const key = (r) => [r.bundesland, r.kostentraegerArt, r.kostentraeger.toLowerCase(), r.art, r.gueltigAb].join('|');
       const neu = new Map(ok.map((r) => [key(r), r]));
       SATZ_EDIT = SATZ_EDIT.filter((r) => !neu.has(key(r))).concat([...neu.values()]);
       SATZ_DIRTY = true; closeModal(); zeichneSatzAbfrage(); zeichneSaetze();
       toast(`${ok.length} Datensätze übernommen${fehler.length ? `, ${fehler.length} Zeilen ignoriert` : ''} – bitte speichern.`, 'ok');
   } }], { wide: true });
  const vorschau = () => { const { ok, fehler } = satzParse($('#si-text').value); $('#si-vorschau').innerHTML = $('#si-text').value.trim() ? `${ok.length} Datensätze erkannt${fehler.length ? ` · <span class="errline">${fehler.length} Zeilen ignoriert:<br>${esc(fehler.slice(0, 4).join('\n')).replace(/\n/g, '<br>')}</span>` : ''}` : ''; };
  $('#si-text').oninput = vorschau;
  $('#si-file').onchange = async (e) => { const f = e.target.files[0]; if (f) { $('#si-text').value = await f.text(); vorschau(); } };
  $('#si-vorlage').onclick = () => { $('#si-text').value = 'Bundesland;Kostenträgerart;Kostenträger;Maßnahme;Gültig ab;Satz;Quelle\nNW;gkv;;604503;01.01.2026;7,24;Beispiel\nNW;gkv;;604504;01.01.2026;11,27;Beispiel'; vorschau(); };
}

$('#btn-save-anbieter').onclick = async () => {
  const anbieter = {};
  $$('#cfg-anbieter [data-a]').forEach((el) => { anbieter[el.dataset.a] = el.value.trim(); });
  try { await api('PUT', '/api/settings', { anbieter }); await reload(false); toast('Anbieterdaten gespeichert.', 'ok'); } catch (e) { toast(e.message, 'err'); }
};
$('#btn-save-ort').onclick = async () => {
  const fuehrungspersonal = $$('#cfg-fuehrung .row').map((row) => ({
    name: row.querySelector('[data-fp=name]').value.trim(),
    email: row.querySelector('[data-fp=email]').value.trim(),
  })).filter((f) => f.email);
  try {
    await api('PUT', '/api/settings', { bundesland: $('#cfg-bundesland').value, ortLändlich: $('#cfg-laendlich').checked, fuehrungspersonal });
    await reload(false); toast('Gespeichert.', 'ok');
  } catch (e) { toast(e.message, 'err'); }
};
$('#btn-fuehrung-plus').onclick = () => {
  (S.settings.fuehrungspersonal = S.settings.fuehrungspersonal || []).push({ name: '', email: '' });
  renderEinstellungen();
};
$('#btn-save-smtp').onclick = async () => {
  const smtp = {};
  $$('#cfg-smtp [data-s]').forEach((el) => { smtp[el.dataset.s] = el.type === 'checkbox' ? el.checked : (el.dataset.s === 'port' ? Number(el.value) : el.value.trim()); });
  try { await api('PUT', '/api/settings', { smtp }); await reload(false); toast('SMTP gespeichert.', 'ok'); } catch (e) { toast(e.message, 'err'); }
};
$('#btn-testmail').onclick = async () => {
  try {
    const r = await api('POST', '/api/testmail', { an: (S.settings.anbieter || {}).email });
    toast(mailStatusText(r.outbox), r.outbox.status === 'gesendet' ? 'ok' : 'err');
    await reload(false);
  } catch (e) { toast(e.message, 'err'); }
};
$('#btn-save-ds').onclick = async () => {
  const datenschutz = {};
  $$('#cfg-ds [data-d]').forEach((el) => { datenschutz[el.dataset.d] = el.value.trim(); });
  try {
    await api('PUT', '/api/settings', { datenschutz, kalender: { titel: $('#cfg-kal-titel').value.trim() }, abrechnung: { stelle: $('#cfg-abr-stelle').value.trim(), kundennr: $('#cfg-abr-kundennr').value.trim(), hersteller: $('#cfg-abr-hersteller').value.trim(), positionsnummern: Object.fromEntries($('#cfg-abr-pos').value.split('\n').map((l) => l.split('=').map((x) => x.trim())).filter((a) => a[0] && a[1])), automatisch: $('#cfg-autoabr').checked, zahlungszielTage: Number($('#cfg-zahlungsziel').value) || 0 }, scan: { punkteAbhaken: $('#cfg-scan-punkte').checked }, unterschrift: { vorabMinuten: Number($('#cfg-vorab').value) || 0 }, google: { adresse: $('#cfg-gmail').value.trim(), abrechnungEmpfaenger: $('#cfg-abr-mail').value.trim() }, gruppennamen: $('#cfg-gruppen').value.split('\n') });
    await reload(false); toast('Gespeichert.', 'ok');
  } catch (e) { toast(e.message, 'err'); }
};
$('#import-file').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  if (!confirm('Backup importieren? Der aktuelle Datenbestand wird ersetzt (Vorher-Backup wird angelegt).')) { e.target.value = ''; return; }
  try {
    const text = await f.text();
    const neu = JSON.parse(text);
    if ((S.lokalModus || window.LOCAL_MODE) && window.RheaStore) {
      const cur = await api('GET', '/api/export');
      await RheaStore.snapshot(cur.json, 'vor Import', true);
    }
    await api('POST', '/api/import', neu);
    await reload(true); toast('Backup importiert.', 'ok');
  } catch (err) { toast(`Import fehlgeschlagen: ${err.message}`, 'err'); }
  e.target.value = '';
});
$('#btn-demo-reset').onclick = async () => {
  if (!confirm('Alle Stammdaten (Trainer, Kurse, Patienten, Verordnungen, Termine) löschen?')) return;
  try { await api('POST', '/api/demo-reset'); await reload(true); toast('Stammdaten gelöscht.', 'ok'); } catch (e) { toast(e.message, 'err'); }
};

/* ============================== START ============================== */
(async function start() {
  try {
    await reload(false);
    zeigeView('dashboard');
  } catch (e) {
    document.body.innerHTML = `<div style="padding:40px;font-family:sans-serif"><h2>Verbindung zum lokalen Server fehlgeschlagen</h2><p>${esc(e.message)}</p></div>`;
  }
})();

/* Speicher-Warnung: Der lokale Speicher der App ist begrenzt (ca. 5 MB). Bei Überlauf würden Änderungen verloren gehen. */
let speicherWarnung = 0;
window.addEventListener('rhea-speicherfehler', () => {
  if (Date.now() - speicherWarnung < 60000) return;
  speicherWarnung = Date.now();
  alert('⚠ Speicher voll – Änderungen konnten NICHT gespeichert werden!\n\nBitte sofort in den Einstellungen ein Backup teilen/speichern. Neue Eingaben erst fortsetzen, wenn Platz geschaffen ist (ältere Daten im Admin-Bereich prüfen).');
});
function speicherPruefen() {
  try {
    let n = 0; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); n += (k.length + (localStorage.getItem(k) || '').length) * 2; }
    const mb = n / 1048576;
    if (mb > 3.5 && Date.now() - speicherWarnung > 3600000) { speicherWarnung = Date.now(); toast(`Speicher zu ${Math.round(mb / 5 * 100)} % belegt (Grenze ca. 5 MB) – bitte Backup teilen und ältere Daten prüfen.`, 'err'); }
  } catch (_) { /* egal */ }
}
setTimeout(speicherPruefen, 4000);
