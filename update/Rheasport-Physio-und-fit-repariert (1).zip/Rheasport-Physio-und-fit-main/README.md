# RheaSport – Physio & fit

Lokal gespeicherte Verwaltungs-App für **Rehasport/Funktionstraining** nach den Regeln von
**RehaSport Deutschland e. V. (RSD)** / der Rahmenvereinbarung der **BAR** – mit digitalem
Datenabgleich nach dem Scann der Verordnung, digitalen Unterschriften, Trainer- & Kursverwaltung,
geteiltem Terminkalender, E-Mail-Benachrichtigungen und abrechnungsfertigen Nachweisen.

> Die Regeln der App orientieren sich am RSD-Pflichtmodul „Rehasport für Verantwortliche“
> (Gesetzliche Grundlagen, Rahmenvereinbarung, Muster 56, Datenschutz, Abrechnung),
> § 43 SGB V i. V. m. § 64 SGB IX und der DS-GVO. Sitz des Beispiels: **Nordrhein-Westfalen**
> (Hilfsfrist 8 Minuten, in ländlichen Bereichen 12 Minuten).

## Schnellstart

```bash
npm install          # Abhängigkeiten (express, nodemailer, qrcode, jsqr)
npm start            # App auf http://localhost:8080
npm run demo         # (optional) Beispieldaten anlegen – Server muss laufen
```

Der komplette Datenbestand liegt **lokal** in `data/db.json` (git-ignoriert).
Es werden keine Daten an externe Dienste gesendet – außer Sie konfigurieren SMTP-Versand.

## Android-APK (Lokalmodus)

Die App läuft **ohne Server** als Android-APK (Capacitor 8): Alle Daten liegen dann
ausschließlich im `localStorage` des Geräts (DSGVO: Daten verlassen das Gerät nicht).

```bash
npm run test          # Lokalmodus-API (public/local-api.js) testen
npm run apk:sync      # Web-Assets ins Android-Projekt einbetten (nach Änderungen)
```

Der APK-Build läuft über **GitHub Actions** (Workflow `.github/workflows/build-apk.yml`):
Push auf den Branch (oder manuell „Run workflow“). Die fertige Datei liegt danach
**im Repository unter `artifacts/RheaSport-Physio-und-fit-debug.apk`** (zusätzlich als
Workflow-Artefakt „RheaSport-APK“) – auf dem Gerät installieren („Unbekannte Quellen“).
Der Workflow erzeugt das Capacitor-Android-Projekt frisch, trägt App-Icons und die
`CAMERA`-Berechtigung (QR-Scanner) ein, baut mit Gradle und committet das Ergebnis.

Unterschiede im Lokalmodus:

* **E-Mail:** Es gibt keinen SMTP-Versand – jede Nachricht wird als Entwurf angelegt und
  über die Mail-App des Geräts versendet (E-Mail-Journal → „Öffnen“).
* **Kalender:** Statt Feed-URL wird der Kalender als `.ics`-Datei geteilt (nur Kurstermine,
  keine Patientennamen).
* **QR-Codes** werden direkt im Gerät erzeugt; CSV-/Backup-Export nutzt die Teilen-Funktion.
* Ein Browser kann den Modus mit `?local=1` testen (Daten dann im Browser-Speicher).

## Funktionen

### 1. Verordnung scannen → Datenabgleich (Kernprozess)
* **Scan per Kamera, QR-Bild oder manueller Code-Eingabe** (JSON, URL-Parameter oder
  Kurzformat `RS56|Name|Geb.|Kasse|VersNr|von|bis|Art|Freq|ÜE|ICD|Arzt`).
* Nach dem Scan öffnet sich automatisch das **Menü für den Datenabgleich**:
  1. **Datenabgleich** – Stammdaten der Verordnung prüfen/korrigieren, **E-Mail- und
     Telefonnummer** erfassen (Pflichtfelder).
  2. **Vollständigkeitsprüfung nach RSD-Regeln** – Live-Checkliste (rot = blockierend):
     aktuelles Formular (Muster 56 ab 2023, G0850, DGUV ab 2025), Pflichtangaben,
     **Kostenübernahme muss vor der 1. Übungseinheit vorliegen**, Frequenz (3×/Woche nur mit
     Begründung), ÜE-Richtwerte (50/90/120 inkl. Diagnosenliste), Folgeverordnungs-Begründung,
     Dauer > 6 Monate nur mit Begründung, Beginnfrist, DSGVO-Einwilligung …
  3. **Trainer-Auswahl anhand der Verordnung** – automatisches Matching: Verordnungsart,
     ICD-10 → Fachbereich, Frequenz, BAR-/RSD-Anerkennung, Zertifikatsgültigkeit
     (Herzgruppen max. 2 Jahre, sonst max. 4), feste Gruppe mit freien Plätzen.
  4. **Gruppe & Einwilligung** – feste Gruppe zuordnen (nur passende Art), digitale
     Unterschrift für Anmeldung & Art.-9-DSGVO-Einwilligung.
* **Nach dem Abschluss:**
  * die/er **Patient/in erhält per E-Mail ihre/sein Termine**,
  * das **Führungspersonal erhält die E-Mail-Bestätigung „Verordnung vollständig“**
    inkl. Prüfprotokoll.

* **Foto-OCR (offline):** „Foto auslesen (OCR)“ fotografiert die Verordnung, erkennt den Text auf dem Gerät
  (Tesseract.js, deutsche Sprachdaten, keine Übertragung) und schlägt Name, Geburtsdatum, Versicherten-Nr.,
  Kasse, Zeitraum, Frequenz, ÜE, ICD-10 und Ärztin/Arzt vor. Alles ist vor der Übernahme korrigierbar.
* **PDF417-/QR-/DataMatrix-Scan:** Kamera, Foto oder Bild; zuerst der Systemdetektor (BarcodeDetector),
  sonst jsQR (QR) und ZXing (PDF417). Ein Barcode im Foto hat Vorrang vor OCR-Werten.
* **ICD-10-Regelwerk:** Formatprüfung (blockiert), Plausibilität Diagnose ↔ Maßnahme (Herzgruppe, Herzinsuffizienz,
  120-ÜE-Diagnosen, Symptomcodes) als Hinweise. Siehe `lib/rules.js` (`ICD_BEREICHE`, `pruefeIcd`).

### 2. Trainer & Eigenschaften
* Qualifikationen (Übungsleiter/in Rehasport BAR, Herzgruppenleitung, Wasser, Kinder,
  Funktionstraining, Gesundheitsbildung, Fachbereiche Orthopädie/Innere/Neuro/…),
  Notfallqualifikationen nach Rahmenvereinbarung, Zertifikatsfristen, Anerkennung,
  **Verschwiegenheitserklärung** & Datenschutz-Belehrung (§ 203 StGB / Art. 9 DSGVO).
* Anlegen von **Kursen (festen Gruppen)** je Trainer mit automatischer RSD-Prüfung.

### 3. Kurse / feste Gruppen
* Mindestdauer 45 Min. (Herzgruppe 60), Teilnehmerlimits (15/10/20/12/7/5),
  5 qm pro Person (Wasser 3 qm), keine technischen Geräte (Ausnahme Ergometer in Herzgruppen),
  keine Vermischung mit Prävention (§ 20 SGB V), Herzgruppe: betreuender Arzt, Notfallplan,
  (A)ED, Notfallkoffer, Notfallübungen 2×/Jahr, Arztvisitation mind. alle 6 Wochen.

### 4. Geteilter Terminkalender
* Monatsansicht aller Übungseinheiten, Terminverwaltung (stattgefunden/ausgefallen/verschoben).
* **Teilbarer ICS-Feed** (Google/Apple/Outlook) – enthält nur Kurstermine, **keine
  Patientennamen/Gesundheitsdaten** (Art. 9 DSGVO). Link jederzeit kündbar/erneuerbar.
* Patientinnen und Patienten werden in der App zur festen Gruppe hinzugefügt (Termine-Liste
  und Termin-E-Mail aktualisieren sich automatisch).

### 5. Digitale Unterschriften (RESI-Prinzip)
* Unterschriften-Pad (Maus/Finger/Stift) mit **Zeitstempel** für:
  Teilnahmebestätigung je Übungseinheit, Bestätigung der/des Übungsleitenden,
  Anmeldung und DSGVO-Einwilligung.
* **Vorab-Unterschriften sind technisch gesperrt** (Rahmenvereinbarung/RSD-Vertragsverstoß):
  erst zulässig, wenn die Übungseinheit stattgefunden hat. Korrekturen werden im Audit-Log
  protokolliert (kein Tipp-Ex, keine Vordatierung). Papier-Unterschriften als Rückfallebene
  dokumentierbar.

### 6. Abrechnung
* Zeigt je Verordnung die **tatsächlich erbrachten ÜE** (nur mit Unterschrift **und**
  Leitungsbestätigung – Vorleistungen zählen nicht).
* Vergütungssätze frei hinterlegbar – offizielle Adressat:innen für die Sätze:
  **<https://verguetungssaetze.rehasport-deutschland.de/>**
* Status „abgerechnet“ mit Rechnungsnummer, CSV-Export (`;`-getrennt, Excel-tauglich).
* Keine Eigenbeteiligungen von GKV-Teilnehmenden (Sachleistungsprinzip, § 2 SGB V).

### 7. E-Mail-Journal
* SMTP frei konfigurierbar (z. B. GMX: `mail.gmx.net`, Port 587).
* Ohne SMTP-Konfiguration werden Nachrichten als **Entwurf** vorgehalten und können per
  `mailto:` geöffnet werden – nichts geht verloren.
* Versand: Termine an Patientinnen/Patienten, Vollständigkeit an das Führungspersonal,
  Test-Mail, erneuter Versand, Vorschau.


### 8. Unterschriften, Patienten-Reiter & automatische Abrechnung (Lokalmodus/APK)
* **Unterschrift ab X Min. vor Kursbeginn** (Einstellungen, Standard 20; 0 = erst nach der Einheit). Solche Unterschriften sind als „vorab“ markiert,
  zählen erst nach der Leitungsbestätigung und lassen sich **stornieren** (Audit-Log).
* **Fehlende Unterschriften:** Im nächsten Termin und im Patienten-Reiter „Unterschriften“ erscheint ein Hinweis mit **Nachholen** oder **Grund des Fehlens**.
* **Patienten-Reiter:** Übersicht · Termine · Unterschriften (inkl. Druck) · Abrechnung.
* **Druckbare Unterschriftenlisten** je Verordnung: Standard (GKV), Rentenversicherung, DGUV (Nachbildung, kein amtliches Formular; Teilen als HTML möglich).
* **Automatische Abrechnung** (Einstellung ein/aus): Bei Abbruch oder vollständig erbrachter Verordnung entsteht ein Abrechnungsentwurf mit Rechnungsnummer
  (`RS-JJJJ-NNNN`); bis „Als abgerechnet“ wird die Zahl erbrachter ÜE nachgeführt.
* Hinweis: Diese Funktionen sind in `public/local-api.js` (APK) umgesetzt, nicht in `server.js`.


### 9. Dokumente, Scans & Backups (Lokalmodus/APK)
* **Menü „Dokumente“:** Scans je Patient · Trainingsdokumentation · Teilnehmerlisten · Vorlagen (leer, druckbar). Zusätzlich Reiter „Dokumente“ im Patienten.
* **Scannen per Kamera/Galerie** (`public/store.js`, IndexedDB): Foto wird verkleinert, optional in Graustufen mit mehr Kontrast gespeichert. Ordner je Patient
  (`Patienten/Nachname_Vorname/`); Anzeigen, Teilen/Speichern, Löschen.
* **Backups:** Nach jeder Änderung automatisch (entprellt), die letzten 40 plus ein Stand pro Tag der letzten 60 Tage. Wiederherstellen sichert vorher den aktuellen Stand
  („vor Wiederherstellung“); ebenso der Import einer Backup-Datei. Scans sind nicht Teil der Backup-Datei.
* **Speicherort:** Wo der Browser/WebView die Ordnerwahl bietet (File System Access API), spiegelt die App Backups und Scans in den gewählten Ordner. Auf Android-WebView
  ist das meist nicht verfügbar – dort „Teilen/Speichern“ nutzen und im Teilen-Dialog den Netzwerkordner wählen.


### 10. Beratungsprotokoll & Abrechnungspaket für das Abrechnungszentrum (azh/NOVENTI)
* **Beratungsprotokoll Rehabilitationssport:** je Verordnung erfassbar (Angaben + zwei digitale Unterschriften + „Kopie ausgehändigt“), druckbar, leere Vorlage unter Dokumente → Vorlagen.
* **Abrechnungspaket (Abrechnung → „📦 Abrechnungspaket“):** eigene Seite mit Suche, Sortierung, Seiten, Auswahl und Summenfeld; Sendungsbegleitschein; Prüfliste je Verordnung (IK, Genehmigungskennzeichen/-datum vor Leistungsbeginn, Positionsnummer, Beratungsprotokoll …),
  Deckblatt „Einlieferung“, je Verordnung eine Teilnahmebestätigung mit Unterschriftsbildern (inkl. Hinweis auf Signatur-App/Hersteller), CSV-Datenliste, „Als eingereicht markieren“ → Offene Posten.
* **Wichtig:** Die DTA-Datei nach § 302 SGB V erzeugt das Abrechnungszentrum aus den Originalunterlagen; die App erzeugt **keine** DTA-Datei. Rentenversicherung/DGUV laufen nicht über § 302 (eigene Träger-Verfahren).
  Die gedruckten Teilnahmebestätigungen sind Nachbildungen – vorab mit Abrechnungszentrum/Kasse klären, ob sie den Original-Vordruck ersetzen dürfen.
* Einstellungen → Abrechnungszentrum: Stelle, Kunden-Nr., Hersteller der Signatur-App, Positionsnummern (Standard: rs=604503, herzgruppe=604504; weitere bitte erfragen).


### 11. Vergütungssätze als Datensätze & Filter in allen Listen
* **Einstellungen → Vergütungssätze:** Datensätze nach RSD-Struktur (Bundesland · Kostenträger-Art/-Name · Maßnahme · Gültig ab · Satz). „Satz abfragen“ zeigt den passenden Satz sofort, wenn Bundesland/Position/Kostenträger/Datum gewechselt werden.
  „Datensätze einsetzen“ importiert eingefügten Text oder CSV (Positionsnummern wie 604503 werden erkannt). Vorbelegt sind nur die DRV-Bund-Sätze (Pos. 604503/604504); alle übrigen Sätze (Primär-/Ersatzkassen, DGUV) selbst einsetzen.
* **Abrechnung:** Betrag = je erbrachter Übungseinheit der Satz zum Leistungsdatum (Zeitpunkt der Leistungserbringung); nach „abgerechnet“ eingefroren. Manuell eingegebene Sätze bleiben fest.
* **Filter/Suche:** Trainer, Gruppen, Kalender (Übungsleitung/Gruppe/Status), E-Mail-Journal, Datenabgleich, Dokumente; Patienten zusätzlich nach Kostenträger, Maßnahme, Übungsleitung und offenen Punkten (Unterschrift/Beratungsprotokoll/Genehmigung fehlt).


### 12. Mehrere Geräte, Admin-Bereich, Patientenakte
* **Mehrere Geräte:** Jedes Gerät hat seine eigene lokale Datenbank (kein Live-Abgleich). Einstellungen → „Mehrere Geräte & Abgleich“: Abgleichsdatei erzeugen/einlesen. Je Datensatz gewinnt die neuere Änderung,
  Unterschriften verschiedener Personen im selben Termin bleiben beide erhalten, Löschungen werden übernommen, echte Konflikte stehen im Admin-Protokoll. Einstellungen (inkl. Vergütungssätze, Admin-PIN) werden ebenfalls abgeglichen
  (neuere Änderung gewinnt; ein frisch installiertes Gerät überschreibt nichts). Rechnungsnummern enthalten ein Gerätekürzel (`RS-JJJJ-XX-0001`), automatisch erzeugte Entwürfe werden angeglichen.
  Scans/Fotos, E-Mail-Journal und die Google-Anmeldung sind je Gerät. Vor jedem Einlesen wird automatisch ein Backup angelegt.
* **Admin (Logo 5× antippen):** PIN-geschützt; Verordnungen/Stammdaten ändern (z. B. Annahme der Verordnung, Beginn) nur mit Begründung, Sammeländerung, Änderungs- und Audit-Protokoll (CSV), Abgleich-Konflikte, Integritätsprüfung, Systemübersicht.
* **Dokumente → Patientenakte:** alle fertigen Dokumente je Patient (Verordnung mit Unterschriften, Beratungsprotokoll, Kostenübernahme, Unterschriftenlisten, Rechnungen, Abbruchprotokoll, Scans) mit Suche und Filter.
* **Speichergrenze:** Der lokale Speicher der App ist auf ca. 5 MB begrenzt. Bei Überlauf erscheint eine Warnung (ab ca. 70 % schon früher); dann Backup teilen und Altdaten prüfen.

## Rechtliche/Erganzende Hinweise

* **Kein Ersatz für Rechtsberatung.** Die Prüfungen bilden den Stand der beigefügten
  RSD-/BAR-Unterlagen ab (Rahmenvereinbarung 2022, Muster 56 ab 2023, DGUV-Verordnung ab 2025).
  Kostenträger-spezifische Fristen (z. B. Genehmigungsverzicht, AOK BW 12 Wochen) bitte
  zusätzlich beachten – die App meldet sie als Hinweise.
* **Datenschutz:** Alle Daten bleiben lokal (`data/db.json`). Empfohlen (RSD): DSB benennen,
  Datenschutzhandbuch, Mitarbeiter-Schulung, Verschwiegenheitserklärungen – Felder dafür
  sind in den Einstellungen/Trainerstammdaten hinterlegt. Einwilligungen werden mit
  Unterschrift und Zeitstempel dokumentiert.
* **Zugriffsschutz:** Vor Produktivbetrieb den Server z. B. mit
  `APP_TOKEN=geheim npm start` absichern (alle API-Aufrufe verlangen dann `?t=geheim`)
  und den Zugang zum Rechner/Netzwerk technisch begrenzen.
* **Backups:** Regelmäßig unter Einstellungen → „Backup exportieren“.

## Projektstruktur

```
server.js          Express-Server + API (Scan, Prüfung, Matching, Termine, Mail, ICS)
lib/rules.js       RSD-Regelwerk (Vollständigkeit, Kursprüfung, Trainer-Matching)
lib/db.js          lokaler JSON-Datenbestand (atomare Schreibweise, Audit-Log)
lib/mail.js        SMTP-Versand, Journal, Vorlagen (Termine / Verordnung vollständig)
lib/ical.js        iCalendar-Feed des geteilten Kalenders
public/            Frontend (index.html, app.css, app.js) – Signatur-Pad, QR-Scanner
scripts/demo.js    Beispieldaten (npm run demo)
data/db.json       lokaler Datenbestand (nicht im Git)
```

## API (Auszug)

| Methode | Pfad | Zweck |
|---|---|---|
| POST | `/api/verordnungen/scan` | Code scannen → Entwurf + Prüfung (öffnet Datenabgleich) |
| PUT | `/api/verordnungen/:id` | Datenabgleich speichern; `abschliessen:true` = final inkl. E-Mails |
| POST | `/api/matching` | passende Trainer/innen zur Verordnung |
| POST | `/api/termine/:id/anwesenheit` | Anwesenheit + Unterschrift (Zeitstempel-Regel) |
| GET | `/api/calendar/:token.ics` | geteilter Kalender-Feed (ohne Patientendaten) |
| GET | `/api/abrechnung/export.csv` | Abrechnungsliste als CSV |
| GET/POST | `/api/export`, `/api/import` | Backup erstellen/wiederherstellen |
